#!/usr/bin/env python3
"""
Checks an Android APK before it is published. Standard library only.

  python3 tools/verify_apk.py app-debug.apk --gradle-file app/build.gradle.kts --require-tools

Always runs: file present, SHA-256, archive CRC, required entries, native ABI list, engine libraries.
Needs Android build-tools (aapt2 or aapt, apksigner): package id, version code and name, SDK levels,
permissions, launcher activity, and the signature. Use --require-tools in CI so those checks cannot be skipped.

Exit code 0 = every mandatory check passed. 1 = at least one failed.
"""
# Copyright (C) 2026 khaledmmg
#
# This file is part of YtClip.
# YtClip is free software: you can redistribute it and/or modify it under the terms of the
# GNU General Public License version 3, as published by the Free Software Foundation.
# It is distributed WITHOUT ANY WARRANTY. See the LICENSE file for details.

import argparse
import glob
import hashlib
import os
import re
import shutil
import subprocess
import sys
import zipfile
import zlib

REQUIRED_ENTRIES = ["AndroidManifest.xml", "classes.dex", "resources.arsc"]
ALLOWED_ABIS = {"arm64-v8a"}                      # build.gradle.kts: ndk { abiFilters += "arm64-v8a" }
ALLOWED_PERMISSIONS = {                           # AndroidManifest.xml
    "android.permission.INTERNET",
    "android.permission.ACCESS_NETWORK_STATE",
    "android.permission.FOREGROUND_SERVICE",
    "android.permission.FOREGROUND_SERVICE_DATA_SYNC",
    "android.permission.POST_NOTIFICATIONS",
}
ENGINE_LIBS = {"ffmpeg": "libffmpeg", "aria2c": "libaria2c"}   # warn if missing (names may differ by release)


class Report:
    def __init__(self):
        self.rows, self.failed = [], 0

    def ok(self, name, detail=""):
        self.rows.append(("PASS", name, detail))

    def warn(self, name, detail=""):
        self.rows.append(("WARN", name, detail))

    def skip(self, name, detail=""):
        self.rows.append(("SKIP", name, detail))

    def fail(self, name, detail=""):
        self.rows.append(("FAIL", name, detail))
        self.failed += 1

    def show(self):
        print("| Result | Check | Detail |")
        print("|---|---|---|")
        for result, name, detail in self.rows:
            print(f"| {result} | {name} | {str(detail).replace('|', '/')} |")
        print()
        print("**All mandatory checks passed.**" if not self.failed
              else f"**{self.failed} mandatory check(s) failed.**")


def sha256_of(path):
    digest = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_gradle(path):
    """Expected values, taken from the project's own build file (the single source of truth)."""
    text = open(path, encoding="utf-8").read()

    def grab(pattern):
        m = re.search(pattern, text)
        return m.group(1) if m else None

    return {
        "package": grab(r'applicationId\s*=\s*"([^"]+)"'),
        "version_code": grab(r"versionCode\s*=\s*(\d+)"),
        "version_name": grab(r'versionName\s*=\s*"([^"]+)"'),
        "min_sdk": grab(r"minSdk\s*=\s*(\d+)"),
        "target_sdk": grab(r"targetSdk\s*=\s*(\d+)"),
    }


def find_tool(*names):
    for name in names:
        path = shutil.which(name)
        if path:
            return path
    root = os.environ.get("ANDROID_HOME") or os.environ.get("ANDROID_SDK_ROOT")
    if root:
        for name in names:
            hits = sorted(glob.glob(os.path.join(root, "build-tools", "*", name)))
            if hits:
                return hits[-1]
    return None


def parse_badging(text):
    """Reads `aapt2 dump badging` output."""
    info = {"permissions": re.findall(r"^uses-permission: name='([^']+)'", text, re.M),
            "abis": []}
    m = re.search(r"^package: name='([^']*)' versionCode='([^']*)' versionName='([^']*)'", text, re.M)
    if m:
        info.update(package=m.group(1), version_code=m.group(2), version_name=m.group(3))
    for key, pattern in (("min_sdk", r"^sdkVersion:'(\d+)'"),
                         ("target_sdk", r"^targetSdkVersion:'(\d+)'"),
                         ("launcher", r"^launchable-activity: name='([^']+)'")):
        m = re.search(pattern, text, re.M)
        info[key] = m.group(1) if m else None
    m = re.search(r"^native-code: (.*)$", text, re.M)
    if m:
        info["abis"] = re.findall(r"'([^']+)'", m.group(1))
    return info


def check_entries(z):
    """Decompresses every entry and checks its CRC. Returns a list of damaged entry names with reasons.
    zipfile.testzip() stops at the first error and raises on corrupt deflate data, so each entry is read here."""
    broken = []
    for info in z.infolist():
        try:
            crc, size = 0, 0
            with z.open(info) as f:
                while True:
                    block = f.read(1 << 20)
                    if not block:
                        break
                    crc = zlib.crc32(block, crc)
                    size += len(block)
            if size != info.file_size or (crc & 0xFFFFFFFF) != info.CRC:
                broken.append(f"{info.filename} (checksum mismatch)")
        except Exception as e:  # zlib.error, BadZipFile, EOF, ...
            broken.append(f"{info.filename} ({str(e)[:60]})")
    return broken


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("apk")
    ap.add_argument("--gradle-file", help="app/build.gradle.kts, for the expected package and versions")
    ap.add_argument("--require-tools", action="store_true", help="fail if aapt2/apksigner are missing")
    args = ap.parse_args()
    rep = Report()

    if not os.path.isfile(args.apk):
        rep.fail("File present", args.apk)
        rep.show()
        return 1
    rep.ok("File present", f"{os.path.basename(args.apk)}, {os.path.getsize(args.apk) / 1048576:.1f} MB")
    rep.ok("SHA-256", sha256_of(args.apk))

    if not zipfile.is_zipfile(args.apk):
        rep.fail("Valid archive", "not a zip file, so not an APK")
        rep.show()
        return 1
    with zipfile.ZipFile(args.apk) as z:
        broken = check_entries(z)
        if broken:
            rep.fail("Archive CRC", f"{len(broken)} damaged entr{'y' if len(broken) == 1 else 'ies'}: " + "; ".join(broken[:5]))
        else:
            rep.ok("Archive CRC", f"all {len(z.infolist())} entries decompress and match their checksums")
        names = set(z.namelist())

        missing = [n for n in REQUIRED_ENTRIES if n not in names]
        if missing:
            rep.fail("Required entries", "missing: " + ", ".join(missing))
        else:
            rep.ok("Required entries", ", ".join(REQUIRED_ENTRIES))

        abis = {n.split("/")[1] for n in names if n.startswith("lib/") and n.count("/") >= 2}
        if not abis:
            rep.fail("Native libraries", "no lib/ folder: yt-dlp, ffmpeg and aria2c cannot run")
        elif abis - ALLOWED_ABIS:
            rep.fail("Native ABIs", f"unexpected: {', '.join(sorted(abis - ALLOWED_ABIS))}")
        else:
            rep.ok("Native ABIs", ", ".join(sorted(abis)))

        for engine, lib in ENGINE_LIBS.items():
            found = sorted(n for n in names if n.startswith("lib/") and os.path.basename(n).startswith(lib))
            if found and any(found[0] in b for b in broken):
                rep.fail(f"Engine: {engine}", f"{os.path.basename(found[0])} is damaged")
            elif found:
                rep.ok(f"Engine: {engine}", os.path.basename(found[0]))
            else:
                rep.warn(f"Engine: {engine}", f"no {lib}*.so found; check the library release")

    expected = read_gradle(args.gradle_file) if args.gradle_file and os.path.isfile(args.gradle_file) else {}
    aapt = find_tool("aapt2", "aapt")
    apksigner = find_tool("apksigner")

    if aapt:
        proc = subprocess.run([aapt, "dump", "badging", args.apk], capture_output=True, text=True)
        if proc.returncode != 0:
            rep.fail("Manifest readable", (proc.stderr or proc.stdout).strip()[:200])
        else:
            info = parse_badging(proc.stdout)

            def compare(name, got, want):
                if want is None:
                    rep.warn(name, f"{got} (no expected value in the Gradle file)")
                elif str(got) == str(want):
                    rep.ok(name, got)
                else:
                    rep.fail(name, f"got {got}, expected {want}")

            compare("Package name", info.get("package"), expected.get("package"))
            compare("Version code", info.get("version_code"), expected.get("version_code"))
            compare("Version name", info.get("version_name"), expected.get("version_name"))
            compare("Target SDK", info.get("target_sdk"), expected.get("target_sdk"))
            if info.get("min_sdk") and expected.get("min_sdk"):
                if int(info["min_sdk"]) >= int(expected["min_sdk"]):
                    rep.ok("Min SDK", info["min_sdk"])
                else:
                    rep.fail("Min SDK", f"got {info['min_sdk']}, expected at least {expected['min_sdk']}")
            if info.get("launcher"):
                rep.ok("Launcher activity", info["launcher"])
            else:
                rep.fail("Launcher activity", "no launchable activity")
            extra = sorted(set(info["permissions"]) - ALLOWED_PERMISSIONS)
            if extra:
                rep.warn("Permissions", "not in the project's manifest: " + ", ".join(extra))
            else:
                rep.ok("Permissions", f"{len(info['permissions'])} declared, all expected")
    elif args.require_tools:
        rep.fail("Android build-tools", "aapt2 not found; set ANDROID_HOME or install build-tools")
    else:
        rep.skip("Manifest checks", "aapt2 not found")

    if apksigner:
        proc = subprocess.run([apksigner, "verify", "--print-certs", args.apk], capture_output=True, text=True)
        if proc.returncode == 0:
            dn = re.search(r"certificate DN: (.*)", proc.stdout)
            rep.ok("Signature", dn.group(1).strip() if dn else "verified")
        else:
            rep.fail("Signature", (proc.stderr or proc.stdout).strip()[:200])
    elif args.require_tools:
        rep.fail("Android build-tools", "apksigner not found")
    else:
        rep.skip("Signature", "apksigner not found")

    rep.show()
    return 1 if rep.failed else 0


if __name__ == "__main__":
    sys.exit(main())
