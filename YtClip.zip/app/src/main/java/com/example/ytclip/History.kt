/*
 * Copyright (C) 2026 khaledmmg
 *
 * This file is part of YtClip.
 * YtClip is free software: you can redistribute it and/or modify it under the terms of the
 * GNU General Public License version 3, as published by the Free Software Foundation.
 * It is distributed WITHOUT ANY WARRANTY. See the LICENSE file for details.
 */

package com.example.ytclip

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Remembers finished downloads, newest first, in SharedPreferences under the "history" key. */
object History {
    private const val KEY = "history"
    private const val MAX = 300

    class Item(val title: String, val link: String, val file: String, val audio: Boolean, val time: Long)

    @Synchronized
    fun add(ctx: Context, item: Item) {
        val list = load(ctx).toMutableList()
        list.add(0, item)
        store(ctx, list.take(MAX))
    }

    @Synchronized
    fun all(ctx: Context): List<Item> = load(ctx)

    @Synchronized
    fun clear(ctx: Context) {
        prefs(ctx).edit().remove(KEY).apply()
    }

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("ytclip", Context.MODE_PRIVATE)

    private fun load(ctx: Context): List<Item> = runCatching {
        val a = JSONArray(prefs(ctx).getString(KEY, "[]") ?: "[]")
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Item(o.optString("t"), o.optString("l"), o.optString("f"), o.optBoolean("a"), o.optLong("m"))
        }
    }.getOrDefault(emptyList())

    private fun store(ctx: Context, list: List<Item>) {
        val a = JSONArray()
        list.forEach {
            a.put(JSONObject().put("t", it.title).put("l", it.link).put("f", it.file).put("a", it.audio).put("m", it.time))
        }
        prefs(ctx).edit().putString(KEY, a.toString()).apply()
    }
}
