package com.example.ytclip

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Callable
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Reads a video's title, length and every quality (with exact sizes) straight from YouTube's
 * player API, in about a second. It needs no JavaScript solving, so it is far faster than yt-dlp's
 * extraction. It only feeds the sheet's quality list; the download itself still goes through yt-dlp.
 */
object FastMeta {
    class Meta(val videoId: String, val title: String, val thumb: String, val duration: Int, val formats: JSONArray)

    private class Client(val id: String, val version: String, val body: String, val ua: String)

    private val clients = listOf(
        Client(
            "28", "1.60.19",
            """{"clientName":"ANDROID_VR","clientVersion":"1.60.19","deviceMake":"Oculus","deviceModel":"Quest 3","androidSdkVersion":32,"osName":"Android","osVersion":"12L","hl":"en","gl":"US"}""",
            "com.google.android.apps.youtube.vr.oculus/1.60.19 (Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip"
        ),
        Client(
            "3", "19.09.37",
            """{"clientName":"ANDROID","clientVersion":"19.09.37","androidSdkVersion":30,"osName":"Android","osVersion":"11","hl":"en","gl":"US"}""",
            "com.google.android.youtube/19.09.37 (Linux; U; Android 11) gzip"
        )
    )

    private val cache = ConcurrentHashMap<String, Pair<Long, Meta>>()
    private val pool = Executors.newFixedThreadPool(4) { r -> Thread(r, "ytclip-meta").apply { isDaemon = true } }

    fun videoId(link: String): String? =
        Regex("""(?:v=|youtu\.be/|shorts/|embed/)([\w-]{11})""").find(link)?.groupValues?.get(1)

    /** Cached for 20 minutes. Returns null when no client gave usable formats. */
    fun get(link: String): Meta? {
        val id = videoId(link) ?: return null
        cache[id]?.let { if (System.currentTimeMillis() - it.first < 20 * 60_000L) return it.second }
        val futures = clients.map { c -> pool.submit(Callable { request(id, c) }) }
        val results = futures.mapNotNull { f -> runCatching { f.get(9, TimeUnit.SECONDS) }.getOrNull() }
        val meta = merge(id, results) ?: return null
        cache[id] = System.currentTimeMillis() to meta
        return meta
    }

    private fun request(id: String, c: Client): JSONObject? = runCatching {
        val conn = URL("https://www.youtube.com/youtubei/v1/player?prettyPrint=false").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.doOutput = true
        conn.connectTimeout = 4000
        conn.readTimeout = 6000
        conn.setRequestProperty("Content-Type", "application/json")
        conn.setRequestProperty("User-Agent", c.ua)
        conn.setRequestProperty("X-YouTube-Client-Name", c.id)
        conn.setRequestProperty("X-YouTube-Client-Version", c.version)
        val body = JSONObject()
            .put("context", JSONObject().put("client", JSONObject(c.body)))
            .put("videoId", id)
            .put("contentCheckOk", true)
            .put("racyCheckOk", true)
        conn.outputStream.use { it.write(body.toString().toByteArray()) }
        val j = JSONObject(conn.inputStream.bufferedReader().readText())
        j.takeIf { it.has("streamingData") }
    }.getOrNull()

    private fun merge(id: String, results: List<JSONObject>): Meta? {
        val details = results.firstNotNullOfOrNull { it.optJSONObject("videoDetails") } ?: return null
        val seen = HashSet<String>()
        val out = JSONArray()
        for (r in results) {
            val sd = r.optJSONObject("streamingData") ?: continue
            for (key in listOf("adaptiveFormats", "formats")) {
                val fs = sd.optJSONArray(key) ?: continue
                for (i in 0 until fs.length()) {
                    val f = fs.optJSONObject(i) ?: continue
                    if (!seen.add(f.optString("itag"))) continue
                    convert(f)?.let { out.put(it) }
                }
            }
        }
        if (out.length() == 0) return null
        val thumbs = details.optJSONObject("thumbnail")?.optJSONArray("thumbnails")
        val thumb = thumbs?.optJSONObject((thumbs.length() - 1).coerceAtLeast(0))?.optString("url").orEmpty()
        return Meta(id, details.optString("title"), thumb, details.optString("lengthSeconds").toIntOrNull() ?: 0, out)
    }

    /** Converts one YouTube format into the shape the quality list already understands (yt-dlp-like keys). */
    private fun convert(f: JSONObject): JSONObject? {
        val mime = f.optString("mimeType")
        val type = mime.substringBefore(';').trim()
        val isVideo = type.startsWith("video/")
        val isAudio = type.startsWith("audio/")
        if (!isVideo && !isAudio) return null
        val codecs = mime.substringAfter("codecs=\"", "").substringBefore('"').split(",").map { it.trim() }
        return JSONObject()
            .put("width", f.optInt("width", 0))
            .put("height", f.optInt("height", 0))
            .put("fps", f.optInt("fps", 0))
            .put("filesize", f.optString("contentLength").toLongOrNull() ?: 0L)
            .put("tbr", f.optInt("bitrate", 0) / 1000.0)
            .put("vcodec", if (isVideo) codecs.firstOrNull().orEmpty().ifEmpty { "avc1" } else "none")
            .put("acodec", if (isAudio) codecs.firstOrNull().orEmpty().ifEmpty { "mp4a" } else if (codecs.size > 1) codecs[1] else "none")
            .put("ext", if (type == "audio/mp4") "m4a" else type.substringAfter('/'))
            .put("protocol", "https")
            .put("itag", f.optString("itag"))
    }
}
