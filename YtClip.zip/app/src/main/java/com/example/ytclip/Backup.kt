package com.example.ytclip

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject

/**
 * Saves and restores the download settings as one JSON file.
 * The Google account cookies are never written to the file, and runtime bookkeeping is skipped.
 */
object SettingsBackup {
    private const val PREFS = "ytclip"
    private const val FORMAT = 1
    private val SKIP = setOf("cookies_imported", "upd", "warm")

    /** Writes every setting to [uri]. Returns how many settings were saved. */
    fun write(ctx: Context, uri: Uri): Int {
        val all = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).all
        val prefs = JSONObject()
        var n = 0
        for ((key, value) in all) {
            if (key in SKIP) continue
            val item = JSONObject()
            when (value) {
                is Boolean -> item.put("t", "b").put("v", value)
                is Int -> item.put("t", "i").put("v", value)
                is Long -> item.put("t", "l").put("v", value)
                is Float -> item.put("t", "f").put("v", value.toDouble())
                is String -> item.put("t", "s").put("v", value)
                is Set<*> -> item.put("t", "ss").put("v", JSONArray(value.filterIsInstance<String>()))
                else -> continue
            }
            prefs.put(key, item)
            n++
        }
        val doc = JSONObject().put("app", "YtClip").put("format", FORMAT).put("prefs", prefs)
        val out = ctx.contentResolver.openOutputStream(uri, "wt") ?: error("Could not open the file for writing")
        out.use { it.write(doc.toString(2).toByteArray(Charsets.UTF_8)) }
        return n
    }

    /** Restores settings from [uri]. Returns how many settings were restored. */
    fun read(ctx: Context, uri: Uri): Int {
        val text = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) }
            ?: error("Could not open the file")
        val doc = try { JSONObject(text) } catch (e: Exception) { error("This is not a settings file") }
        require(doc.optString("app") == "YtClip") { "This is not a YtClip settings file" }
        require(doc.optInt("format") <= FORMAT) { "This settings file is from a newer version of YtClip" }
        val src = doc.getJSONObject("prefs")
        val ed = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
        var n = 0
        for (key in src.keys()) {
            if (key in SKIP) continue
            val item = src.getJSONObject(key)
            when (item.getString("t")) {
                "b" -> ed.putBoolean(key, item.getBoolean("v"))
                "i" -> ed.putInt(key, item.getInt("v"))
                "l" -> ed.putLong(key, item.getLong("v"))
                "f" -> ed.putFloat(key, item.getDouble("v").toFloat())
                "s" -> ed.putString(key, item.getString("v"))
                "ss" -> {
                    val a = item.getJSONArray("v")
                    ed.putStringSet(key, (0 until a.length()).map { a.getString(it) }.toSet())
                }
                else -> continue
            }
            n++
        }
        ed.commit() // synchronous, so the screen is rebuilt with the restored values
        return n
    }
}
