plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.ytclip"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.ytclip"
        minSdk = 29
        targetSdk = 35
        versionCode = 20
        versionName = "10.0"
        ndk { abiFilters += listOf("arm64-v8a") }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { viewBinding = true }
    packaging { jniLibs { useLegacyPackaging = true } }  // needed so yt-dlp/python/ffmpeg can run
}

dependencies {
    val yt = "0.18.1"
    implementation("io.github.junkfood02.youtubedl-android:library:$yt")
    // ffmpeg is 0.17.2: the 0.18.x line publishes no ffmpeg artifact (the reference app uses 0.17.2 too)
    implementation("io.github.junkfood02.youtubedl-android:ffmpeg:0.17.2")
    implementation("io.github.junkfood02.youtubedl-android:aria2c:$yt")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
}
