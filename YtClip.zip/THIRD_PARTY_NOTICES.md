# Third-party software and licenses

YtClip is free software, licensed under the **GNU General Public License version 3** (see `LICENSE`).
Because the APK bundles GPL-3.0 code, the whole project is distributed under GPL-3.0 as well. The source code
must stay available with every build. This repository is that source.

| Component | License | Where it comes from |
|---|---|---|
| youtubedl-android (library and the aria2c module) | GPL-3.0 | https://github.com/JunkFood02/youtubedl-android (Maven: `io.github.junkfood02.youtubedl-android`) |
| yt-dlp (downloads run it; youtubedl-android bundles and updates it) | The Unlicense (public domain) | https://github.com/yt-dlp/yt-dlp |
| FFmpeg (the ffmpeg module) | LGPL-2.1-or-later or GPL-2.0-or-later, depending on the build options | https://ffmpeg.org/legal.html |
| aria2 (the aria2c binary) | GPL-2.0-or-later with the OpenSSL exception | https://aria2.github.io |
| AndroidX, Material Components, Kotlin coroutines | Apache License 2.0 | https://developer.android.com |

The exact license of the FFmpeg and aria2 binaries depends on how the library release was built. Check the
release notes of the youtubedl-android version used (`0.18.1` for the library and aria2c, `0.17.2` for ffmpeg)
before each public release.

**Feature ideas.** Some features (the filename template, split by chapters, safe file names, extra yt-dlp
options, settings backup, download history, SponsorBlock categories) were inspired by YTDLnis
(https://github.com/deniscerri/ytdlnis, GPL-3.0). YtClip's code for them was written separately; no code was copied.
