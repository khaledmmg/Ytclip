package com.example.ytclip

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.IBinder
import androidx.core.app.NotificationCompat

/** Keeps the app alive (and shows a progress notification) while downloads run. */
class KeepAliveService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "cancel") {
            onCancel?.invoke()
            stopSelf()
            return START_NOT_STICKY
        }
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CH, "Downloads", NotificationManager.IMPORTANCE_LOW))
        startForeground(ID, build(this, "Starting…", null), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        return START_NOT_STICKY
    }

    companion object {
        const val CH = "ytclip_downloads"
        const val ID = 1
        var onCancel: (() -> Unit)? = null

        fun build(c: Context, text: String, pct: Int?, done: Boolean = false, uri: Uri? = null, mime: String? = null): Notification {
            val open = if (done && uri != null) {
                PendingIntent.getActivity(
                    c, uri.hashCode(),
                    Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime ?: "video/*")
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK),
                    PendingIntent.FLAG_IMMUTABLE
                )
            } else {
                PendingIntent.getActivity(
                    c, 0, Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
                    PendingIntent.FLAG_IMMUTABLE
                )
            }
            val b = NotificationCompat.Builder(c, CH)
                .setContentTitle("YtClip").setContentText(text).setContentIntent(open)
                .setOnlyAlertOnce(true).setOngoing(!done)
            if (done) {
                b.setSmallIcon(android.R.drawable.stat_sys_download_done).setAutoCancel(true)
                if (uri != null) {
                    b.addAction(
                        0, "Share",
                        PendingIntent.getActivity(
                            c, uri.hashCode() + 1,
                            Intent.createChooser(
                                Intent(Intent.ACTION_SEND).setType(mime ?: "video/*").putExtra(Intent.EXTRA_STREAM, uri)
                                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), null
                            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                            PendingIntent.FLAG_IMMUTABLE
                        )
                    )
                }
            } else {
                b.setSmallIcon(android.R.drawable.stat_sys_download).setProgress(100, pct ?: 0, pct == null)
                b.addAction(
                    0, "Cancel",
                    PendingIntent.getService(
                        c, 1, Intent(c, KeepAliveService::class.java).setAction("cancel"),
                        PendingIntent.FLAG_IMMUTABLE
                    )
                )
            }
            return b.build()
        }
    }
}
