package com.example.ytclip

import android.app.Application
import android.app.NotificationManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.webkit.CookieManager
import android.webkit.MimeTypeMap
import android.webkit.WebStorage
import androidx.core.content.ContextCompat
import com.yausername.aria2c.Aria2c
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.util.Collections

/**
 * The download engine. It lives for the whole process, so rotating the phone, changing the theme
 * or closing the screen never loses a running download.
 */
object DL {
    enum class St { QUEUED, RUNNING, PAUSED, FAILED }

    class Opts(
        val audio: Boolean, val h: Int, val trim: Boolean, val a: Int, val bEnd: Int, val accurate: Boolean,
        val subLang: String?, val embedSubs: Boolean, val thumb: Boolean, val skipVideo: Boolean,
        val sponsor: Boolean, val afmt: String, val abr: String
    )

    class Task(
        val id: Int, val link: String, var title: String, var thumb: Bitmap?, val o: Opts,
        val job: Deferred<File>?, var info: File?, val dir: File
    ) {
        @Volatile var st = St.QUEUED
        @Volatile var busy = false
        @Volatile var gone = false
        @Volatile var pct = -1f
        @Volatile var speed = ""
        @Volatile var eta = -1L
        @Volatile var stage = 0
        @Volatile var err = ""
        @Volatile var phase = ""
        @Volatile var errFull = ""
        @Volatile var duration = 0
        val pid get() = "ytclip-task-$id"
    }

    class Saved(val name: String, val uri: Uri?, val mime: String)
    class Entry(val url: String, val title: String)

    private class InfoJob(val job: Deferred<File>, val ts: Long, val pid: String)

    lateinit var app: Application
    val tasks = mutableListOf<Task>()
    var onChange: (() -> Unit)? = null
    var onSaved: (() -> Unit)? = null
    var nextId = 1
    @Volatile var ready = false
    @Volatile var turboOk = false
    @Volatile var version = ""

    private var starting = false
    private var svcRunning = false
    private var lastUi = 0L
    private var lastNotif = 0L
    private val waiting = mutableListOf<(String?) -> Unit>()
    private val infos = LinkedHashMap<String, InfoJob>()
    private val killed: MutableSet<String> = Collections.synchronizedSet(HashSet())
    private val main = Handler(Looper.getMainLooper())
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    val prefs: SharedPreferences get() = app.getSharedPreferences("ytclip", Context.MODE_PRIVATE)
    val cookieFile: File get() = File(app.filesDir, "cookies.txt")

    // =====================  engine  =====================

    fun attach(ctx: Context) { app = ctx.applicationContext as Application }

    fun boot(ctx: Context, status: (String) -> Unit, done: (String?) -> Unit) {
        app = ctx.applicationContext as Application
        KeepAliveService.onCancel = { main.post { cancelAll() } }
        if (ready) { done(null); return }
        waiting += done
        if (starting) return
        starting = true
        scope.launch {
            var err: String? = null
            try {
                val due = System.currentTimeMillis() - prefs.getLong("upd", 0L) > 24 * 3600 * 1000L
                withContext(Dispatchers.IO) {
                    YoutubeDL.getInstance().init(app)
                    FFmpeg.getInstance().init(app)
                    turboOk = runCatching { Aria2c.getInstance().init(app) }.isSuccess
                    if (due) { // update yt-dlp at most once a day
                        main.post { status("Updating engine…") }
                        runCatching { YoutubeDL.getInstance().updateYoutubeDL(app, YoutubeDL.UpdateChannel.STABLE) }
                            .onSuccess { prefs.edit().putLong("upd", System.currentTimeMillis()).apply() }
                    }
                }
                ready = true
                bgTasks()
            } catch (e: Exception) {
                err = msgOf(e)
            }
            starting = false
            val cbs = waiting.toList()
            waiting.clear()
            cbs.forEach { it(err) }
        }
    }

    private fun destroy(pid: String) {
        killed += pid
        YoutubeDL.getInstance().destroyProcessById(pid)
    }

    // =====================  engine version / warm-up  =====================

    private fun readVersion(): String {
        val r = YoutubeDLRequest(emptyList<String>()).apply { addOption("--version") }
        return YoutubeDL.getInstance().execute(r, "ytclip-ver") { _, _, _ -> }.out.trim().lines().lastOrNull().orEmpty()
    }

    fun updateEngine(): String {
        YoutubeDL.getInstance().updateYoutubeDL(app, YoutubeDL.UpdateChannel.STABLE)
        prefs.edit().putLong("upd", System.currentTimeMillis()).apply()
        version = readVersion()
        return version
    }

    /** Reads the engine version and pre-processes YouTube's current player once, so the first real video is quick. */
    private fun bgTasks() {
        scope.launch(Dispatchers.IO) {
            version = runCatching { readVersion() }.getOrDefault("")
            main.post { change() }
            if (System.currentTimeMillis() - prefs.getLong("warm", 0L) > 12 * 3600_000L) {
                runCatching { extract("https://www.youtube.com/watch?v=jNQXAC9IVRw", "ytclip-warm", false) }
                    .onSuccess { it.delete(); prefs.edit().putLong("warm", System.currentTimeMillis()).apply() }
            }
        }
    }

    // =====================  Google account  =====================

    fun signedIn() = CookieManager.getInstance().getCookie("https://www.youtube.com")
        ?.let { "SAPISID" in it || "__Secure-3PSID" in it } == true

    fun imported() = prefs.getBoolean("cookies_imported", false) && cookieFile.exists()
    fun linked() = signedIn() || imported()

    fun importCookies(uri: Uri) {
        app.contentResolver.openInputStream(uri)?.use { cookieFile.writeBytes(it.readBytes()) }
        prefs.edit().putBoolean("cookies_imported", true).apply()
    }

    fun signOut() {
        CookieManager.getInstance().removeAllCookies(null)
        CookieManager.getInstance().flush()
        WebStorage.getInstance().deleteAllData()
        cookieFile.delete()
        prefs.edit().putBoolean("cookies_imported", false).apply()
    }

    /** Path of a cookies file for yt-dlp, or null when no account should be used. */
    fun cookiesArg(): String? {
        if (!prefs.getBoolean("use_account", true)) return null
        if (imported()) return cookieFile.absolutePath
        if (!signedIn()) return null
        return runCatching {
            val sb = StringBuilder("# Netscape HTTP Cookie File\n")
            val cm = CookieManager.getInstance()
            for ((u, dom) in listOf(
                "https://www.youtube.com" to ".youtube.com", "https://accounts.google.com" to ".google.com",
                "https://www.google.com" to ".google.com"
            )) {
                cm.getCookie(u)?.split(";")?.forEach { c ->
                    val i = c.indexOf('=')
                    if (i > 0) sb.append("$dom\tTRUE\t/\tTRUE\t2147483647\t${c.substring(0, i).trim()}\t${c.substring(i + 1).trim()}\n")
                }
            }
            cookieFile.writeText(sb.toString())
            cookieFile.absolutePath
        }.getOrNull()
    }

    // =====================  reading video details (cached, prefetched)  =====================

    private val fulls = LinkedHashMap<String, InfoJob>()

    fun fastMode() = prefs.getBoolean("fast", true) && cookiesArg() == null

    /** Quick read (Android VR client): few qualities, but ready in seconds. */
    fun info(link: String): Deferred<File> = jobFor(infos, link, "ytclip-info") { pid -> extract(link, pid, fastMode()) }

    /** Complete read with the default clients: every quality, but slower. */
    fun infoFull(link: String): Deferred<File> = jobFor(fulls, link, "ytclip-full") { pid -> extract(link, pid, false) }

    private fun jobFor(map: LinkedHashMap<String, InfoJob>, link: String, prefix: String, work: (String) -> File): Deferred<File> =
        synchronized(map) {
            val old = map[link]
            if (old != null && System.currentTimeMillis() - old.ts < 3 * 3600_000L) {
                old.job
            } else {
                while (map.size >= 4) {
                    val k = map.keys.first()
                    map.remove(k)?.let { if (!it.job.isCompleted) { destroy(it.pid); it.job.cancel() } }
                }
                val pid = "$prefix-${link.hashCode()}"
                val job = scope.async(Dispatchers.IO) {
                    try {
                        work(pid)
                    } catch (e: Exception) {
                        synchronized(map) { map.remove(link) }
                        throw e
                    }
                }
                map[link] = InfoJob(job, System.currentTimeMillis(), pid)
                job
            }
        }

    /** The library adds --no-cache-dir unless we give a folder: without a cache YouTube's player is re-processed every time (minutes). */
    private val ytCache: String get() = File(app.filesDir, "ytdlp-cache").apply { mkdirs() }.absolutePath

    private fun common(r: YoutubeDLRequest, fast: Boolean) {
        r.addOption("--cache-dir", ytCache)
        r.addOption("--socket-timeout", "20")
        r.addOption("--retries", "3")
        r.addOption("--extractor-retries", "2")
        // The Android VR client needs no JavaScript solving and no login: far quicker than the default list.
        if (fast) r.addOption("--extractor-args", "youtube:player_client=android_vr")
        cookiesArg()?.let { r.addOption("--cookies", it) }
    }

    private fun extract(link: String, pid: String, fast: Boolean): File {
        fun go(f: Boolean): String {
            val r = YoutubeDLRequest(link).apply {
                addOption("--dump-single-json")
                addOption("--no-playlist")
                addOption("--no-warnings")
                common(this, f)
            }
            return YoutubeDL.getInstance().execute(r, pid) { _, _, _ -> }.out
        }
        val out = try {
            go(fast)
        } catch (e: Exception) {
            if (fast && pid !in killed) go(false) else throw e
        }
        val json = out.lines().lastOrNull { it.trimStart().startsWith("{") } ?: error("No video details were returned")
        return File(app.cacheDir, "info-${System.currentTimeMillis()}.json").apply { writeText(json) }
    }

    // =====================  queue  =====================

    fun add(t: Task) { tasks.add(0, t); change(); pump() }
    fun active() = tasks.any { it.st == St.RUNNING || it.st == St.QUEUED }
    fun change() { runCatching { onChange?.invoke() } }

    private fun postChange() {
        val n = System.currentTimeMillis()
        if (n - lastUi < 250) return
        lastUi = n
        main.post { change() }
    }

    fun pump() {
        val max = prefs.getInt("parallel", 0) + 1
        var running = tasks.count { it.st == St.RUNNING }
        for (t in tasks.reversed()) { // oldest first
            if (running >= max) break
            if (t.st == St.QUEUED && !t.busy) { running++; begin(t) }
        }
        runCatching {
            val svc = Intent(app, KeepAliveService::class.java)
            if (active()) {
                if (!svcRunning) { ContextCompat.startForegroundService(app, svc); svcRunning = true }
            } else if (svcRunning) {
                app.stopService(svc); svcRunning = false
            }
        }
    }

    private fun begin(t: Task) {
        t.st = St.RUNNING; t.busy = true; t.err = ""; t.phase = ""
        killed.remove(t.pid)
        scope.launch {
            try {
                if (prefs.getBoolean("wifi", false) && !onWifi()) {
                    t.st = St.PAUSED; t.err = "Waiting for Wi‑Fi — tap ▶ to continue"
                    return@launch
                }
                if (t.info == null && t.o.subLang == null) {
                    t.phase = "Reading video details…"; change()
                    t.info = runCatching { t.job?.await() }.getOrNull()
                }
                val s = withContext(Dispatchers.IO) { runTask(t) }
                tasks.remove(t)
                t.dir.deleteRecursively()
                notifyDone("Saved ✓  ${s.name}", s.uri, s.mime)
                runCatching { onSaved?.invoke() }
            } catch (e: Exception) {
                when {
                    t.gone -> tasks.remove(t)
                    t.st != St.RUNNING -> {} // paused by the user
                    else -> { t.st = St.FAILED; t.err = msgOf(e); t.errFull = (e.message ?: e.toString()).takeLast(6000) }
                }
            } finally {
                t.busy = false
                if (t.gone) t.dir.deleteRecursively()
                change(); pump()
            }
        }
    }

    fun pause(t: Task) {
        if (t.st != St.RUNNING && t.st != St.QUEUED) return
        t.st = St.PAUSED; t.err = ""
        destroy(t.pid)
        change(); pump()
    }

    fun resume(t: Task) { t.st = St.QUEUED; t.err = ""; change(); pump() }

    fun cancel(t: Task) {
        t.gone = true
        destroy(t.pid)
        if (!t.busy) { tasks.remove(t); t.dir.deleteRecursively() }
        change(); pump()
    }

    fun cancelAll() { tasks.toList().forEach { cancel(it) } }
    fun pauseAll() { tasks.toList().forEach { pause(it) } }
    fun resumeAll() { tasks.toList().forEach { if (it.st == St.PAUSED || it.st == St.FAILED) resume(it) } }

    private fun onWifi(): Boolean {
        val cm = app.getSystemService(ConnectivityManager::class.java)
        val c = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) || c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
    }

    fun folderName(): String = (prefs.getString("folder", "YtClip") ?: "YtClip")
        .replace(Regex("[^A-Za-z0-9 _-]"), "").trim().ifEmpty { "YtClip" }

    // =====================  playlists  =====================

    /** Lists a playlist quickly (titles only, no per-video reading). */
    fun playlist(link: String): Pair<String, List<Entry>> {
        val r = YoutubeDLRequest(link).apply {
            addOption("--flat-playlist")
            addOption("--dump-single-json")
            addOption("--no-warnings")
            addOption("--playlist-end", "200")
            common(this, false)
        }
        val out = YoutubeDL.getInstance().execute(r, "ytclip-playlist") { _, _, _ -> }.out
        val json = out.lines().lastOrNull { it.trimStart().startsWith("{") } ?: error("Couldn't read the playlist")
        val j = JSONObject(json)
        val arr = j.optJSONArray("entries") ?: error("This link is not a playlist")
        val list = ArrayList<Entry>()
        for (i in 0 until arr.length()) {
            val e = arr.optJSONObject(i) ?: continue
            val id = e.optString("id")
            val u = e.optString("url").takeIf { it.startsWith("http") }
                ?: if (id.isNotEmpty()) "https://www.youtube.com/watch?v=$id" else continue
            list += Entry(u, e.optString("title").ifEmpty { u })
        }
        return Pair(j.optString("title").ifEmpty { "Playlist" }, list)
    }

    // =====================  one download  =====================

    private val timeRe = Regex("""time=(\d+):(\d+):(\d+)""")
    private val speedRe = Regex("""at\s+([\d.]+\s?\w+/s)""")
    private val ariaRe = Regex("""\[#\w+\s+[\d.]+\w+/[\d.]+\w+\((\d+)%\)\s+CN:\d+\s+DL:([\d.]+\w+)(?:\s+ETA:(\S+?))?\]""")

    private fun etaSecs(s: String?): Long {
        if (s.isNullOrEmpty()) return -1L
        var t = 0L
        Regex("""(\d+)([hms])""").findAll(s).forEach { m ->
            val v = m.groupValues[1].toLong()
            t += when (m.groupValues[2]) { "h" -> v * 3600; "m" -> v * 60; else -> v }
        }
        return t
    }

    private fun runTask(t: Task): Saved {
        if (t.st != St.RUNNING) error("stopped")
        val o = t.o
        val infoOk = o.subLang == null // the quick details contain no caption list
        t.info?.takeIf { infoOk }?.let { f ->
            runCatching {
                val j = JSONObject(f.readText())
                j.optString("title").takeIf { it.isNotEmpty() }?.let { t.title = it }
                if (t.duration == 0) t.duration = j.optInt("duration", 0)
            }
        }
        val conn = listOf(1, 4, 8)[prefs.getInt("threads", 1).coerceIn(0, 2)]
        val rate = listOf("", "1M", "2M", "5M")[prefs.getInt("speed", 0).coerceIn(0, 3)]
        val codec = if (o.h <= 1080) "h264" else "vp9"
        val embed = prefs.getBoolean("embed", true)
        val fast = prefs.getBoolean("fast", true) && infoOk && cookiesArg() == null
        val turbo = turboOk && prefs.getBoolean("turbo", true)

        // rich = first attempt (quick client, turbo downloader, tags); the retry is plain and safe
        fun build(withInfo: Boolean, rich: Boolean): YoutubeDLRequest {
            val f = t.info?.takeIf { withInfo && infoOk && it.exists() }
            return (if (f != null) YoutubeDLRequest(emptyList<String>()) else YoutubeDLRequest(t.link)).apply {
                if (f != null) addOption("--load-info-json", f.absolutePath)
                addOption("--no-playlist")
                addOption("-N", conn.toString())
                if (rate.isNotEmpty()) addOption("--limit-rate", rate)
                common(this, rich && fast && f == null)
                if (rich && turbo && !o.trim && !o.skipVideo) {
                    addOption("--downloader", "libaria2c.so") // up to 16 connections per file
                }
                val tag = if (o.audio || o.skipVideo) "" else " (%(height)sP)"
                addOption("-o", "${t.dir.absolutePath}/%(title).80s$tag.%(ext)s")
                if (o.skipVideo) {
                    addOption("--skip-download")
                } else if (o.audio) {
                    addOption("-f", if (o.afmt == "m4a") "ba[ext=m4a]/ba/b" else "ba/b")
                    addOption("-x")
                    addOption("--audio-format", o.afmt)
                    if (o.abr.isNotEmpty()) addOption("--audio-quality", o.abr) // e.g. 128K / 320K
                } else {
                    addOption("-f", "bv*+ba[ext=m4a]/bv*+ba/b")
                    addOption("-S", "res:${o.h},vcodec:$codec,acodec:aac") // res = smallest side (portrait-safe)
                    addOption("--merge-output-format", "mp4")
                }
                if (o.trim && !o.skipVideo) {
                    addOption("--download-sections", "*${o.a}-${if (o.bEnd > 0) o.bEnd.toString() else "inf"}")
                    if (o.accurate) addOption("--force-keyframes-at-cuts")
                }
                if (o.subLang != null) {
                    addOption("--write-subs")
                    addOption("--write-auto-subs")
                    addOption("--sub-langs", o.subLang)
                    addOption("--sub-format", "srt/best")
                    addOption("--convert-subs", "srt")
                    if (o.embedSubs && !o.skipVideo && !o.audio) addOption("--embed-subs")
                }
                if (rich && o.thumb && !o.skipVideo) { // cover art goes inside the file; no separate image
                    addOption("--embed-thumbnail")
                    addOption("--convert-thumbnails", "jpg")
                }
                if (rich && embed && !o.skipVideo) {
                    addOption("--embed-metadata")
                    if (!o.trim) addOption("--embed-chapters")
                }
                if (rich && o.sponsor && !o.trim && !o.skipVideo) {
                    addOption("--sponsorblock-remove", "sponsor,selfpromo,interaction,intro,outro")
                }
            }
        }

        val clipLen = if (!o.trim) 0 else (if (o.bEnd > 0) o.bEnd else t.duration) - o.a
        val onLine: (Float, Long, String) -> Unit = { pct, eta, line ->
            if (line.contains("Destination:")) t.stage++
            val l = line.trimStart()
            t.phase = when {
                l.startsWith("[Merger]") || l.startsWith("[Fixup") -> "Merging…"
                l.startsWith("[ExtractAudio]") -> "Converting audio…"
                l.startsWith("[EmbedSubtitle]") || l.startsWith("[SubtitlesConvertor]") -> "Subtitles…"
                l.startsWith("[ThumbnailsConvertor]") || l.startsWith("[EmbedThumbnail]") -> "Cover art…"
                l.startsWith("[Metadata]") || l.startsWith("[ModifyChapters]") || l.startsWith("[SponsorBlock]") -> "Tags & chapters…"
                l.startsWith("[youtube]") -> "Reading video details…"
                l.startsWith("[info]") -> "Starting download…"
                else -> t.phase
            }
            val tm = timeRe.find(line)
            val ar = ariaRe.find(line)
            val frac: Float? = when {
                o.trim && tm != null && clipLen > 0 -> {
                    val (hh, mm, ss) = tm.destructured
                    (hh.toInt() * 3600 + mm.toInt() * 60 + ss.toInt()) * 100f / clipLen
                }
                o.trim -> null
                ar != null -> ar.groupValues[1].toFloat()
                pct >= 0f -> pct
                else -> null
            }
            t.pct = frac ?: -1f
            t.eta = if (o.trim) -1L else if (ar != null) etaSecs(ar.groupValues[3]) else eta
            if (!o.trim) {
                val sp = if (ar != null) ar.groupValues[2] + "/s" else speedRe.find(line)?.groupValues?.get(1)
                if (sp != null) t.speed = sp
            }
            postChange()
            notifyProgress(t)
        }

        if (t.st != St.RUNNING) error("stopped")
        try {
            YoutubeDL.getInstance().execute(build(true, true), t.pid, onLine)
        } catch (e: Exception) {
            if (t.gone || t.st != St.RUNNING || t.pid in killed) throw e
            t.stage = 0; t.phase = "Retrying safely…" // quick client / turbo / tags failed: plain run
            t.speed = ""
            YoutubeDL.getInstance().execute(build(false, false), t.pid, onLine)
        }
        return save(t)
    }

    private fun save(t: Task): Saved {
        val o = t.o
        val files = t.dir.listFiles()?.filter {
            it.isFile && !it.name.endsWith(".part") && !it.name.endsWith(".ytdl") && !it.name.endsWith(".temp")
        } ?: emptyList()
        if (files.isEmpty()) error(if (o.subLang != null) "No subtitles found for that language" else "No output file was produced")
        val folder = folderName()
        var primary = ""
        var pUri: Uri? = null
        var pMime = "video/mp4"
        var hasSubs = false
        for (f in files) {
            val ext = f.extension.lowercase()
            val mt = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
            val coll: Uri
            val mime: String
            val path: String
            when (ext) {
                "mp4", "mkv", "webm", "mov" -> { coll = MediaStore.Video.Media.EXTERNAL_CONTENT_URI; mime = mt ?: "video/mp4"; path = "${Environment.DIRECTORY_MOVIES}/$folder" }
                "m4a", "mp3", "opus", "ogg", "aac", "flac", "wav" -> { coll = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI; mime = if (ext == "m4a") "audio/mp4" else mt ?: (if (ext == "opus") "audio/ogg" else "audio/mpeg"); path = "${Environment.DIRECTORY_MUSIC}/$folder" }
                "srt", "vtt", "ass", "lrc" -> { coll = MediaStore.Downloads.EXTERNAL_CONTENT_URI; mime = if (ext == "vtt") "text/vtt" else "application/x-subrip"; path = "${Environment.DIRECTORY_DOWNLOADS}/$folder"; hasSubs = true }
                "jpg", "jpeg", "png", "webp" -> { coll = MediaStore.Images.Media.EXTERNAL_CONTENT_URI; mime = mt ?: "image/jpeg"; path = "${Environment.DIRECTORY_PICTURES}/$folder" }
                else -> continue
            }
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, f.name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, path)
            }
            val uri = app.contentResolver.insert(coll, values) ?: error("Could not create the file")
            app.contentResolver.openOutputStream(uri)!!.use { out -> f.inputStream().use { it.copyTo(out) } }
            val isMedia = coll == MediaStore.Video.Media.EXTERNAL_CONTENT_URI || coll == MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            if (primary.isEmpty() || isMedia) { primary = f.name; pUri = uri; pMime = mime }
        }
        if (primary.isEmpty()) error("No output file was produced")
        if (hasSubs || (o.subLang != null && o.embedSubs && !o.skipVideo)) {
            val set = (prefs.getStringSet("cc", emptySet()) ?: emptySet()).toMutableSet()
            set += primary.substringBeforeLast('.')
            prefs.edit().putStringSet("cc", set).apply()
        }
        return Saved(primary, pUri, pMime)
    }

    // =====================  notifications  =====================

    private var doneId = 100

    private fun notifyProgress(t: Task) {
        val now = System.currentTimeMillis()
        if (now - lastNotif < 1000) return
        lastNotif = now
        val n = tasks.count { it.st == St.RUNNING }
        val text = if (n > 1) "Downloading $n files" else t.title
        runCatching {
            app.getSystemService(NotificationManager::class.java).notify(
                KeepAliveService.ID,
                KeepAliveService.build(app, text, if (t.pct >= 0) t.pct.toInt().coerceAtMost(100) else null)
            )
        }
    }

    private fun notifyDone(text: String, uri: Uri? = null, mime: String? = null) {
        runCatching {
            app.getSystemService(NotificationManager::class.java)
                .notify(doneId++, KeepAliveService.build(app, text, null, true, uri, mime))
        }
    }
}
