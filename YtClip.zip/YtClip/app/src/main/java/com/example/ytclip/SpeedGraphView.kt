package com.example.ytclip

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import com.google.android.material.color.MaterialColors

/** A small live graph of the total download speed (last ~48 seconds). */
class SpeedGraphView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {
    private val samples = ArrayDeque<Long>()
    private val maxSamples = 48
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)

    fun push(v: Long) {
        samples.addLast(v)
        while (samples.size > maxSamples) samples.removeFirst()
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (samples.isEmpty() || w <= 0f || h <= 0f) return
        val col = MaterialColors.getColor(this, com.google.android.material.R.attr.colorPrimary)
        val peak = (samples.maxOrNull() ?: 1L).coerceAtLeast(1L).toFloat()
        val step = w / (maxSamples - 1)
        val area = Path()
        val line = Path()
        var x = w - step * (samples.size - 1)
        samples.forEachIndexed { i, v ->
            val ratio = (v.toFloat() / peak).coerceIn(0f, 1f)
            val y = h - ratio * (h - 8f) - 4f
            if (i == 0) { area.moveTo(x, h); area.lineTo(x, y); line.moveTo(x, y) } else { area.lineTo(x, y); line.lineTo(x, y) }
            x += step
        }
        area.lineTo(x - step, h)
        area.close()
        fill.style = Paint.Style.FILL
        fill.shader = LinearGradient(0f, 0f, 0f, h, (col and 0x00FFFFFF) or 0x66000000, col and 0x00FFFFFF, Shader.TileMode.CLAMP)
        canvas.drawPath(area, fill)
        stroke.style = Paint.Style.STROKE
        stroke.strokeWidth = 3f
        stroke.strokeJoin = Paint.Join.ROUND
        stroke.strokeCap = Paint.Cap.ROUND
        stroke.color = col
        canvas.drawPath(line, stroke)
    }
}
