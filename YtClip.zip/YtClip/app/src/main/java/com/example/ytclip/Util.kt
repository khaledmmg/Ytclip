package com.example.ytclip

fun fmt(s: Int): String {
    val h = s / 3600
    val m = s % 3600 / 60
    val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
}

fun fmtSize(b: Long): String =
    if (b >= (1L shl 30)) "%.1f GB".format(b / 1073741824.0) else "%d MB".format(maxOf(1L, b / 1048576))

fun extractUrl(t: String): String = Regex("""https?://\S+""").find(t)?.value ?: ""

fun msgOf(e: Throwable): String {
    val ls = e.message?.lines().orEmpty().filter { it.isNotBlank() }
    return (ls.lastOrNull { "ERROR" in it } ?: ls.firstOrNull() ?: "Unknown error").take(180)
}
