package com.example.ytclip

fun fmt(s: Int): String {
    val h = s / 3600
    val m = s % 3600 / 60
    val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
}

fun fmtSize(b: Long): String = when {
    b >= (1L shl 30) -> "%.1f GB".format(b / 1073741824.0)
    b >= (1L shl 20) -> "%.1f MB".format(b / 1048576.0)
    else -> "%d KB".format(maxOf(1L, b / 1024))
}

fun extractUrl(t: String): String = Regex("""https?://\S+""").find(t)?.value ?: ""

fun msgOf(e: Throwable): String {
    val ls = e.message?.lines().orEmpty().filter { it.isNotBlank() }
    return (ls.lastOrNull { "ERROR" in it } ?: ls.firstOrNull() ?: "Unknown error").take(180)
}

/** "2.35MiB/s", "512KiB/s", "1.2MB/s" → bytes per second. */
fun parseSpeed(s: String): Long {
    val m = Regex("""([\d.]+)\s*([KMGT]?)i?B""", RegexOption.IGNORE_CASE).find(s) ?: return 0L
    val v = m.groupValues[1].toDoubleOrNull() ?: return 0L
    val mul = when (m.groupValues[2].uppercase()) { "K" -> 1024.0; "M" -> 1048576.0; "G" -> 1073741824.0; "T" -> 1099511627776.0; else -> 1.0 }
    return (v * mul).toLong()
}

fun fmtSpeed(b: Long): String = when {
    b >= (1L shl 20) -> "%.1f MB/s".format(b / 1048576.0)
    b >= (1L shl 10) -> "%d KB/s".format(b / 1024)
    else -> "0 KB/s"
}
