package com.example.ytclip

import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.View
import android.view.WindowManager
import android.webkit.MimeTypeMap
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.chip.ChipGroup
import com.google.android.material.color.DynamicColors
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.progressindicator.LinearProgressIndicator
import com.google.android.material.slider.RangeSlider
import com.google.android.material.textfield.TextInputEditText
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.net.URL

class MainActivity : AppCompatActivity() {

    private val pid = "ytclip-download"
    private val timeRe = Regex("""time=(\d+):(\d+):(\d+)""")
    private var ready = false
    private var cancelled = false
    private var link = ""
    private var duration = 0
    private var savedUri: Uri? = null
    private var savedMime = "video/mp4"

    private fun <T : View> v(id: Int): T = findViewById(id)
    private val scroll by lazy { v<ScrollView>(R.id.scroll) }
    private val hintView by lazy { v<TextView>(R.id.hintView) }
    private val url by lazy { v<TextInputEditText>(R.id.url) }
    private val pasteBtn by lazy { v<View>(R.id.pasteBtn) }
    private val fetchBtn by lazy { v<android.widget.Button>(R.id.fetchBtn) }
    private val previewCard by lazy { v<View>(R.id.previewCard) }
    private val thumb by lazy { v<ImageView>(R.id.thumb) }
    private val titleView by lazy { v<TextView>(R.id.titleView) }
    private val metaView by lazy { v<TextView>(R.id.metaView) }
    private val optionsCard by lazy { v<View>(R.id.optionsCard) }
    private val qualityGroup by lazy { v<ChipGroup>(R.id.qualityGroup) }
    private val trimSwitch by lazy { v<MaterialSwitch>(R.id.trimSwitch) }
    private val trimBox by lazy { v<LinearLayout>(R.id.trimBox) }
    private val trimLabel by lazy { v<TextView>(R.id.trimLabel) }
    private val range by lazy { v<RangeSlider>(R.id.range) }
    private val precise by lazy { v<CheckBox>(R.id.precise) }
    private val downloadBtn by lazy { v<View>(R.id.downloadBtn) }
    private val progressCard by lazy { v<View>(R.id.progressCard) }
    private val status by lazy { v<TextView>(R.id.status) }
    private val bar by lazy { v<LinearProgressIndicator>(R.id.bar) }
    private val details by lazy { v<TextView>(R.id.details) }
    private val cancelBtn by lazy { v<View>(R.id.cancelBtn) }
    private val openBtn by lazy { v<View>(R.id.openBtn) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DynamicColors.applyToActivityIfAvailable(this)
        setContentView(R.layout.activity_main)

        if (intent.action == Intent.ACTION_SEND) {
            intent.getStringExtra(Intent.EXTRA_TEXT)?.let { url.setText(extractUrl(it)) }
        }

        range.setLabelFormatter { fmt(it.toInt()) }
        range.addOnChangeListener { _, _, _ -> updateTrim() }
        trimSwitch.setOnCheckedChangeListener { _, on ->
            trimBox.visibility = if (on) View.VISIBLE else View.GONE
            updateTrim()
        }

        pasteBtn.setOnClickListener {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            val t = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)
                ?.coerceToText(this)?.toString().orEmpty()
            url.setText(extractUrl(t).ifEmpty { t })
            fetch()
        }
        fetchBtn.setOnClickListener { fetch() }

        downloadBtn.setOnClickListener {
            if (link.isEmpty()) return@setOnClickListener say("Fetch a link first.")
            val trim = trimSwitch.isChecked
            val (a, b) = range.values.map { it.toInt() }
            if (trim && b <= a) return@setOnClickListener say("The end time must be after the start time.")
            startDownload(qualityGroup.checkedChipId, trim, a, b, precise.isChecked)
        }
        cancelBtn.setOnClickListener {
            cancelled = true
            YoutubeDL.getInstance().destroyProcessById(pid)
        }
        openBtn.setOnClickListener {
            val u = savedUri ?: return@setOnClickListener
            runCatching {
                startActivity(
                    Intent(Intent.ACTION_VIEW).setDataAndType(u, savedMime)
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                )
            }
        }

        // Start the engine, update yt-dlp (YouTube changes often), then continue
        lifecycleScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    YoutubeDL.getInstance().init(application)
                    FFmpeg.getInstance().init(application)
                    say("Checking for updates…", false)
                    runCatching {
                        YoutubeDL.getInstance().updateYoutubeDL(application, YoutubeDL.UpdateChannel.STABLE)
                    }
                }
                ready = true
                say("Ready. Paste a YouTube link to begin.", false)
                if (url.text?.isNotBlank() == true) fetch()
            } catch (e: Exception) {
                say("Startup failed: ${msg(e)}")
            }
        }
    }

    /** Load title, thumbnail and length for the link. */
    private fun fetch() {
        val l = extractUrl(url.text.toString())
        if (l.isEmpty()) return say("Paste a YouTube link first.")
        if (!ready) return say("The engine is still starting. Try again in a moment.")
        lifecycleScope.launch {
            fetchBtn.isEnabled = false
            fetchBtn.text = "Loading…"
            previewCard.visibility = View.GONE
            optionsCard.visibility = View.GONE
            try {
                val info = withContext(Dispatchers.IO) { YoutubeDL.getInstance().getInfo(l) }
                link = l
                duration = info.duration ?: 0
                titleView.text = info.title ?: "Video"
                metaView.text = if (duration > 0) "Length ${fmt(duration)}" else "Live or unknown length"
                previewCard.visibility = View.VISIBLE
                setupTrim()
                optionsCard.visibility = View.VISIBLE
                say("Choose a quality, then tap Download.", false)
                val bmp = withContext(Dispatchers.IO) {
                    runCatching { URL(info.thumbnail).openStream().use { BitmapFactory.decodeStream(it) } }.getOrNull()
                }
                bmp?.let { thumb.setImageBitmap(it) }
            } catch (e: Exception) {
                say("Couldn't load this link. ${msg(e)}")
            } finally {
                fetchBtn.isEnabled = true
                fetchBtn.text = "Fetch"
            }
        }
    }

    private fun setupTrim() {
        val can = duration > 1
        trimSwitch.isEnabled = can
        trimSwitch.isChecked = false
        trimBox.visibility = View.GONE
        if (can) {
            range.valueFrom = 0f
            range.valueTo = duration.toFloat()
            range.stepSize = 1f
            range.values = listOf(0f, duration.toFloat())
        }
        updateTrim()
    }

    private fun updateTrim() {
        val (a, b) = range.values.map { it.toInt() }
        trimLabel.text = "${fmt(a)}  →  ${fmt(b)}    (clip ${fmt(b - a)})"
    }

    private fun startDownload(chip: Int, trim: Boolean, a: Int, b: Int, accurate: Boolean) =
        lifecycleScope.launch {
            cancelled = false
            setBusy(true)
            status.text = "Starting…"
            details.text = ""
            setBar(null)
            val t0 = System.currentTimeMillis()
            val ticker = launch {
                while (true) {
                    delay(1000)
                    if (bar.isIndeterminate)
                        details.text = "Elapsed " + fmt(((System.currentTimeMillis() - t0) / 1000).toInt())
                }
            }
            try {
                val r = withContext(Dispatchers.IO) { download(chip, trim, a, b, accurate) }
                savedUri = r.first
                savedMime = r.second
                setBar(100f)
                status.text = "Done ✓  Saved to ${r.third}"
                details.text = "You can find it in your gallery."
                openBtn.visibility = View.VISIBLE
            } catch (e: Exception) {
                status.text = if (cancelled) "Cancelled" else "Failed"
                details.text = if (cancelled) "" else msg(e)
            } finally {
                ticker.cancel()
                setBusy(false)
            }
        }

    /** Downloads (optionally only a section) and copies the result into Movies/YtClip or Music/YtClip. */
    private fun download(chip: Int, trim: Boolean, a: Int, b: Int, accurate: Boolean): Triple<Uri, String, String> {
        val dir = File(cacheDir, "dl/${System.currentTimeMillis()}").apply { mkdirs() }
        try {
            val audio = chip == R.id.qAudio
            val h = when (chip) { R.id.q1080 -> 1080; R.id.q720 -> 720; R.id.q480 -> 480; R.id.q360 -> 360; else -> 0 }
            val c = if (h > 0) "[height<=$h]" else ""
            val req = YoutubeDLRequest(link).apply {
                addOption("--no-playlist")
                addOption("-o", "${dir.absolutePath}/%(title).80s.%(ext)s")
                if (audio) {
                    addOption("-f", "ba[ext=m4a]/ba/b")
                    addOption("-x")
                    addOption("--audio-format", "m4a")
                } else {
                    addOption("-f", "bv*$c[ext=mp4]+ba[ext=m4a]/b$c[ext=mp4]/bv*$c+ba/b$c")
                    addOption("--merge-output-format", "mp4")
                }
                if (trim) {
                    addOption("--download-sections", "*$a-$b")
                    if (accurate) addOption("--force-keyframes-at-cuts")
                }
            }

            var stage = 0
            YoutubeDL.getInstance().execute(req, pid) { pct, eta, line ->
                if (line.contains("Destination:")) stage++
                val tm = timeRe.find(line)
                val frac: Float? = when {
                    trim && tm != null && b > a -> {
                        val (hh, mm, ss) = tm.destructured
                        (hh.toInt() * 3600 + mm.toInt() * 60 + ss.toInt()) * 100f / (b - a)
                    }
                    trim -> null
                    pct >= 0f -> pct
                    else -> null
                }
                val label = when {
                    audio -> "Downloading audio"
                    trim -> "Downloading your clip"
                    stage >= 2 -> "Downloading audio"
                    else -> "Downloading video"
                }
                runOnUiThread {
                    status.text = if (frac != null && frac >= 100f && (audio || trim || stage >= 2)) "Processing…" else label
                    setBar(frac)
                    if (frac != null) {
                        details.text = "${frac.toInt().coerceAtMost(100)}%" +
                            if (!trim && eta >= 0) "   •   ${fmt(eta.toInt())} left" else ""
                    }
                }
            }

            val file = dir.listFiles()
                ?.filter { !it.name.endsWith(".part") && !it.name.endsWith(".ytdl") }
                ?.maxByOrNull { it.length() } ?: error("No output file was produced")

            val mime = if (audio) "audio/mp4"
            else MimeTypeMap.getSingleton().getMimeTypeFromExtension(file.extension) ?: "video/mp4"
            val folder = if (audio) Environment.DIRECTORY_MUSIC else Environment.DIRECTORY_MOVIES
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, file.name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, "$folder/YtClip")
            }
            val coll = if (audio) MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            val uri = contentResolver.insert(coll, values) ?: error("Could not create the file")
            contentResolver.openOutputStream(uri)!!.use { out -> file.inputStream().use { it.copyTo(out) } }
            return Triple(uri, mime, "$folder/YtClip")
        } finally {
            dir.deleteRecursively()
        }
    }

    private fun setBar(frac: Float?) {
        if (frac == null) {
            if (!bar.isIndeterminate) bar.isIndeterminate = true
        } else {
            if (bar.isIndeterminate) bar.isIndeterminate = false
            bar.setProgressCompat(frac.coerceIn(0f, 100f).toInt(), true)
        }
    }

    private fun setBusy(busy: Boolean) {
        progressCard.visibility = View.VISIBLE
        downloadBtn.isEnabled = !busy
        fetchBtn.isEnabled = !busy
        pasteBtn.isEnabled = !busy
        cancelBtn.visibility = if (busy) View.VISIBLE else View.GONE
        if (busy) {
            openBtn.visibility = View.GONE
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    private fun say(m: String, toast: Boolean = true) = runOnUiThread {
        hintView.text = m
        if (toast) Toast.makeText(this, m, Toast.LENGTH_LONG).show()
    }

    private fun extractUrl(t: String) = Regex("""https?://\S+""").find(t)?.value ?: ""

    private fun fmt(s: Int): String {
        val h = s / 3600
        val m = s % 3600 / 60
        val sec = s % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
    }

    private fun msg(e: Exception): String {
        val ls = e.message?.lines().orEmpty().filter { it.isNotBlank() }
        return (ls.lastOrNull { "ERROR" in it } ?: ls.firstOrNull() ?: "Unknown error").take(180)
    }
}
