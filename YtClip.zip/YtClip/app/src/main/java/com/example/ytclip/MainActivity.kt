package com.example.ytclip

import android.Manifest
import android.content.ClipboardManager
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.text.InputFilter
import android.text.InputType
import android.util.LruCache
import android.util.Size
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.ytclip.databinding.ActivityMainBinding
import com.example.ytclip.databinding.ItemFileBinding
import com.example.ytclip.databinding.ItemTaskBinding
import com.google.android.material.button.MaterialButton
import com.google.android.material.chip.Chip
import com.google.android.material.color.MaterialColors
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.tabs.TabLayout
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : AppCompatActivity() {

    class Item(val uri: Uri, val name: String, val size: Long, val mime: String, val added: Long, val ms: Long)

    private lateinit var ui: ActivityMainBinding
    private val W = ViewGroup.LayoutParams.WRAP_CONTENT
    private val tasks get() = DL.tasks
    private var items = listOf<Item>()
    private var showQueue = true

    // download-sheet state
    private var link = ""
    private var gen = 0
    private var duration = 0
    private var selStart = 0
    private var selEnd = 0 // 0 = until the end of the video
    private var infoFile: File? = null
    private var infoJob: Deferred<File>? = null
    private var customSub = ""
    private lateinit var typeFields: List<EditText>

    private var browseUrl = ""
    private var pendingUrl: String? = null
    private var sharedLink = ""
    private var lastClip = ""
    private val refreshers = mutableListOf<() -> Unit>()
    private val thumbCache = LruCache<Uri, Bitmap>(60)
    private lateinit var taskAdapter: TaskAdapter
    private lateinit var fileAdapter: FileAdapter
    private val prefs by lazy { getSharedPreferences("ytclip", MODE_PRIVATE) }

    private val sites = listOf(
        "YouTube" to "https://m.youtube.com", "Facebook" to "https://m.facebook.com",
        "Instagram" to "https://www.instagram.com", "TikTok" to "https://www.tiktok.com", "X" to "https://x.com"
    )
    private val qBase = mapOf(
        R.id.qBest to "Best", R.id.q2160 to "4K", R.id.q1440 to "2K", R.id.q1080 to "1080p",
        R.id.q720 to "720p", R.id.q480 to "480p", R.id.q360 to "360p", R.id.qAudio to "Audio only"
    )
    private val qHeight = mapOf(
        R.id.q2160 to 2160, R.id.q1440 to 1440, R.id.q1080 to 1080,
        R.id.q720 to 720, R.id.q480 to 480, R.id.q360 to 360
    )
    private val qIds = listOf(R.id.qBest, R.id.q2160, R.id.q1440, R.id.q1080, R.id.q720, R.id.q480, R.id.q360, R.id.qAudio)
    private val bgPreview = listOf(0xFF141414, 0xFF000000, 0xFF0B1020, 0xFFFAFAFA).map { it.toInt() }
    private val accents = listOf(
        0xFFFFC107, 0xFF448AFF, 0xFF2ECC71, 0xFFFF5252, 0xFFB388FF,
        0xFFFF9800, 0xFFFF4081, 0xFF1DE9B6, 0xFF26C6DA, 0xFFCDDC39
    ).map { it.toInt() }
    private val ytRe = Regex("""(youtube\.com/(watch|shorts)|youtu\.be/)""")

    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    private val pickCookies = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { DL.importCookies(uri) }
                .onSuccess { updateAccountIcon(); refreshSettings(); say("Cookies imported ✓") }
                .onFailure { say("Couldn't import the file: ${it.message}") }
        }
    }
    private val prefetch = Runnable {
        if (DL.ready && ytRe.containsMatchIn(browseUrl)) DL.info(browseUrl)
    }

    // =====================  lifecycle  =====================

    override fun onCreate(savedInstanceState: Bundle?) {
        DL.attach(this)
        val id = resources.getIdentifier("YtTheme_${prefs.getInt("bg", 0)}_${prefs.getInt("accent", 0)}", "style", packageName)
        if (id != 0) setTheme(id)
        super.onCreate(savedInstanceState)
        ui = ActivityMainBinding.inflate(layoutInflater)
        setContentView(ui.root)
        handleShare(intent)
        setupBrowse(); setupSheet(); buildTrimTools(); setupDownloads(); setupSettings()

        ui.nav.setOnItemSelectedListener { item ->
            val target = when (item.itemId) {
                R.id.nav_downloads -> ui.downloadsPane
                R.id.nav_settings -> ui.settingsPane
                else -> ui.browsePane
            }
            listOf(ui.browsePane, ui.downloadsPane, ui.settingsPane).forEach { if (it !== target) it.visibility = View.GONE }
            if (target.visibility != View.VISIBLE) fadeIn(target)
            if (item.itemId == R.id.nav_downloads) { refreshTasks(); loadFiles() }
            if (item.itemId == R.id.nav_settings) refreshSettings()
            true
        }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    ui.sheet.visibility == View.VISIBLE -> hideSheet()
                    ui.nav.selectedItemId != R.id.nav_browse -> ui.nav.selectedItemId = R.id.nav_browse
                    ui.web.visibility == View.VISIBLE && ui.web.canGoBack() -> ui.web.goBack()
                    ui.web.visibility == View.VISIBLE -> ui.tabs.getTabAt(0)?.select()
                    else -> finish()
                }
            }
        })
        DL.onChange = { refreshTasks() }
        DL.onSaved = { loadFiles() }
        DL.boot(this, { say(it, false) }) { err ->
            if (err != null) say("Startup failed: $err")
            else {
                say("Ready. Paste a link, or browse a site and tap Download.", false)
                if (sharedLink.isNotEmpty()) openSheet(sharedLink)
            }
        }
        refreshTasks()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleShare(intent)
        if (sharedLink.isNotEmpty() && DL.ready) openSheet(sharedLink)
    }

    private fun handleShare(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND) sharedLink = extractUrl(i.getStringExtra(Intent.EXTRA_TEXT).orEmpty())
    }

    override fun onDestroy() {
        DL.onChange = null
        DL.onSaved = null
        super.onDestroy()
    }

    // =====================  animations  =====================

    private fun anim() = prefs.getBoolean("anim", true)

    private fun fadeIn(v: View) {
        v.visibility = View.VISIBLE
        if (!anim()) return
        v.alpha = 0f
        v.translationY = dp(12).toFloat()
        v.animate().alpha(1f).translationY(0f).setDuration(200).start()
    }

    private fun showSheet() {
        ui.scrim.visibility = View.VISIBLE
        ui.sheet.visibility = View.VISIBLE
        ui.scrim.alpha = 1f
        if (!anim()) return
        ui.scrim.alpha = 0f
        ui.scrim.animate().alpha(1f).setDuration(200).start()
        ui.sheet.translationY = dp(480).toFloat()
        ui.sheet.animate().translationY(0f).setDuration(260).setInterpolator(DecelerateInterpolator()).start()
    }

    private fun hideSheet() {
        if (ui.sheet.visibility != View.VISIBLE) return
        if (!anim()) { ui.scrim.visibility = View.GONE; ui.sheet.visibility = View.GONE; return }
        ui.scrim.animate().alpha(0f).setDuration(180).start()
        ui.sheet.animate().translationY(dp(480).toFloat()).setDuration(220).withEndAction {
            ui.sheet.visibility = View.GONE; ui.scrim.visibility = View.GONE; ui.sheet.translationY = 0f
        }.start()
    }

    // =====================  theme picker  =====================

    private fun themeDialog() {
        val onSurface = MaterialColors.getColor(this, com.google.android.material.R.attr.colorOnSurface, 0)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), dp(8)) }
        var dlg: androidx.appcompat.app.AlertDialog? = null
        fun choose(key: String, i: Int) { prefs.edit().putInt(key, i).apply(); dlg?.dismiss(); recreate() }
        fun label(t: String) = TextView(this).apply { text = t; alpha = 0.7f; setPadding(0, dp(14), 0, dp(6)) }
        fun dot(color: Int, selected: Boolean, tap: () -> Unit) = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(color)
                setStroke(dp(if (selected) 3 else 1), if (selected) onSurface else 0x66888888)
            }
            layoutParams = LinearLayout.LayoutParams(dp(40), dp(40)).apply { setMargins(dp(5), dp(5), dp(5), dp(5)) }
            setOnClickListener { tap() }
        }
        box.addView(label("Background  (Charcoal · Pure black · Midnight · Light)"))
        val bgRow = LinearLayout(this)
        bgPreview.forEachIndexed { i, c -> bgRow.addView(dot(c, prefs.getInt("bg", 0) == i) { choose("bg", i) }) }
        box.addView(bgRow)
        box.addView(label("Accent color"))
        for (r in 0..1) {
            val row = LinearLayout(this)
            for (k in 0..4) {
                val i = r * 5 + k
                row.addView(dot(accents[i], prefs.getInt("accent", 0) == i) { choose("accent", i) })
            }
            box.addView(row)
        }
        box.addView(MaterialSwitch(this).apply {
            text = "Animations"; isChecked = anim()
            setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("anim", c).apply() }
        })
        dlg = MaterialAlertDialogBuilder(this).setTitle("Theme").setView(box).setPositiveButton("Done", null).show()
    }

    // =====================  BROWSE  =====================

    private fun setupBrowse() {
        ui.tabs.addTab(ui.tabs.newTab().setText("Home"))
        sites.forEach { ui.tabs.addTab(ui.tabs.newTab().setText(it.first)) }
        ui.tabs.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) { showSite(tab?.position ?: 0) }
            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) { if ((tab?.position ?: 0) > 0) showSite(tab!!.position) }
        })
        sites.forEachIndexed { i, s ->
            ui.siteChips.addView(Chip(this).apply { text = s.first; setOnClickListener { goWeb(i + 1, null) } })
        }
        ui.searchGo.setOnClickListener { submitSearch() }
        ui.searchBox.setOnEditorActionListener { _, action, _ ->
            if (action == EditorInfo.IME_ACTION_SEARCH) { submitSearch(); true } else false
        }
        ui.pasteBtn.setOnClickListener {
            val t = clipText()
            if (t.isNotEmpty()) { ui.searchBox.setText(extractUrl(t).ifEmpty { t }); submitSearch() }
        }
        ui.dlFab.setOnClickListener { openSheet(browseUrl) }
        ui.accountBtn.setOnClickListener { accountDialog() }
        ui.themeBtn.setOnClickListener { themeDialog() }

        val ua = WebSettings.getDefaultUserAgent(this).replace("; wv", "").replace(Regex("""Version/\d+\.\d+\s"""), "")
        ui.web.settings.apply { javaScriptEnabled = true; domStorageEnabled = true; userAgentString = ua }
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(ui.web, true)
        ui.web.webViewClient = object : WebViewClient() {
            override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) { onBrowse(url) }
            override fun onPageFinished(view: WebView?, url: String?) {
                CookieManager.getInstance().flush()
                updateAccountIcon()
            }
        }
        updateAccountIcon()
    }

    private fun showSite(pos: Int) {
        if (pos == 0) {
            ui.web.visibility = View.GONE
            ui.dlFab.hide()
            fadeIn(ui.homePane)
        } else {
            ui.homePane.visibility = View.GONE
            fadeIn(ui.web)
            ui.web.loadUrl(pendingUrl ?: sites[pos - 1].second)
            pendingUrl = null
        }
    }

    private fun goWeb(tab: Int, url: String?) {
        pendingUrl = url
        ui.nav.selectedItemId = R.id.nav_browse
        if (ui.tabs.selectedTabPosition == tab) showSite(tab) else ui.tabs.getTabAt(tab)?.select()
    }

    private fun submitSearch() {
        val t = ui.searchBox.text.toString().trim()
        if (t.isEmpty()) return
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(ui.searchBox.windowToken, 0)
        val u = extractUrl(t)
        if (u.isNotEmpty()) openSheet(u)
        else goWeb(1, "https://m.youtube.com/results?search_query=" + Uri.encode(t))
    }

    private fun onBrowse(u: String?) {
        browseUrl = u.orEmpty()
        val yt = ytRe.containsMatchIn(browseUrl)
        val other = !browseUrl.contains("youtube.com") && !browseUrl.contains("google.") &&
            Regex("""https?://[^/]+/.+""").containsMatchIn(browseUrl)
        if (ui.web.visibility == View.VISIBLE && (yt || other)) ui.dlFab.show() else ui.dlFab.hide()
        // start reading the video's details while the user is still watching, so Download is instant
        ui.root.removeCallbacks(prefetch)
        if (yt) ui.root.postDelayed(prefetch, 1500)
    }

    private fun clipText(): String {
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        return cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString().orEmpty()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (!hasFocus || !DL.ready || ui.nav.selectedItemId != R.id.nav_browse || ui.sheet.visibility == View.VISIBLE) return
        val u = extractUrl(clipText())
        if (u.isNotEmpty() && u != lastClip && u != link &&
            Regex("""youtu|facebook|fb\.watch|instagram|tiktok|twitter|x\.com""").containsMatchIn(u)
        ) {
            lastClip = u
            Snackbar.make(ui.root, "Link copied — download it?", Snackbar.LENGTH_LONG).setAction("Open") { openSheet(u) }.show()
        }
    }

    // =====================  GOOGLE ACCOUNT  =====================

    private fun updateAccountIcon() {
        ui.accountBtn.imageTintList = if (DL.linked()) ColorStateList.valueOf(MaterialColors.getColor(ui.root, com.google.android.material.R.attr.colorPrimary)) else null
    }

    private fun accountDialog() {
        if (DL.linked()) {
            MaterialAlertDialogBuilder(this).setTitle("Google account linked ✓")
                .setMessage("Downloads can use your account (age-restricted videos and “confirm you’re not a bot” errors).")
                .setPositiveButton("Close", null)
                .setNegativeButton("Sign out") { _, _ -> DL.signOut(); updateAccountIcon(); refreshSettings(); say("Signed out.") }.show()
        } else {
            MaterialAlertDialogBuilder(this).setTitle("Link your Google account")
                .setMessage("Sign in to YouTube so downloads can use your account. If Google refuses the sign-in inside the app, import a cookies.txt file instead.")
                .setPositiveButton("Sign in") { _, _ ->
                    goWeb(1, "https://accounts.google.com/ServiceLogin?service=youtube&hl=en&continue=" + Uri.encode("https://m.youtube.com/"))
                }
                .setNeutralButton("Import cookies.txt") { _, _ -> pickCookies.launch(arrayOf("*/*")) }
                .setNegativeButton("Cancel", null).show()
        }
    }

    // =====================  DOWNLOAD SHEET  =====================

    private fun setupSheet() {
        ui.scrim.setOnClickListener { hideSheet() }
        ui.sheetClose.setOnClickListener { hideSheet() }
        ui.downloadBtn.setOnClickListener { enqueueFromSheet() }
        ui.range.values = listOf(0f, 100f)
        ui.range.isEnabled = false
        ui.range.setLabelFormatter { fmt(it.toInt()) }
        ui.range.addOnChangeListener { s, _, _ ->
            selStart = s.values[0].toInt()
            selEnd = s.values[1].toInt()
            refreshTrimUi()
        }
        ui.trimSwitch.setOnCheckedChangeListener { _, on ->
            ui.trimBox.visibility = if (on) View.VISIBLE else View.GONE
            // length not known yet: typing times works immediately, the slider needs the length
            if (on && duration <= 1 && ui.modeGroup.checkedButtonId == R.id.modeSlider) ui.modeGroup.check(R.id.modeType)
            refreshTrimUi()
        }
        ui.modeGroup.addOnButtonCheckedListener { _, id, checked ->
            if (!checked) return@addOnButtonCheckedListener
            val typing = id == R.id.modeType
            if (typing) fillFields() else {
                readFields()
                if (duration > 1) applySel(selStart, if (selEnd > 0) selEnd else duration)
            }
            ui.typeBox.visibility = if (typing) View.VISIBLE else View.GONE
            ui.sliderBox.visibility = if (typing) View.GONE else View.VISIBLE
            refreshTrimUi()
        }
        ui.subsSwitch.setOnCheckedChangeListener { _, on -> ui.subsBox.visibility = if (on) View.VISIBLE else View.GONE }
        ui.sOther.setOnClickListener {
            val et = EditText(this).apply { setText(customSub); hint = "Language code, e.g. de, tr, ru, hi"; setPadding(dp(24), dp(16), dp(24), dp(16)) }
            MaterialAlertDialogBuilder(this).setTitle("Subtitle language").setView(et)
                .setPositiveButton("OK") { _, _ ->
                    customSub = et.text.toString().trim().lowercase()
                    ui.sOther.text = if (customSub.isEmpty()) "Other…" else "Other: $customSub"
                }.setNegativeButton("Cancel", null).show()
        }
    }

    /**
     * Instant preview (title + thumbnail + length) comes from YouTube's public pages in about a second,
     * while yt-dlp reads the formats in the background (shared with the prefetcher and the download).
     */
    private fun openSheet(l: String) {
        if (l.isEmpty()) return
        if (!DL.ready) return say("The engine is still starting. Try again in a moment.")
        val g = ++gen
        link = l; duration = 0; infoFile = null
        ui.titleView.text = "Loading…"
        ui.metaView.text = "Reading video details…"
        ui.thumb.setImageDrawable(null)
        ui.trimSwitch.isChecked = false
        ui.subsSwitch.isChecked = false
        ui.thumbCheck.isChecked = false
        ui.extrasOnly.isChecked = false
        selStart = 0; selEnd = 0
        ui.range.isEnabled = false
        resetChips()
        ui.qualityGroup.check(qIds[prefs.getInt("quality", 0).coerceIn(qIds.indices)])
        ui.precise.isChecked = prefs.getBoolean("precise", false)
        fillFields(); refreshTrimUi(); showSheet()

        val job = DL.info(l)
        infoJob = job
        val t0 = System.currentTimeMillis()
        lifecycleScope.launch {
            while (g == gen && infoFile == null && ui.sheet.visibility == View.VISIBLE) {
                delay(1000)
                if (infoFile == null) ui.metaView.text = (if (duration > 0) "Length ${fmt(duration)}  •  " else "") +
                    "Reading formats… ${(System.currentTimeMillis() - t0) / 1000}s"
            }
        }
        lifecycleScope.launch {
            val q = withContext(Dispatchers.IO) { quickPreview(l) }
            if (q != null && g == gen) {
                if (infoFile == null) ui.titleView.text = q.first
                q.second?.let { if (ui.thumb.drawable == null) ui.thumb.setImageBitmap(it) }
            }
        }
        lifecycleScope.launch {
            val len = withContext(Dispatchers.IO) { lengthOf(l) }
            if (len > 1 && g == gen && duration == 0) { duration = len; onDurationKnown() }
        }
        lifecycleScope.launch {
            try {
                val f = job.await()
                if (g != gen) return@launch
                infoFile = f
                val j = withContext(Dispatchers.IO) { JSONObject(f.readText()) }
                val d = j.optInt("duration", 0)
                if (d > 1) { duration = d; onDurationKnown() }
                j.optString("title").takeIf { it.isNotEmpty() }?.let { ui.titleView.text = it }
                ui.metaView.text = if (duration > 0) "Length ${fmt(duration)}" else "Live or unknown length"
                updateChips(j)
                val tu = j.optString("thumbnail")
                if (ui.thumb.drawable == null && tu.isNotEmpty()) {
                    withContext(Dispatchers.IO) { bitmap(tu) }?.let { ui.thumb.setImageBitmap(it) }
                }
            } catch (e: Exception) {
                if (g == gen) ui.metaView.text = "Couldn't read details (${msgOf(e)}). You can still try Download."
            }
        }
    }

    private fun quickPreview(l: String): Pair<String, Bitmap?>? = runCatching {
        val c = URL("https://www.youtube.com/oembed?format=json&url=" + Uri.encode(l)).openConnection() as HttpURLConnection
        c.connectTimeout = 4000
        c.readTimeout = 4000
        val j = JSONObject(c.inputStream.bufferedReader().readText())
        Pair(j.getString("title"), bitmap(j.optString("thumbnail_url")))
    }.getOrNull()

    /** Video length (seconds) straight from the YouTube page, so the trim slider works at once. */
    private fun lengthOf(l: String): Int {
        val id = Regex("""(?:v=|youtu\.be/|shorts/)([\w-]{11})""").find(l)?.groupValues?.get(1) ?: return 0
        return runCatching {
            val c = URL("https://m.youtube.com/watch?v=$id").openConnection() as HttpURLConnection
            c.connectTimeout = 5000
            c.readTimeout = 5000
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/126.0 Mobile Safari/537.36")
            c.setRequestProperty("Cookie", "SOCS=CAI; CONSENT=PENDING+987")
            val re = Regex("\"lengthSeconds\":\"(\\d+)\"")
            val sb = StringBuilder()
            c.inputStream.bufferedReader().use { r ->
                val buf = CharArray(16384)
                while (sb.length < 1_200_000) {
                    val n = r.read(buf)
                    if (n < 0) break
                    sb.append(buf, 0, n)
                    re.find(sb)?.let { return@runCatching it.groupValues[1].toInt() }
                }
            }
            0
        }.getOrDefault(0)
    }

    private fun bitmap(u: String): Bitmap? =
        runCatching { URL(u).openStream().use { BitmapFactory.decodeStream(it) } }.getOrNull()

    private fun subCode() = when (ui.subGroup.checkedChipId) {
        R.id.sEn -> "en"; R.id.sAr -> "ar"; R.id.sFr -> "fr"; R.id.sEs -> "es"
        R.id.sOther -> customSub.ifEmpty { "en" }
        else -> ".*-orig"
    }

    private fun enqueueFromSheet() {
        if (link.isEmpty()) return
        val trim = ui.trimSwitch.isChecked
        val (a, e) = trimRange()
        if (trim && e > 0 && e <= a) return say("The end time must be after the start time.")
        if (trim && duration > 0 && a >= duration) return say("The start time is after the end of the video.")
        val sub = if (ui.subsSwitch.isChecked) subCode() else null
        val thumbOn = ui.thumbCheck.isChecked
        if (ui.extrasOnly.isChecked && sub == null && !thumbOn) return say("Extras only: pick subtitles or the thumbnail first.")
        val chip = ui.qualityGroup.checkedChipId
        val o = DL.Opts(chip == R.id.qAudio, qHeight[chip] ?: 2160, trim, a, e, ui.precise.isChecked,
            sub, ui.embedSubs.isChecked, thumbOn, ui.extrasOnly.isChecked)
        val dir = File(getExternalFilesDir(null) ?: filesDir, "tasks/${DL.nextId}").apply { mkdirs() }
        val bmp = (ui.thumb.drawable as? BitmapDrawable)?.bitmap
        val t = DL.Task(DL.nextId++, link, ui.titleView.text.toString(), bmp, o, infoJob, infoFile, dir)
        t.duration = duration
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        hideSheet()
        DL.add(t)
        Snackbar.make(ui.root, "Added to downloads", Snackbar.LENGTH_LONG)
            .setAction("View") { ui.nav.selectedItemId = R.id.nav_downloads }.show()
    }

    // ---- quality chips (hide missing resolutions, show estimated sizes) ----

    private fun resetChips() {
        for ((id, base) in qBase) findViewById<Chip>(id).apply { text = base; visibility = View.VISIBLE }
    }

    private fun updateChips(j: JSONObject) {
        val fs = j.optJSONArray("formats") ?: return
        class F(val r: Int, val size: Long, val audio: Boolean, val m4a: Boolean)
        val vids = ArrayList<F>()
        val auds = ArrayList<F>()
        for (i in 0 until fs.length()) {
            val o = fs.optJSONObject(i) ?: continue
            val vc = o.optString("vcodec", "none")
            val ac = o.optString("acodec", "none")
            val hasV = vc != "none" && vc != "null" && vc.isNotEmpty()
            val hasA = ac != "none" && ac != "null" && ac.isNotEmpty()
            var size = o.optLong("filesize", 0L)
            if (size <= 0) size = o.optLong("filesize_approx", 0L)
            if (size <= 0) size = (o.optDouble("tbr", 0.0) * 125.0 * duration).toLong()
            val w = o.optInt("width", 0)
            val hh = o.optInt("height", 0)
            val res = if (w > 0 && hh > 0) minOf(w, hh) else hh // portrait videos: smallest side
            val f = F(res, size, hasA, o.optString("ext") == "m4a")
            if (hasV && res > 0) vids += f else if (hasA && !hasV) auds += f
        }
        val audioSize = (auds.filter { it.m4a }.ifEmpty { auds }).maxOfOrNull { it.size } ?: 0L
        val maxR = vids.maxOfOrNull { it.r } ?: 0
        fun est(limit: Int): Long {
            val cand = vids.filter { it.r <= limit }
            val top = cand.maxOfOrNull { it.r } ?: return 0L
            val best = cand.filter { it.r == top }.maxByOrNull { it.size } ?: return 0L
            return best.size + if (best.audio) 0L else audioSize
        }
        for ((id, h) in qHeight) {
            val chip = findViewById<Chip>(id)
            if (maxR in 1 until h) { chip.visibility = View.GONE; continue }
            val e = est(h)
            chip.text = if (e > 0) "${qBase[id]} · ${fmtSize(e)}" else qBase[id]
        }
        est(2160).takeIf { it > 0 }?.let { ui.qBest.text = "Best · ${fmtSize(it)}" }
        if (audioSize > 0) ui.qAudio.text = "Audio only · ${fmtSize(audioSize)}"
        val checked = ui.qualityGroup.checkedChipId
        if (checked == View.NO_ID || findViewById<Chip>(checked).visibility != View.VISIBLE) ui.qualityGroup.check(R.id.qBest)
    }

    // ---- trim ----

    private fun onDurationKnown() {
        if (duration < 2) return
        ui.range.valueFrom = 0f
        ui.range.valueTo = duration.toFloat()
        ui.range.stepSize = 1f
        ui.range.isEnabled = true
        selStart = selStart.coerceIn(0, duration - 1)
        if (selEnd <= selStart || selEnd > duration) selEnd = duration
        ui.range.values = listOf(selStart.toFloat(), selEnd.toFloat())
        refreshTrimUi()
    }

    private fun applySel(a: Int, e: Int) {
        if (duration < 2) return
        selStart = a.coerceIn(0, duration - 1)
        selEnd = e.coerceIn(selStart + 1, duration)
        ui.range.values = listOf(selStart.toFloat(), selEnd.toFloat())
        refreshTrimUi()
    }

    private fun refreshTrimUi() {
        ui.trimLabel.text = when {
            ui.modeGroup.checkedButtonId == R.id.modeType -> "Type start and end time (leave End empty to go to the end)"
            duration <= 1 -> "Loading video length…"
            else -> "${fmt(selStart)}  →  ${fmt(selEnd)}      (clip ${fmt(selEnd - selStart)})"
        }
    }

    /** (startSeconds, endSeconds); end <= 0 means "until the end of the video". */
    private fun trimRange(): Pair<Int, Int> {
        if (ui.modeGroup.checkedButtonId == R.id.modeType) readFields()
        return Pair(selStart, selEnd)
    }

    private fun buildTrimTools() {
        typeFields = timeRow("Start") + timeRow("End")
        for ((name, isStart) in listOf("Start" to true, "End" to false)) {
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            row.addView(TextView(this).apply { text = name }, LinearLayout.LayoutParams(dp(52), W))
            for (d in listOf(-10, -1, 1, 10)) {
                val label = if (d > 0) "+${d}s" else "−${-d}s"
                row.addView(smallBtn(label) {
                    if (isStart) applySel(selStart + d, selEnd) else applySel(selStart, selEnd + d)
                }, LinearLayout.LayoutParams(0, W, 1f).apply { marginStart = dp(4) })
            }
            ui.nudgeBox.addView(row)
        }
        val presets = LinearLayout(this)
        listOf<Pair<String, () -> Unit>>(
            "Reset" to { applySel(0, duration) }, "First 30s" to { applySel(0, 30) },
            "First 60s" to { applySel(0, 60) }, "Last 30s" to { applySel(duration - 30, duration) }
        ).forEach { (t, action) ->
            presets.addView(smallBtn(t, action), LinearLayout.LayoutParams(0, W, 1f).apply { marginEnd = dp(4) })
        }
        ui.nudgeBox.addView(presets)
    }

    private fun smallBtn(t: String, onClick: () -> Unit) =
        MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            text = t; textSize = 12f; minWidth = 0; minimumWidth = 0; insetTop = 0; insetBottom = 0
            setPadding(0, 0, 0, 0)
            setOnClickListener { onClick() }
        }

    private fun timeRow(name: String): List<EditText> {
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        row.addView(TextView(this).apply { text = name }, LinearLayout.LayoutParams(dp(52), W))
        val fields = listOf("hh", "mm", "ss").mapIndexed { i, u ->
            if (i > 0) row.addView(TextView(this).apply { text = " : " })
            EditText(this).apply {
                hint = u
                inputType = InputType.TYPE_CLASS_NUMBER
                filters = arrayOf(InputFilter.LengthFilter(2))
                gravity = Gravity.CENTER
            }.also { row.addView(it, LinearLayout.LayoutParams(0, W, 1f)) }
        }
        ui.typeBox.addView(row)
        return fields
    }

    private fun secs(i: Int): Int {
        val p = (0..2).map { typeFields[i + it].text.toString().toIntOrNull() ?: 0 }
        return p[0] * 3600 + p[1] * 60 + p[2]
    }

    private fun readFields() {
        selStart = secs(0)
        val e = secs(3)
        selEnd = if (e > 0) e else duration
    }

    private fun fillFields() {
        fun put(i: Int, t: Int) {
            val parts = if (t <= 0) listOf("", "", "") else listOf(t / 3600, t % 3600 / 60, t % 60).map { it.toString() }
            for (k in 0..2) typeFields[i + k].setText(parts[k])
        }
        put(0, selStart)
        put(3, selEnd)
    }

    // =====================  DOWNLOADS TAB  =====================

    private fun setupDownloads() {
        taskAdapter = TaskAdapter(); fileAdapter = FileAdapter()
        ui.taskList.adapter = taskAdapter
        ui.fileList.adapter = fileAdapter
        ui.fileList.setOnItemClickListener { _, _, i, _ -> openUri(items[i].uri, items[i].mime) }
        ui.fileList.setOnItemLongClickListener { _, _, i, _ -> fileMenu(items[i]); true }
        ui.dlTabs.addOnButtonCheckedListener { _, id, checked ->
            if (checked) { showQueue = id == R.id.tabQueue; refreshTasks() }
        }
        ui.pauseAllBtn.setOnClickListener { if (DL.active()) DL.pauseAll() else DL.resumeAll() }
        ui.cancelAllBtn.setOnClickListener {
            MaterialAlertDialogBuilder(this).setTitle("Cancel all downloads?")
                .setPositiveButton("Yes, cancel all") { _, _ -> DL.cancelAll() }
                .setNegativeButton("No", null).show()
        }
    }

    private fun statusText(t: DL.Task): String = when (t.st) {
        DL.St.QUEUED -> "Waiting…"
        DL.St.PAUSED -> if (t.err.isNotEmpty()) t.err else "Paused" + if (t.pct >= 0) " • ${t.pct.toInt()}%" else ""
        DL.St.FAILED -> "Failed: ${t.err}  (tap ▶ to retry)"
        DL.St.RUNNING -> {
            val part = when { t.o.audio -> "Audio"; t.o.trim -> "Clip"; t.stage >= 2 -> "Audio"; else -> "Video" }
            if (t.pct < 0) t.phase.ifEmpty { "Starting…" }
            else if (t.pct >= 100f && (t.o.audio || t.o.trim || t.stage >= 2)) t.phase.ifEmpty { "Processing…" }
            else "$part ${t.pct.toInt().coerceAtMost(100)}%" +
                (if (t.speed.isNotEmpty()) "  •  ${t.speed}" else "") +
                (if (t.eta >= 0) "  •  ${fmt(t.eta.toInt())} left" else "")
        }
    }

    private fun refreshTasks() {
        if (!::taskAdapter.isInitialized) return
        taskAdapter.notifyDataSetChanged()
        val n = tasks.size
        ui.tabQueue.text = "Downloading ($n)"
        ui.taskList.visibility = if (showQueue) View.VISIBLE else View.GONE
        ui.fileList.visibility = if (showQueue) View.GONE else View.VISIBLE
        ui.queueBar.visibility = if (showQueue && n > 0) View.VISIBLE else View.GONE
        ui.pauseAllBtn.text = if (DL.active()) "Pause all" else "Resume all"
        val empty = if (showQueue) n == 0 else items.isEmpty()
        ui.emptyView.visibility = if (empty) View.VISIBLE else View.GONE
        ui.emptyView.text = if (showQueue) "No active downloads.\nBrowse a site or paste a link to start." else "No downloaded files yet."
        if (n > 0) ui.nav.getOrCreateBadge(R.id.nav_downloads).number = n else ui.nav.removeBadge(R.id.nav_downloads)
    }

    private inner class TaskAdapter : BaseAdapter() {
        override fun getCount() = tasks.size
        override fun getItem(position: Int): Any = tasks[position]
        override fun getItemId(position: Int) = tasks[position].id.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val r = if (convertView != null) ItemTaskBinding.bind(convertView)
            else ItemTaskBinding.inflate(layoutInflater, parent, false)
            val t = tasks[position]
            r.title.text = t.title
            r.thumb.setImageBitmap(t.thumb)
            r.status.text = statusText(t)
            if (t.st == DL.St.RUNNING && t.pct < 0) {
                if (!r.bar.isIndeterminate) r.bar.isIndeterminate = true
            } else {
                if (r.bar.isIndeterminate) r.bar.isIndeterminate = false
                r.bar.setProgressCompat(t.pct.coerceIn(0f, 100f).toInt(), false)
            }
            val active = t.st == DL.St.RUNNING || t.st == DL.St.QUEUED
            r.pauseBtn.setImageResource(if (active) R.drawable.ic_pause else R.drawable.ic_play)
            r.pauseBtn.setOnClickListener { if (active) DL.pause(t) else DL.resume(t) }
            r.cancelBtn.setOnClickListener { DL.cancel(t) }
            return r.root
        }
    }

    // ---- downloaded files ----

    private fun loadFiles() {
        lifecycleScope.launch {
            items = withContext(Dispatchers.IO) { queryFiles() }
            fileAdapter.notifyDataSetChanged()
            refreshTasks()
        }
    }

    private fun queryFiles(): List<Item> {
        val out = mutableListOf<Item>()
        val cols = arrayOf(
            MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.MIME_TYPE, MediaStore.MediaColumns.DATE_ADDED, MediaStore.MediaColumns.DURATION
        )
        for (coll in listOf(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, MediaStore.Audio.Media.EXTERNAL_CONTENT_URI)) {
            contentResolver.query(
                coll, cols, "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?", arrayOf("%${DL.folderName()}/"), null
            )?.use { c ->
                while (c.moveToNext()) {
                    out += Item(
                        ContentUris.withAppendedId(coll, c.getLong(0)), c.getString(1) ?: "file", c.getLong(2),
                        c.getString(3) ?: "video/mp4", c.getLong(4), c.getLong(5)
                    )
                }
            }
        }
        return out.sortedByDescending { it.added }
    }

    private inner class FileAdapter : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(position: Int): Any = items[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val r = if (convertView != null) ItemFileBinding.bind(convertView)
            else ItemFileBinding.inflate(layoutInflater, parent, false)
            val f = items[position]
            val base = f.name.substringBeforeLast('.')
            r.title.text = base
            val res = Regex("""\((\d+)P\)""").find(f.name)?.groupValues?.get(1)?.let { "${it}P" }
            val parts = listOfNotNull(res, if (f.ms > 0) fmt((f.ms / 1000).toInt()) else null).joinToString(" | ")
            r.meta.text = if (parts.isEmpty()) fmtSize(f.size) else "$parts   •   ${fmtSize(f.size)}"
            r.cc.visibility = if ((prefs.getStringSet("cc", emptySet()) ?: emptySet()).contains(base)) View.VISIBLE else View.GONE
            r.root.tag = f.uri
            val cached = thumbCache.get(f.uri)
            if (cached != null) r.thumb.setImageBitmap(cached) else {
                r.thumb.setImageDrawable(null)
                lifecycleScope.launch {
                    val bmp = withContext(Dispatchers.IO) {
                        runCatching { contentResolver.loadThumbnail(f.uri, Size(192, 108), null) }.getOrNull()
                    }
                    if (bmp != null) { thumbCache.put(f.uri, bmp); if (r.root.tag == f.uri) r.thumb.setImageBitmap(bmp) }
                }
            }
            r.moreBtn.setOnClickListener { fileMenu(f) }
            return r.root
        }
    }

    private fun fileMenu(f: Item) {
        MaterialAlertDialogBuilder(this).setTitle(f.name)
            .setItems(arrayOf("Open", "Share", "Delete")) { _, which ->
                when (which) {
                    0 -> openUri(f.uri, f.mime)
                    1 -> shareUri(f.uri, f.mime)
                    else -> {
                        val ok = runCatching { contentResolver.delete(f.uri, null, null) }.getOrDefault(0) > 0
                        if (!ok) say("Couldn't delete this file.")
                        loadFiles()
                    }
                }
            }.show()
    }

    private fun openUri(u: Uri, mime: String) {
        runCatching {
            startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(u, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        }
    }

    private fun shareUri(u: Uri, mime: String) {
        runCatching {
            startActivity(
                Intent.createChooser(
                    Intent(Intent.ACTION_SEND).setType(mime).putExtra(Intent.EXTRA_STREAM, u)
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), null
                )
            )
        }
    }

    // =====================  SETTINGS (download settings only)  =====================

    private fun setupSettings() {
        ui.settingsBox.addView(TextView(this).apply {
            text = "Download settings"; textSize = 22f; setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(16), dp(20), dp(16), dp(8))
        })
        choiceRow("Default quality", "quality", listOf("Best (up to 4K)", "4K", "2K", "1080p", "720p", "480p", "360p", "Audio only"), 0)
        switchRow("Fast reading (recommended)", "fast", true) { "Quicker YouTube client; turn off if a video fails to load" }
        addRow("Download folder", { "Movies/${DL.folderName()}  •  Music/${DL.folderName()}" }, {
            val et = EditText(this).apply { setText(DL.folderName()); setPadding(dp(24), dp(16), dp(24), dp(16)) }
            MaterialAlertDialogBuilder(this).setTitle("Folder name").setView(et)
                .setPositiveButton("Save") { _, _ -> prefs.edit().putString("folder", et.text.toString()).apply(); refreshSettings() }
                .setNegativeButton("Cancel", null).show()
        })
        choiceRow("Simultaneous downloads", "parallel", listOf("1", "2", "3"), 0)
        choiceRow("Connections per download", "threads", listOf("1", "4 (faster)", "8 (fastest)"), 1)
        choiceRow("Speed limit", "speed", listOf("Unlimited", "1 MB/s", "2 MB/s", "5 MB/s"), 0)
        switchRow("Wi‑Fi only", "wifi", false) { "Wait for Wi‑Fi instead of using mobile data" }
        switchRow("Precise trimming by default", "precise", false) { "Slower, but cuts exactly at your times" }
        switchRow("Use my Google account", "use_account", true) {
            when {
                DL.imported() -> "Using the imported cookies file"
                DL.signedIn() -> "Signed in through the Browse tab"
                else -> "Not linked — tap the account icon in Browse"
            }
        }
    }

    private fun refreshSettings() { refreshers.forEach { it() } }

    private fun addRow(title: String, sub: () -> String, tap: () -> Unit, sw: MaterialSwitch? = null) {
        val tv = TypedValue()
        theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
        val row = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            setBackgroundResource(tv.resourceId)
            setOnClickListener { tap() }
        }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val s = TextView(this).apply { text = sub(); textSize = 13f; alpha = 0.7f }
        col.addView(TextView(this).apply { text = title; textSize = 16f })
        col.addView(s)
        row.addView(col, LinearLayout.LayoutParams(0, W, 1f))
        sw?.let { row.addView(it) }
        ui.settingsBox.addView(row)
        refreshers += { s.text = sub() }
    }

    private fun choiceRow(title: String, key: String, labels: List<String>, def: Int) {
        addRow(title, { labels[prefs.getInt(key, def).coerceIn(labels.indices)] }, {
            MaterialAlertDialogBuilder(this).setTitle(title)
                .setSingleChoiceItems(labels.toTypedArray(), prefs.getInt(key, def)) { d, i ->
                    prefs.edit().putInt(key, i).apply(); d.dismiss(); refreshSettings()
                }.show()
        })
    }

    private fun switchRow(title: String, key: String, def: Boolean, sub: () -> String) {
        val sw = MaterialSwitch(this).apply {
            isChecked = prefs.getBoolean(key, def)
            setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean(key, c).apply() }
        }
        addRow(title, sub, { sw.toggle() }, sw)
    }

    // =====================  helpers  =====================

    private fun say(m: String, toast: Boolean = true) = runOnUiThread {
        ui.hintView.text = m
        if (toast) Toast.makeText(this, m, Toast.LENGTH_LONG).show()
    }

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
}
