package com.example.ytclip

import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import android.widget.Button
import android.widget.CheckBox
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.textfield.TextInputEditText
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : AppCompatActivity() {

    private val processId = "ytclip-download"
    private var ready = false

    private lateinit var url: TextInputEditText
    private lateinit var start: TextInputEditText
    private lateinit var end: TextInputEditText
    private lateinit var precise: CheckBox
    private lateinit var download: Button
    private lateinit var cancel: Button
    private lateinit var progress: ProgressBar
    private lateinit var log: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        url = findViewById(R.id.url)
        start = findViewById(R.id.start)
        end = findViewById(R.id.end)
        precise = findViewById(R.id.precise)
        download = findViewById(R.id.download)
        cancel = findViewById(R.id.cancel)
        progress = findViewById(R.id.progress)
        log = findViewById(R.id.log)

        // Link shared from the YouTube app
        if (intent.action == Intent.ACTION_SEND) {
            intent.getStringExtra(Intent.EXTRA_TEXT)?.let { url.setText(extractUrl(it)) }
        }

        // Unpack yt-dlp + ffmpeg, then try to update yt-dlp (YouTube changes often)
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                YoutubeDL.getInstance().init(application)
                FFmpeg.getInstance().init(application)
                ready = true
                setLog("Ready.")
                runCatching {
                    YoutubeDL.getInstance().updateYoutubeDL(application, YoutubeDL.UpdateChannel.STABLE)
                }
            } catch (e: Exception) {
                setLog("Init failed: ${e.message}")
            }
        }

        download.setOnClickListener {
            val link = extractUrl(url.text.toString())
            if (!ready) return@setOnClickListener setLog("Engine not ready yet.")
            if (link.isBlank()) return@setOnClickListener setLog("Paste a YouTube link first.")
            val s = start.text.toString().trim()
            val e = end.text.toString().trim()

            lifecycleScope.launch {
                setBusy(true)
                try {
                    val name = withContext(Dispatchers.IO) { run(link, s, e, precise.isChecked) }
                    setLog("Saved to Movies/YtClip/$name")
                } catch (ex: Exception) {
                    setLog("Failed: ${ex.message}")
                } finally {
                    setBusy(false)
                }
            }
        }

        cancel.setOnClickListener { YoutubeDL.getInstance().destroyProcessById(processId) }
    }

    /** Download (optionally just a time range) and copy the result into Movies/YtClip. */
    private fun run(link: String, s: String, e: String, accurate: Boolean): String {
        val dir = File(cacheDir, "dl/${System.currentTimeMillis()}").apply { mkdirs() }
        try {
            val req = YoutubeDLRequest(link).apply {
                addOption("--no-playlist")
                addOption("-f", "bv*[height<=1080][ext=mp4]+ba[ext=m4a]/b[ext=mp4]/b")
                addOption("--merge-output-format", "mp4")
                addOption("-o", "${dir.absolutePath}/%(title).80s.%(ext)s")
                if (s.isNotEmpty() || e.isNotEmpty()) {
                    // yt-dlp fetches only this section; formats: 90, 1:30, 0:01:30
                    addOption("--download-sections", "*${s.ifEmpty { "0" }}-${e.ifEmpty { "inf" }}")
                    if (accurate) addOption("--force-keyframes-at-cuts")
                }
            }
            YoutubeDL.getInstance().execute(req, processId) { pct, eta, _ ->
                runOnUiThread {
                    progress.progress = pct.toInt().coerceIn(0, 100)
                    log.text = "Working… ${pct.toInt()}%  (ETA ${eta}s)"
                }
            }

            val file = dir.listFiles()
                ?.filter { !it.name.endsWith(".part") && !it.name.endsWith(".ytdl") }
                ?.maxByOrNull { it.length() }
                ?: error("No output file produced")

            val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(file.extension) ?: "video/mp4"
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, file.name)
                put(MediaStore.Video.Media.MIME_TYPE, mime)
                put(MediaStore.Video.Media.RELATIVE_PATH, "${Environment.DIRECTORY_MOVIES}/YtClip")
            }
            val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: error("Could not create file in Movies")
            contentResolver.openOutputStream(uri)!!.use { out ->
                file.inputStream().use { it.copyTo(out) }
            }
            return file.name
        } finally {
            dir.deleteRecursively()
        }
    }

    private fun extractUrl(text: String) = Regex("""https?://\S+""").find(text)?.value ?: ""

    private fun setBusy(busy: Boolean) {
        download.isEnabled = !busy
        cancel.isEnabled = busy
        if (busy) progress.progress = 0
    }

    private fun setLog(msg: String) = runOnUiThread { log.text = msg }
}
