package com.example.ytclip

import android.Manifest
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.res.Configuration
import android.os.Environment
import android.os.StatFs
import org.json.JSONArray
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.text.InputFilter
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.InputType
import android.util.LruCache
import android.util.Size
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.WebSettings
import android.content.ClipData
import android.view.HapticFeedbackConstants
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import androidx.core.widget.doAfterTextChanged
import java.io.ByteArrayInputStream
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.ytclip.databinding.ActivityMainBinding
import com.example.ytclip.databinding.ItemFileBinding
import com.example.ytclip.databinding.ItemTaskBinding
import com.google.android.material.button.MaterialButton
import com.google.android.material.chip.Chip
import com.google.android.material.color.MaterialColors
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.radiobutton.MaterialRadioButton
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.tabs.TabLayout
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

class MainActivity : AppCompatActivity() {

    class QOpt(
        val key: String, val title: String, val desc: String, val size: Long, val audio: Boolean,
        val h: Int, val afmt: String, val abr: String, val section: String
    )

    class Item(val uri: Uri, val name: String, val size: Long, val mime: String, val added: Long, val ms: Long)

    private lateinit var ui: ActivityMainBinding
    private val W = ViewGroup.LayoutParams.WRAP_CONTENT
    private val tasks get() = DL.tasks
    private var items = listOf<Item>()
    private var showQueue = true

    // download-sheet state
    private var link = ""
    private var gen = 0
    private var duration = 0
    private var selStart = 0
    private var selEnd = 0 // 0 = until the end of the video
    private var infoFile: File? = null
    private var customSub = ""
    private var night = false
    private var peakBps = 0L
    private var sumBps = 0L
    private var cntBps = 0
    private var startTab = 0
    private var pasteRequest = false
    private var group: LinearLayout? = null
    private val suggestRun = Runnable { fetchSuggestions(ui.searchBox.text.toString().trim()) }
    private val previews = HashMap<String, Pair<String, Bitmap?>>()
    private val lens = HashMap<String, Int>()
    private var allItems = listOf<Item>()
    private val sizeViews = ArrayList<Pair<QOpt, TextView>>()
    private var filling = false
    private val capMbps = mapOf(144 to 1, 240 to 2, 360 to 3, 480 to 5, 720 to 10, 1080 to 20, 1440 to 40, 2160 to 80)
    private var qOpts = listOf<QOpt>()
    private var selKey = ""
    private var fullFile: File? = null
    private lateinit var typeFields: List<EditText>

    private var browseUrl = ""
    private var pendingUrl: String? = null
    private var sharedLink = ""
    private var lastClip = ""
    private val refreshers = mutableListOf<() -> Unit>()
    private val thumbCache = LruCache<Uri, Bitmap>(60)
    private lateinit var taskAdapter: TaskAdapter
    private lateinit var fileAdapter: FileAdapter
    private val prefs by lazy { getSharedPreferences("ytclip", MODE_PRIVATE) }

    private val sites = listOf(
        "YouTube" to "https://m.youtube.com", "Facebook" to "https://m.facebook.com",
        "Instagram" to "https://www.instagram.com", "TikTok" to "https://www.tiktok.com", "X" to "https://x.com"
    )
    private val bgPreview = listOf(0xFF0F0F10, 0xFF000000, 0xFF080C1C, 0xFFF5F5F7).map { it.toInt() }
    private val accents = listOf(
        0xFFFFD60A, 0xFF2F80FF, 0xFF00E676, 0xFFFF3B3B, 0xFF8B5CFF,
        0xFFFF7A00, 0xFFFF2E88, 0xFF00D9FF, 0xFFB6FF00, 0xFFE040FB
    ).map { it.toInt() }
    private val ytRe = Regex("""(youtube\.com/(watch|shorts)|youtu\.be/)""")

    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    private val pickCookies = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { DL.importCookies(uri) }
                .onSuccess { updateAccountIcon(); refreshSettings(); say("Cookies imported ✓") }
                .onFailure { say("Couldn't import the file: ${it.message}") }
        }
    }
    private val prefetch = Runnable {
        if (DL.ready && ytRe.containsMatchIn(browseUrl)) {
            DL.info(browseUrl)
            if (DL.fastMode()) DL.infoFull(browseUrl)
        }
    }

    // =====================  lifecycle  =====================

    override fun onCreate(savedInstanceState: Bundle?) {
        DL.attach(this)
        installCrashHandler()
        night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        var bgIdx = prefs.getInt("bg", 0)
        if (bgIdx == 4) bgIdx = if (night) 0 else 3 // "Auto" follows the system
        val id = resources.getIdentifier("YtTheme_${bgIdx}_${prefs.getInt("accent", 0)}", "style", packageName)
        if (id != 0) setTheme(id)
        super.onCreate(savedInstanceState)
        ui = ActivityMainBinding.inflate(layoutInflater)
        setContentView(ui.root)
        handleShare(intent)
        setupBrowse(); setupSheet(); buildTrimTools(); setupDownloads(); setupSettings()

        ui.nav.setOnItemSelectedListener { item ->
            val target = when (item.itemId) {
                R.id.nav_downloads -> ui.downloadsPane
                R.id.nav_settings -> ui.settingsPane
                else -> ui.browsePane
            }
            listOf(ui.browsePane, ui.downloadsPane, ui.settingsPane).forEach { if (it !== target) it.visibility = View.GONE }
            if (target.visibility != View.VISIBLE) fadeIn(target)
            if (item.itemId == R.id.nav_downloads) { refreshTasks(); loadFiles() }
            if (item.itemId == R.id.nav_settings) refreshSettings()
            true
        }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    ui.sheet.visibility == View.VISIBLE -> hideSheet()
                    ui.nav.selectedItemId != R.id.nav_browse -> ui.nav.selectedItemId = R.id.nav_browse
                    ui.web.visibility == View.VISIBLE && ui.web.canGoBack() -> ui.web.goBack()
                    ui.web.visibility == View.VISIBLE -> ui.tabs.getTabAt(0)?.select()
                    else -> finish()
                }
            }
        })
        DL.onChange = { refreshTasks() }
        DL.onSaved = { loadFiles() }
        showLastCrash()
        ui.logo.text = SpannableString("YtClip").apply {
            setSpan(ForegroundColorSpan(MaterialColors.getColor(ui.root, com.google.android.material.R.attr.colorPrimary)), 0, 2, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        fadeIn(ui.homePane)
        if (startTab != 0) { ui.nav.selectedItemId = startTab; startTab = 0 }
        startSpeedMeter()
        DL.boot(this, { say(it, false) }) { err ->
            if (err != null) say("Startup failed: $err")
            else {
                say("Ready. Paste a link, or browse a site and tap Download.", false)
                if (sharedLink.isNotEmpty()) openSheet(sharedLink)
                if (pasteRequest && hasWindowFocus()) doPaste()
            }
        }
        refreshTasks()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val n = (newConfig.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        if (prefs.getInt("bg", 0) == 4 && n != night) recreate()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleShare(intent)
        if (sharedLink.isNotEmpty() && DL.ready) openSheet(sharedLink)
        if (startTab != 0) { ui.nav.selectedItemId = startTab; startTab = 0 }
    }

    private fun handleShare(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND) sharedLink = extractUrl(i.getStringExtra(Intent.EXTRA_TEXT).orEmpty())
        else if (i?.action == Intent.ACTION_VIEW) sharedLink = i.dataString.orEmpty()
        else if (i?.action == "com.example.ytclip.OPEN_DOWNLOADS") startTab = R.id.nav_downloads
        else if (i?.action == "com.example.ytclip.PASTE") pasteRequest = true
    }

    override fun onDestroy() {
        DL.onChange = null
        DL.onSaved = null
        super.onDestroy()
    }

    // =====================  animations  =====================

    private fun anim() = prefs.getBoolean("anim", true)

    private fun fadeIn(v: View) {
        v.visibility = View.VISIBLE
        if (!anim()) return
        v.alpha = 0f
        v.translationY = dp(12).toFloat()
        v.animate().alpha(1f).translationY(0f).setDuration(200).start()
    }

    private fun showSheet() {
        ui.sheet.layoutParams = ui.sheet.layoutParams.apply { height = (resources.displayMetrics.heightPixels * 0.84).toInt() }
        ui.scrim.visibility = View.VISIBLE
        ui.sheet.visibility = View.VISIBLE
        ui.scrim.alpha = 1f
        if (!anim()) return
        ui.scrim.alpha = 0f
        ui.scrim.animate().alpha(1f).setDuration(200).start()
        ui.sheet.translationY = resources.displayMetrics.heightPixels * 0.84f
        ui.sheet.animate().translationY(0f).setDuration(260).setInterpolator(DecelerateInterpolator()).start()
    }

    private fun hideSheet() {
        if (ui.sheet.visibility != View.VISIBLE) return
        if (!anim()) { ui.scrim.visibility = View.GONE; ui.sheet.visibility = View.GONE; return }
        ui.scrim.animate().alpha(0f).setDuration(180).start()
        ui.sheet.animate().translationY(resources.displayMetrics.heightPixels * 0.84f).setDuration(220).withEndAction {
            ui.sheet.visibility = View.GONE; ui.scrim.visibility = View.GONE; ui.sheet.translationY = 0f
        }.start()
    }

    // =====================  theme picker  =====================

    private fun themeDialog() {
        val onSurface = MaterialColors.getColor(this, com.google.android.material.R.attr.colorOnSurface, 0)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), dp(8)) }
        var dlg: androidx.appcompat.app.AlertDialog? = null
        fun choose(key: String, i: Int) { prefs.edit().putInt(key, i).apply(); dlg?.dismiss(); recreate() }
        fun label(t: String) = TextView(this).apply { text = t; alpha = 0.7f; setPadding(0, dp(14), 0, dp(6)) }
        fun dot(color: Int, selected: Boolean, tap: () -> Unit) = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(color)
                setStroke(dp(if (selected) 3 else 1), if (selected) onSurface else 0x66888888)
            }
            layoutParams = LinearLayout.LayoutParams(dp(40), dp(40)).apply { setMargins(dp(5), dp(5), dp(5), dp(5)) }
            setOnClickListener { tap() }
        }
        box.addView(label("Background  (Graphite · Pure black · Midnight · Light · Auto)"))
        val bgRow = LinearLayout(this)
        bgPreview.forEachIndexed { i, c -> bgRow.addView(dot(c, prefs.getInt("bg", 0) == i) { choose("bg", i) }) }
        bgRow.addView(dot(0xFF8E8E93.toInt(), prefs.getInt("bg", 0) == 4) { choose("bg", 4) }.also { v ->
            (v.background as GradientDrawable).apply {
                orientation = GradientDrawable.Orientation.LEFT_RIGHT
                setColors(intArrayOf(0xFF0F0F10.toInt(), 0xFF0F0F10.toInt(), 0xFFF5F5F7.toInt(), 0xFFF5F5F7.toInt()), floatArrayOf(0f, 0.5f, 0.5f, 1f))
            }
        })
        box.addView(bgRow)
        box.addView(label("Accent color"))
        for (r in 0..1) {
            val row = LinearLayout(this)
            for (k in 0..4) {
                val i = r * 5 + k
                row.addView(dot(accents[i], prefs.getInt("accent", 0) == i) { choose("accent", i) })
            }
            box.addView(row)
        }
        box.addView(MaterialSwitch(this).apply {
            text = "Animations"; isChecked = anim()
            setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("anim", c).apply() }
        })
        dlg = MaterialAlertDialogBuilder(this).setTitle("Theme").setView(box).setPositiveButton("Done", null).show()
    }

    // =====================  BROWSE  =====================

    private fun setupBrowse() {
        ui.tabs.addTab(ui.tabs.newTab().setText("Home"))
        sites.forEach { ui.tabs.addTab(ui.tabs.newTab().setText(it.first)) }
        ui.tabs.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) { showSite(tab?.position ?: 0) }
            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) { if ((tab?.position ?: 0) > 0) showSite(tab!!.position) }
        })
        sites.forEachIndexed { i, s ->
            ui.siteChips.addView(Chip(this).apply { text = s.first; setOnClickListener { goWeb(i + 1, null) } })
        }
        ui.searchGo.setOnClickListener { submitSearch() }
        ui.searchBox.doAfterTextChanged { ui.root.removeCallbacks(suggestRun); ui.root.postDelayed(suggestRun, 250) }
        ui.searchBox.setOnFocusChangeListener { _, f -> if (f) fetchSuggestions(ui.searchBox.text.toString().trim()) }
        ui.searchBox.setOnEditorActionListener { _, action, _ ->
            if (action == EditorInfo.IME_ACTION_SEARCH) { submitSearch(); true } else false
        }
        ui.pasteBtn.setOnClickListener {
            val t = clipText()
            if (t.isNotEmpty()) { ui.searchBox.setText(extractUrl(t).ifEmpty { t }); submitSearch() }
        }
        ui.dlFab.setOnClickListener { openSheet(browseUrl) }
        ui.accountBtn.setOnClickListener { accountDialog() }
        ui.themeBtn.setOnClickListener { themeDialog() }

        val ua = WebSettings.getDefaultUserAgent(this).replace("; wv", "").replace(Regex("""Version/\d+\.\d+\s"""), "")
        ui.web.settings.apply { javaScriptEnabled = true; domStorageEnabled = true; userAgentString = ua }
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(ui.web, true)
        ui.web.webViewClient = object : WebViewClient() {
            override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) { onBrowse(url) }
            // drop ad and tracker requests: pages load faster and cleaner
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val u = request?.url?.toString().orEmpty()
                val ad = listOf("doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.", "pagead2.", "/pagead/")
                return if (ad.any { it in u }) WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                else super.shouldInterceptRequest(view, request)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                CookieManager.getInstance().flush()
                updateAccountIcon()
            }
        }
        updateAccountIcon()
    }

    private fun showSite(pos: Int) {
        if (pos == 0) {
            ui.web.visibility = View.GONE
            ui.dlFab.hide()
            fadeIn(ui.homePane)
        } else {
            ui.homePane.visibility = View.GONE
            fadeIn(ui.web)
            ui.web.loadUrl(pendingUrl ?: sites[pos - 1].second)
            pendingUrl = null
        }
    }

    private fun goWeb(tab: Int, url: String?) {
        pendingUrl = url
        ui.nav.selectedItemId = R.id.nav_browse
        if (ui.tabs.selectedTabPosition == tab) showSite(tab) else ui.tabs.getTabAt(tab)?.select()
    }

    private fun submitSearch() {
        val t = ui.searchBox.text.toString().trim()
        if (t.isEmpty()) return
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(ui.searchBox.windowToken, 0)
        val u = extractUrl(t)
        ui.searchBox.clearFocus()
        ui.suggestBox.visibility = View.GONE
        if (u.isEmpty()) addRecent(t)
        val urls = Regex("""https?://\S+""").findAll(t).map { it.value }.toList()
        if (urls.size > 1) batchDialog(urls)
        else if (u.isNotEmpty()) openSheet(u)
        else goWeb(1, "https://m.youtube.com/results?search_query=" + Uri.encode(t))
    }

    private fun onBrowse(u: String?) {
        browseUrl = u.orEmpty()
        val yt = ytRe.containsMatchIn(browseUrl)
        val other = !browseUrl.contains("youtube.com") && !browseUrl.contains("google.") &&
            Regex("""https?://[^/]+/.+""").containsMatchIn(browseUrl)
        if (ui.web.visibility == View.VISIBLE && (yt || other)) ui.dlFab.show() else ui.dlFab.hide()
        // start reading the video's details while the user is still watching, so Download is instant
        ui.root.removeCallbacks(prefetch)
        if (yt) ui.root.postDelayed(prefetch, 1500)
    }

    private fun clipText(): String {
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        return cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString().orEmpty()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && pasteRequest && DL.ready) { doPaste(); return }
        if (!hasFocus || !DL.ready || ui.nav.selectedItemId != R.id.nav_browse || ui.sheet.visibility == View.VISIBLE) return
        val u = extractUrl(clipText())
        if (u.isNotEmpty() && u != lastClip && u != link &&
            Regex("""youtu|facebook|fb\.watch|instagram|tiktok|twitter|x\.com""").containsMatchIn(u)
        ) {
            lastClip = u
            Snackbar.make(ui.root, "Link copied — download it?", Snackbar.LENGTH_LONG).setAction("Open") { openSheet(u) }.show()
        }
    }

    // =====================  GOOGLE ACCOUNT  =====================

    private fun updateAccountIcon() {
        // never pass null here: it would strip the icon's own tint and leave a black icon on a dark bar
        val attr = if (DL.linked()) com.google.android.material.R.attr.colorPrimary else com.google.android.material.R.attr.colorOnSurfaceVariant
        ui.accountBtn.imageTintList = ColorStateList.valueOf(MaterialColors.getColor(ui.root, attr))
    }

    private fun accountDialog() {
        if (DL.linked()) {
            MaterialAlertDialogBuilder(this).setTitle("Google account linked ✓")
                .setMessage("Downloads can use your account (age-restricted videos and “confirm you’re not a bot” errors).")
                .setPositiveButton("Close", null)
                .setNegativeButton("Sign out") { _, _ -> DL.signOut(); updateAccountIcon(); refreshSettings(); say("Signed out.") }.show()
        } else {
            MaterialAlertDialogBuilder(this).setTitle("Link your Google account")
                .setMessage("Sign in to YouTube so downloads can use your account. If Google refuses the sign-in inside the app, import a cookies.txt file instead.")
                .setPositiveButton("Sign in") { _, _ ->
                    goWeb(1, "https://accounts.google.com/ServiceLogin?service=youtube&hl=en&continue=" + Uri.encode("https://m.youtube.com/"))
                }
                .setNeutralButton("Import cookies.txt") { _, _ -> pickCookies.launch(arrayOf("*/*")) }
                .setNegativeButton("Cancel", null).show()
        }
    }

    // =====================  DOWNLOAD SHEET  =====================

    private fun setupSheet() {
        ui.scrim.setOnClickListener { hideSheet() }
        ui.sheetClose.setOnClickListener { hideSheet() }
        ui.downloadBtn.setOnClickListener { enqueueFromSheet() }
        ui.playlistBtn.setOnClickListener { hideSheet(); openPlaylist(link) }
        ui.range.values = listOf(0f, 100f)
        ui.range.isEnabled = false
        ui.range.stepSize = 0f
        ui.range.setLabelFormatter { fmt(it.toInt()) }
        ui.range.addOnChangeListener { s, _, _ ->
            selStart = s.values[0].toInt()
            selEnd = s.values[1].toInt()
            refreshTrimUi()
        }
        ui.trimSwitch.setOnCheckedChangeListener { _, on ->
            ui.trimBox.visibility = if (on) View.VISIBLE else View.GONE
            // length not known yet: typing times works immediately, the slider needs the length
            if (on && duration <= 1 && ui.modeGroup.checkedButtonId == R.id.modeSlider) ui.modeGroup.check(R.id.modeType)
            refreshTrimUi()
        }
        ui.modeGroup.addOnButtonCheckedListener { _, id, checked ->
            if (!checked) return@addOnButtonCheckedListener
            val typing = id == R.id.modeType
            if (typing) fillFields() else {
                readFields()
                if (duration > 1) applySel(selStart, if (selEnd > 0) selEnd else duration)
            }
            ui.typeBox.visibility = if (typing) View.VISIBLE else View.GONE
            ui.sliderBox.visibility = if (typing) View.GONE else View.VISIBLE
            refreshTrimUi()
        }
        ui.subsSwitch.setOnCheckedChangeListener { _, on -> ui.subsBox.visibility = if (on) View.VISIBLE else View.GONE }
        ui.sOther.setOnClickListener {
            val et = EditText(this).apply { setText(customSub); hint = "Language code, e.g. de, tr, ru, hi"; setPadding(dp(24), dp(16), dp(24), dp(16)) }
            MaterialAlertDialogBuilder(this).setTitle("Subtitle language").setView(et)
                .setPositiveButton("OK") { _, _ ->
                    customSub = et.text.toString().trim().lowercase()
                    ui.sOther.text = if (customSub.isEmpty()) "Other…" else "Other: $customSub"
                }.setNegativeButton("Cancel", null).show()
        }
    }

    /**
     * Instant preview (title + thumbnail + length) comes from YouTube's public pages in about a second,
     * while yt-dlp reads the formats in the background (shared with the prefetcher and the download).
     */
    private fun openSheet(l: String) {
        if (l.isEmpty()) return
        if (!DL.ready) return say("The engine is still starting. Try again in a moment.")
        if (Regex("""[?&]list=""").containsMatchIn(l) && !Regex("""[?&]v=|youtu\.be/""").containsMatchIn(l)) return openPlaylist(l)
        if (!prefs.getBoolean("ask", true)) return quickAdd(listOf(l))
        val g = ++gen
        link = l; duration = 0; infoFile = null
        ui.titleView.text = "Loading…"
        ui.metaView.text = "Reading video details…"
        ui.thumb.setImageDrawable(null)
        ui.trimSwitch.isChecked = false
        ui.subsSwitch.isChecked = false
        ui.extrasOnly.isChecked = false
        ui.sponsorCheck.isChecked = false
        ui.playlistBtn.visibility = if (Regex("""[?&]list=""").containsMatchIn(l)) View.VISIBLE else View.GONE
        selStart = 0; selEnd = 0
        ui.range.isEnabled = false
        selKey = ""; fullFile = null; ui.qualityNote.text = ""
        buildQuality(null)
        ui.precise.isChecked = prefs.getBoolean("precise", false)
        fillFields(); refreshTrimUi(); showSheet()

        val job = DL.info(l)
        startFull(l, g)
        val t0 = System.currentTimeMillis()
        lifecycleScope.launch {
            while (g == gen && infoFile == null && ui.sheet.visibility == View.VISIBLE) {
                delay(1000)
                if (infoFile == null) ui.metaView.text = (if (duration > 0) "Length ${fmt(duration)}  •  " else "") +
                    "Reading formats… ${(System.currentTimeMillis() - t0) / 1000}s"
            }
        }
        lifecycleScope.launch {
            val q = previews[l] ?: withContext(Dispatchers.IO) { quickPreview(l) }?.also { previews[l] = it }
            if (q != null && g == gen) {
                if (infoFile == null) ui.titleView.text = q.first
                q.second?.let { if (ui.thumb.drawable == null) ui.thumb.setImageBitmap(it) }
            }
        }
        lifecycleScope.launch {
            val len = lens[l] ?: withContext(Dispatchers.IO) { lengthOf(l) }.also { if (it > 1) lens[l] = it }
            if (len > 1 && g == gen && duration == 0) { duration = len; onDurationKnown(); if (infoFile == null) buildQuality(null) }
        }
        lifecycleScope.launch {
            try {
                val f = job.await()
                if (g != gen) return@launch
                infoFile = f
                val j = withContext(Dispatchers.IO) { JSONObject(f.readText()) }
                val d = j.optInt("duration", 0)
                if (d > 1) { duration = d; onDurationKnown() }
                j.optString("title").takeIf { it.isNotEmpty() }?.let { ui.titleView.text = it }
                ui.metaView.text = if (duration > 0) "Length ${fmt(duration)}" else "Live or unknown length"
                if (fullFile == null) buildQuality(j)
                val tu = j.optString("thumbnail")
                if (ui.thumb.drawable == null && tu.isNotEmpty()) {
                    withContext(Dispatchers.IO) { bitmap(tu) }?.let { ui.thumb.setImageBitmap(it) }
                }
            } catch (e: Exception) {
                if (g == gen) ui.metaView.text = "Couldn't read details (${msgOf(e)}). You can still try Download."
            }
        }
    }

    private fun quickPreview(l: String): Pair<String, Bitmap?>? = runCatching {
        val c = URL("https://www.youtube.com/oembed?format=json&url=" + Uri.encode(l)).openConnection() as HttpURLConnection
        c.connectTimeout = 4000
        c.readTimeout = 4000
        val j = JSONObject(c.inputStream.bufferedReader().readText())
        Pair(j.getString("title"), bitmap(j.optString("thumbnail_url")))
    }.getOrNull()

    /** Video length (seconds) straight from the YouTube page, so the trim slider works at once. */
    private fun lengthOf(l: String): Int {
        val id = Regex("""(?:v=|youtu\.be/|shorts/)([\w-]{11})""").find(l)?.groupValues?.get(1) ?: return 0
        return runCatching {
            val c = URL("https://m.youtube.com/watch?v=$id").openConnection() as HttpURLConnection
            c.connectTimeout = 5000
            c.readTimeout = 5000
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/126.0 Mobile Safari/537.36")
            c.setRequestProperty("Cookie", "SOCS=CAI; CONSENT=PENDING+987")
            val re = Regex("\"lengthSeconds\":\"(\\d+)\"")
            val sb = StringBuilder()
            c.inputStream.bufferedReader().use { r ->
                val buf = CharArray(16384)
                while (sb.length < 1_200_000) {
                    val n = r.read(buf)
                    if (n < 0) break
                    sb.append(buf, 0, n)
                    re.find(sb)?.let { return@runCatching it.groupValues[1].toInt() }
                }
            }
            0
        }.getOrDefault(0)
    }

    private fun bitmap(u: String): Bitmap? =
        runCatching { URL(u).openStream().use { BitmapFactory.decodeStream(it) } }.getOrNull()

    private fun subCode() = when (ui.subGroup.checkedChipId) {
        R.id.sEn -> "en"; R.id.sAr -> "ar"; R.id.sFr -> "fr"; R.id.sEs -> "es"
        R.id.sOther -> customSub.ifEmpty { "en" }
        else -> ".*-orig"
    }

    private fun enqueueFromSheet(force: Boolean = false) {
        if (link.isEmpty()) return
        val trim = ui.trimSwitch.isChecked
        val (a, e) = trimRange()
        if (trim && e > 0 && e <= a) return say("The end time must be after the start time.")
        if (trim && duration > 0 && a >= duration) return say("The start time is after the end of the video.")
        if (trim && duration > 0 && e > duration) return say("The end time is after the end of the video.")
        val sub = if (ui.subsSwitch.isChecked) subCode() else null
        val q = qOpts.firstOrNull { it.key == selKey } ?: prefChoice()
        val est = (q.size * clipFraction()).toLong()
        val free = runCatching { StatFs(Environment.getExternalStorageDirectory().path).availableBytes }.getOrDefault(Long.MAX_VALUE)
        if (!force && est > 0 && est * 1.1 > free) {
            MaterialAlertDialogBuilder(this).setTitle("Low storage")
                .setMessage("This download needs about ${fmtSize(est)} but only ${fmtSize(free)} is free.")
                .setPositiveButton("Download anyway") { _, _ -> enqueueFromSheet(true) }
                .setNegativeButton("Cancel", null).show()
            return
        }
        val o = DL.Opts(q.audio, q.h, trim, a, e, ui.precise.isChecked, sub, ui.embedSubs.isChecked, true,
            (ui.extrasOnly.isChecked && sub != null), ui.sponsorCheck.isChecked, q.afmt, q.abr) // cover art is always embedded
        val dir = File(getExternalFilesDir(null) ?: filesDir, "tasks/${UUID.randomUUID()}").apply { mkdirs() }
        val bmp = (ui.thumb.drawable as? BitmapDrawable)?.bitmap
        val useFull = fullFile?.takeIf { it.exists() }
        // The quick Android-VR JSON may omit formats. Download from the URL until the full read is ready.
        val t = DL.Task(DL.nextId++, link, ui.titleView.text.toString(), bmp, o, null, useFull, dir)
        t.duration = duration
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        hideSheet()
        ui.root.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
        DL.add(t)
        Snackbar.make(ui.root, "Added to downloads", Snackbar.LENGTH_LONG)
            .setAction("View") { ui.nav.selectedItemId = R.id.nav_downloads }.show()
    }

    // ---- quality list (SnapTube style: radio rows with sizes) ----

    private val stdH = listOf(144, 240, 360, 480, 720, 1080, 1440, 2160)

    private fun vTitle(h: Int) = when (h) {
        144 -> "Fast (144p)" to "Very low quality"
        240 -> "Low (240p)" to "Small size, low quality"
        360 -> "Normal (360p)" to "Normal quality, small file"
        480 -> "Normal (480p)" to "Good for phones"
        720 -> "High (720p)" to "Clear picture, fast playback"
        1080 -> "High (1080p)" to "Full HD details"
        1440 -> "2K (1440p)" to "Sharp on big screens"
        else -> "4K (2160p)" to "Ultra HD — very large file"
    }

    private fun vq(h: Int) = QOpt("v$h", "", "", 0, false, h, "m4a", "", "")

    /** The default quality chosen in Settings. */
    private fun prefChoice(): QOpt = when (prefs.getInt("quality", 0).coerceIn(0, 8)) {
        1 -> vq(2160); 2 -> vq(1440); 3 -> vq(1080); 4 -> vq(720); 5 -> vq(480); 6 -> vq(360)
        7 -> QOpt("a_m4a", "", "", 0, true, 0, "m4a", "", "")
        8 -> QOpt("a_mp3_128", "", "", 0, true, 0, "mp3", "128K", "")
        else -> vq(2160)
    }

    /** Builds the list from the formats the video really has (or a default list while loading). */
    private fun buildQuality(j: JSONObject?) {
        class F(val r: Int, val size: Long, val hasAudio: Boolean, val m4a: Boolean, val fps: Int, val codec: String)
        val all = ArrayList<F>()
        val clean = ArrayList<F>()
        val auds = ArrayList<F>()
        j?.optJSONArray("formats")?.let { fs ->
            for (i in 0 until fs.length()) {
                val o = fs.optJSONObject(i) ?: continue
                val vc = o.optString("vcodec", "none")
                val ac = o.optString("acodec", "none")
                val hasV = vc != "none" && vc != "null" && vc.isNotEmpty()
                val hasA = ac != "none" && ac != "null" && ac.isNotEmpty()
                var size = o.optLong("filesize", 0L)
                if (size <= 0) size = o.optLong("filesize_approx", 0L)
                if (size <= 0) size = (o.optDouble("tbr", 0.0) * 125.0 * duration).toLong()
                val w = o.optInt("width", 0)
                val hh = o.optInt("height", 0)
                val res = if (w > 0 && hh > 0) minOf(w, hh) else hh // portrait videos: smallest side
                val f = F(res, size, hasA, o.optString("ext") == "m4a", o.optInt("fps", 0), vc)
                if (hasV && res > 0) {
                    all += f
                    // streaming (m3u8) and "Premium" variants are not what gets downloaded: leave them out of the sizes
                    if (!o.optString("protocol").contains("m3u8") && !o.optString("format_note").contains("Premium", ignoreCase = true)) clean += f
                } else if (hasA && !hasV) auds += f
            }
        }
        val vids = clean.ifEmpty { all }
        val audioSize = (auds.filter { it.m4a }.ifEmpty { auds }).maxOfOrNull { it.size } ?: 0L
        // the same choice the downloader makes: preferred codec, highest fps, then the smaller (normal) bitrate
        fun pick(h: Int): F? {
            val cand = vids.filter { it.r >= h * 0.85 && it.r <= h * 1.15 }
            if (cand.isEmpty()) return null
            val pref = if (h <= 1080) "avc1" else "vp09"
            val byCodec = cand.filter { it.codec.startsWith(pref) }.ifEmpty { cand }
            val top = byCodec.maxOf { it.fps }
            val group = byCodec.filter { it.fps == top }
            return group.filter { it.size > 0 }.minByOrNull { it.size } ?: group.firstOrNull()
        }
        val list = ArrayList<QOpt>()
        list += QOpt("a_m4a", "Original audio (M4A)", "Best quality, no re-encoding", audioSize, true, 0, "m4a", "", "Audio")
        list += QOpt("a_mp3_128", "MP3 128K", "Plays on speakers, cars and watches", duration * 16000L, true, 0, "mp3", "128K", "Audio")
        list += QOpt("a_mp3_320", "MP3 320K", "Highest MP3 quality", duration * 40000L, true, 0, "mp3", "320K", "Audio")
        val hs = if (vids.isNotEmpty()) stdH.filter { h -> vids.any { it.r >= h * 0.85 && it.r <= h * 1.15 } }
        else listOf(144, 240, 360, 480, 720, 1080)
        for (h in hs) {
            val best = pick(h)
            var size = if (best == null) 0L else best.size + if (best.hasAudio) 0L else audioSize
            if (size > 0 && duration > 0) size = minOf(size, duration * (capMbps[h] ?: 80) * 125_000L) // sanity cap
            val (t, d) = vTitle(h)
            list += QOpt("v$h", t, d, size, false, h, "m4a", "", "Video")
        }
        qOpts = list
        if (qOpts.none { it.key == selKey }) { // keep the user's choice when more qualities arrive
            val p = prefChoice()
            selKey = if (p.audio) p.key else "v" + (hs.filter { it <= p.h }.maxOrNull() ?: hs.minOrNull() ?: 360)
            if (qOpts.none { it.key == selKey }) selKey = qOpts.last().key
        }
        renderQuality()
    }

    private fun renderQuality() {
        ui.qualityBox.removeAllViews()
        sizeViews.clear()
        val tv = TypedValue()
        theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
        var section = ""
        for (q in qOpts) {
            if (q.section != section) {
                section = q.section
                ui.qualityBox.addView(TextView(this).apply { text = section; alpha = 0.6f; textSize = 13f; setPadding(0, dp(12), 0, dp(2)) })
            }
            val row = LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(6), 0, dp(6))
                setBackgroundResource(tv.resourceId)
                setOnClickListener { selKey = q.key; renderQuality() }
            }
            val rb = MaterialRadioButton(this).apply { isChecked = q.key == selKey; isClickable = false; isFocusable = false }
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            col.addView(TextView(this).apply { text = q.title; textSize = 15f; setTypeface(typeface, Typeface.BOLD) })
            col.addView(TextView(this).apply { text = q.desc; textSize = 12f; alpha = 0.65f })
            val sz = TextView(this).apply { textSize = 13f; alpha = 0.85f }
            sizeViews += Pair(q, sz)
            row.addView(rb)
            row.addView(col, LinearLayout.LayoutParams(0, W, 1f).apply { marginStart = dp(6) })
            row.addView(sz)
            ui.qualityBox.addView(row)
        }
        refreshSizes()
    }

    /** Share of the video that will be downloaded (1.0 = all of it). */
    private fun clipFraction(): Double {
        if (!ui.trimSwitch.isChecked || duration <= 1) return 1.0
        val end = if (selEnd > 0) selEnd else duration
        return ((end - selStart).coerceAtLeast(1)).toDouble() / duration
    }

    /** Sizes follow the trim: clip length / full length. */
    private fun refreshSizes() {
        if (!::ui.isInitialized) return
        val f = clipFraction()
        for ((q, v) in sizeViews) v.text = if (q.size > 0) (if (f < 0.999) "≈ " else "") + fmtSize((q.size * f).toLong()) else "—"
        val q = qOpts.firstOrNull { it.key == selKey }
        ui.sizeNote.text = when {
            q == null || q.size <= 0 -> ""
            f < 0.999 -> "Clip ${fmt(((if (selEnd > 0) selEnd else duration) - selStart).coerceAtLeast(1))} of ${fmt(duration)}  •  about ${fmtSize((q.size * f).toLong())}"
            else -> "Full video  •  about ${fmtSize(q.size)}"
        }
    }

    /** After the quick read: fetch the complete list of qualities in the background. */
    private fun startFull(l: String, g: Int) {
        if (!DL.fastMode()) return
        ui.qualityNote.text = "Loading all qualities…"
        val t0 = System.currentTimeMillis()
        val fj = DL.infoFull(l)
        lifecycleScope.launch {
            while (g == gen && !fj.isCompleted && ui.sheet.visibility == View.VISIBLE) {
                delay(1000)
                if (!fj.isCompleted) ui.qualityNote.text = "Loading all qualities… ${(System.currentTimeMillis() - t0) / 1000}s"
            }
        }
        lifecycleScope.launch {
            try {
                val f = fj.await()
                if (g != gen) return@launch
                fullFile = f
                val j2 = withContext(Dispatchers.IO) { JSONObject(f.readText()) }
                val d = j2.optInt("duration", 0)
                if (d > 1 && duration <= 1) { duration = d; onDurationKnown() }
                buildQuality(j2)
                ui.qualityNote.text = ""
            } catch (e: Exception) {
                if (g == gen) ui.qualityNote.text = "Only the quick qualities are available for this video."
            }
        }
    }

    // ---- trim ----

    private fun onDurationKnown() {
        if (duration < 2) return
        ui.range.valueFrom = 0f
        ui.range.valueTo = duration.toFloat()
        ui.range.stepSize = 0f
        ui.range.isEnabled = true
        selStart = selStart.coerceIn(0, duration - 1)
        if (selEnd <= selStart || selEnd > duration) selEnd = duration
        ui.range.values = listOf(selStart.toFloat(), selEnd.toFloat())
        if (::typeFields.isInitialized && ui.modeGroup.checkedButtonId == R.id.modeType) fillFields()
        refreshTrimUi()
    }

    private fun applySel(a: Int, e: Int) {
        if (duration < 2) return
        selStart = a.coerceIn(0, duration - 1)
        selEnd = e.coerceIn(selStart + 1, duration)
        ui.range.values = listOf(selStart.toFloat(), selEnd.toFloat())
        refreshTrimUi()
    }

    private fun refreshTrimUi() {
        val endText = if (selEnd > 0) fmt(selEnd) else "End of video"
        val clipText = if (selEnd > selStart) fmt(selEnd - selStart) else "—"
        val summary = "${fmt(selStart)}  →  $endText  •  clip $clipText"
        ui.trimLabel.text = when {
            duration <= 1 && ui.modeGroup.checkedButtonId != R.id.modeType -> "Loading video length…"
            ui.modeGroup.checkedButtonId == R.id.modeType -> "$summary\nEnter hours, minutes and seconds (leave End empty for the end)"
            else -> summary
        }
        refreshSizes()
    }

    /** (startSeconds, endSeconds); end <= 0 means "until the end of the video". */
    private fun trimRange(): Pair<Int, Int> {
        if (ui.modeGroup.checkedButtonId == R.id.modeType) readFields()
        return Pair(selStart, selEnd)
    }

    private fun buildTrimTools() {
        typeFields = timeRow("Start") + timeRow("End")
        for ((name, isStart) in listOf("Start" to true, "End" to false)) {
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            row.addView(TextView(this).apply { text = name }, LinearLayout.LayoutParams(dp(52), W))
            for (d in listOf(-10, -1, 1, 10)) {
                val label = if (d > 0) "+${d}s" else "−${-d}s"
                row.addView(smallBtn(label) {
                    if (isStart) applySel(selStart + d, selEnd) else applySel(selStart, selEnd + d)
                }, LinearLayout.LayoutParams(0, W, 1f).apply { marginStart = dp(4) })
            }
            ui.nudgeBox.addView(row)
        }
        val presets = LinearLayout(this)
        listOf<Pair<String, () -> Unit>>(
            "Reset" to { applySel(0, duration) }, "First 30s" to { applySel(0, 30) },
            "First 60s" to { applySel(0, 60) }, "Last 30s" to { applySel(duration - 30, duration) }
        ).forEach { (t, action) ->
            presets.addView(smallBtn(t, action), LinearLayout.LayoutParams(0, W, 1f).apply { marginEnd = dp(4) })
        }
        ui.nudgeBox.addView(presets)
        typeFields.forEach { f ->
            f.doAfterTextChanged {
                if (!filling && ui.modeGroup.checkedButtonId == R.id.modeType) { readFields(); refreshTrimUi() }
            }
        }
    }

    private fun smallBtn(t: String, onClick: () -> Unit) =
        MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            text = t; textSize = 12f; minWidth = 0; minimumWidth = 0; insetTop = 0; insetBottom = 0
            setPadding(0, 0, 0, 0)
            setOnClickListener { onClick() }
        }

    private fun timeRow(name: String): List<EditText> {
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        row.addView(TextView(this).apply { text = name }, LinearLayout.LayoutParams(dp(52), W))
        val fields = listOf("hh", "mm", "ss").mapIndexed { i, u ->
            if (i > 0) row.addView(TextView(this).apply { text = " : " })
            EditText(this).apply {
                hint = u
                inputType = InputType.TYPE_CLASS_NUMBER
                filters = arrayOf(InputFilter.LengthFilter(2))
                gravity = Gravity.CENTER
            }.also { row.addView(it, LinearLayout.LayoutParams(0, W, 1f)) }
        }
        ui.typeBox.addView(row)
        return fields
    }

    private fun secs(i: Int): Int {
        val p = (0..2).map { typeFields[i + it].text.toString().toIntOrNull() ?: 0 }
        return p[0] * 3600 + p[1] * 60 + p[2]
    }

    private fun readFields() {
        selStart = secs(0)
        val e = secs(3)
        selEnd = if (e > 0) e else duration
    }

    private fun fillFields() {
        fun put(i: Int, t: Int) {
            val parts = if (t <= 0) listOf("", "", "") else listOf(t / 3600, t % 3600 / 60, t % 60).map { it.toString() }
            for (k in 0..2) typeFields[i + k].setText(parts[k])
        }
        filling = true
        put(0, selStart)
        put(3, selEnd)
        filling = false
    }

    // =====================  DOWNLOADS TAB  =====================

    private fun setupDownloads() {
        taskAdapter = TaskAdapter(); fileAdapter = FileAdapter()
        ui.taskList.adapter = taskAdapter
        ui.fileList.adapter = fileAdapter
        ui.fileList.setOnItemClickListener { _, _, i, _ -> openUri(items[i].uri, items[i].mime) }
        ui.fileList.setOnItemLongClickListener { _, _, i, _ -> fileMenu(items[i]); true }
        ui.dlTabs.addOnButtonCheckedListener { _, id, checked ->
            if (checked) { showQueue = id == R.id.tabQueue; refreshTasks() }
        }
        ui.pauseAllBtn.setOnClickListener { if (DL.active()) DL.pauseAll() else DL.resumeAll() }
        ui.fileSearch.doAfterTextChanged { applyFilter() }
        ui.sortBtn.setOnClickListener {
            MaterialAlertDialogBuilder(this).setTitle("Sort by")
                .setSingleChoiceItems(arrayOf("Newest", "Oldest", "Largest", "Name"), prefs.getInt("sort", 0)) { d, i ->
                    prefs.edit().putInt("sort", i).apply(); d.dismiss(); applyFilter()
                }.show()
        }
        ui.cancelAllBtn.setOnClickListener {
            MaterialAlertDialogBuilder(this).setTitle("Cancel all downloads?")
                .setPositiveButton("Yes, cancel all") { _, _ -> DL.cancelAll() }
                .setNegativeButton("No", null).show()
        }
    }

    private fun statusText(t: DL.Task): String = when (t.st) {
        DL.St.QUEUED -> "Waiting…"
        DL.St.PAUSED -> if (t.err.isNotEmpty()) t.err else "Paused" + if (t.pct >= 0) " • ${t.pct.toInt()}%" else ""
        DL.St.FAILED -> "Failed: ${t.err}  (tap ▶ to retry)"
        DL.St.RUNNING -> {
            val part = when { t.o.audio -> "Audio"; t.o.trim -> "Clip"; t.stage >= 2 -> "Audio"; else -> "Video" }
            val progress = when {
                t.pct < 0 -> t.phase.ifEmpty { "Starting…" }
                t.pct >= 100f && (t.o.audio || t.o.trim || t.stage >= 2) -> t.phase.ifEmpty { "Processing…" }
                else -> "$part ${t.pct.toInt().coerceAtMost(100)}%"
            }
            val metrics = listOfNotNull(t.speed.takeIf { it.isNotEmpty() }, if (t.eta >= 0) "${fmt(t.eta.toInt())} left" else null)
            val details = metrics.joinToString(" • ")
            if (details.isEmpty()) progress else "$progress  •  $details"
        }
    }

    private fun refreshTasks() {
        if (!::taskAdapter.isInitialized) return
        taskAdapter.notifyDataSetChanged()
        val n = tasks.size
        ui.tabQueue.text = "Downloading ($n)"
        ui.taskList.visibility = if (showQueue) View.VISIBLE else View.GONE
        ui.fileList.visibility = if (showQueue) View.GONE else View.VISIBLE
        ui.queueBar.visibility = if (showQueue && n > 0) View.VISIBLE else View.GONE
        ui.fileTools.visibility = if (showQueue) View.GONE else View.VISIBLE
        ui.pauseAllBtn.text = if (DL.active()) "Pause all" else "Resume all"
        val empty = if (showQueue) n == 0 else items.isEmpty()
        ui.emptyView.visibility = if (empty) View.VISIBLE else View.GONE
        ui.emptyView.text = if (showQueue) "No active downloads.\nBrowse a site or paste a link to start." else "No downloaded files yet."
        if (n > 0) ui.nav.getOrCreateBadge(R.id.nav_downloads).number = n else ui.nav.removeBadge(R.id.nav_downloads)
    }

    private inner class TaskAdapter : BaseAdapter() {
        override fun getCount() = tasks.size
        override fun getItem(position: Int): Any = tasks[position]
        override fun getItemId(position: Int) = tasks[position].id.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val r = if (convertView != null) ItemTaskBinding.bind(convertView)
            else ItemTaskBinding.inflate(layoutInflater, parent, false)
            val t = tasks[position]
            r.title.text = t.title
            r.thumb.setImageBitmap(t.thumb)
            val shownDuration = if (t.o.trim) {
                val end = if (t.o.bEnd > 0) t.o.bEnd else t.duration
                (end - t.o.a).coerceAtLeast(0)
            } else t.duration
            r.dur.visibility = if (shownDuration > 0) View.VISIBLE else View.GONE
            r.dur.text = fmt(shownDuration)
            r.status.text = statusText(t)
            if (t.st == DL.St.RUNNING && t.pct < 0) {
                if (!r.bar.isIndeterminate) r.bar.isIndeterminate = true
            } else {
                if (r.bar.isIndeterminate) r.bar.isIndeterminate = false
                r.bar.setProgressCompat(t.pct.coerceIn(0f, 100f).toInt(), false)
            }
            val active = t.st == DL.St.RUNNING || t.st == DL.St.QUEUED
            r.pauseBtn.setImageResource(if (active) R.drawable.ic_pause else R.drawable.ic_play)
            r.pauseBtn.setOnClickListener { if (active) DL.pause(t) else DL.resume(t) }
            r.cancelBtn.setOnClickListener { DL.cancel(t) }
            r.root.setOnClickListener { if (t.st == DL.St.FAILED) errorDialog(t) } // tap a failed download for the full log
            return r.root
        }
    }

    // ---- downloaded files ----

    private fun loadFiles() {
        lifecycleScope.launch {
            allItems = withContext(Dispatchers.IO) { queryFiles() }
            applyFilter()
            refreshTasks()
        }
    }

    private fun applyFilter() {
        val q = ui.fileSearch.text.toString().trim().lowercase()
        val base = if (q.isEmpty()) allItems else allItems.filter { it.name.lowercase().contains(q) }
        items = when (prefs.getInt("sort", 0)) {
            1 -> base.sortedBy { it.added }
            2 -> base.sortedByDescending { it.size }
            3 -> base.sortedBy { it.name.lowercase() }
            else -> base.sortedByDescending { it.added }
        }
        ui.fileStats.text = "${items.size} files  •  ${fmtSize(items.sumOf { it.size })}"
        fileAdapter.notifyDataSetChanged()
    }

    private fun queryFiles(): List<Item> {
        val out = mutableListOf<Item>()
        val cols = arrayOf(
            MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.MIME_TYPE, MediaStore.MediaColumns.DATE_ADDED, MediaStore.MediaColumns.DURATION
        )
        for (coll in listOf(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, MediaStore.Audio.Media.EXTERNAL_CONTENT_URI)) {
            contentResolver.query(
                coll, cols, "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?", arrayOf("%${DL.folderName()}/"), null
            )?.use { c ->
                while (c.moveToNext()) {
                    out += Item(
                        ContentUris.withAppendedId(coll, c.getLong(0)), c.getString(1) ?: "file", c.getLong(2),
                        c.getString(3) ?: "video/mp4", c.getLong(4), c.getLong(5)
                    )
                }
            }
        }
        return out.sortedByDescending { it.added }
    }

    private inner class FileAdapter : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(position: Int): Any = items[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val r = if (convertView != null) ItemFileBinding.bind(convertView)
            else ItemFileBinding.inflate(layoutInflater, parent, false)
            val f = items[position]
            val base = f.name.substringBeforeLast('.')
            r.title.text = base
            r.dur.visibility = if (f.ms > 0) View.VISIBLE else View.GONE
            r.dur.text = fmt((f.ms / 1000).toInt())
            val res = Regex("""\((\d+)P\)""").find(f.name)?.groupValues?.get(1)?.let { "${it}P" }
            val parts = listOfNotNull(res, if (f.ms > 0) fmt((f.ms / 1000).toInt()) else null).joinToString(" | ")
            r.meta.text = if (parts.isEmpty()) fmtSize(f.size) else "$parts   •   ${fmtSize(f.size)}"
            r.cc.visibility = if ((prefs.getStringSet("cc", emptySet()) ?: emptySet()).contains(base)) View.VISIBLE else View.GONE
            r.root.tag = f.uri
            val cached = thumbCache.get(f.uri)
            if (cached != null) r.thumb.setImageBitmap(cached) else {
                r.thumb.setImageDrawable(null)
                lifecycleScope.launch {
                    val bmp = withContext(Dispatchers.IO) {
                        runCatching { contentResolver.loadThumbnail(f.uri, Size(192, 108), null) }.getOrNull()
                    }
                    if (bmp != null) { thumbCache.put(f.uri, bmp); if (r.root.tag == f.uri) r.thumb.setImageBitmap(bmp) }
                }
            }
            r.moreBtn.setOnClickListener { fileMenu(f) }
            r.root.setOnClickListener { openUri(f.uri, f.mime) }
            return r.root
        }
    }

    private fun fileMenu(f: Item) {
        MaterialAlertDialogBuilder(this).setTitle(f.name)
            .setItems(arrayOf("Open", "Share", "Rename", "Delete")) { _, which ->
                when (which) {
                    0 -> openUri(f.uri, f.mime)
                    1 -> shareUri(f.uri, f.mime)
                    2 -> renameDialog(f)
                    else -> {
                        val ok = runCatching { contentResolver.delete(f.uri, null, null) }.getOrDefault(0) > 0
                        if (!ok) say("Couldn't delete this file.")
                        loadFiles()
                    }
                }
            }.show()
    }

    private fun openUri(u: Uri, mime: String) {
        runCatching {
            startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(u, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        }
    }

    private fun shareUri(u: Uri, mime: String) {
        runCatching {
            startActivity(
                Intent.createChooser(
                    Intent(Intent.ACTION_SEND).setType(mime).putExtra(Intent.EXTRA_STREAM, u)
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), null
                )
            )
        }
    }

    // =====================  SETTINGS (download settings only)  =====================

    private fun setupSettings() {
        ui.settingsBox.addView(TextView(this).apply {
            text = "Download settings"; textSize = 26f; setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(22), dp(24), dp(22), dp(2))
        })
        addGroup("Quality & format")
        choiceRow("Default quality", "quality", listOf("Best (up to 4K)", "4K", "2K", "1080p", "720p", "480p", "360p", "Audio M4A", "Audio MP3 128K"), 0)
        switchRow("Embed metadata, chapters & cover art", "embed", true) { "Titles, chapters and album art inside the file" }
        addRow("Download folder", { "Movies/${DL.folderName()}  •  Music/${DL.folderName()}" }, {
            val et = EditText(this).apply { setText(DL.folderName()); setPadding(dp(24), dp(16), dp(24), dp(16)) }
            MaterialAlertDialogBuilder(this).setTitle("Folder name").setView(et)
                .setPositiveButton("Save") { _, _ -> prefs.edit().putString("folder", et.text.toString()).apply(); refreshSettings() }
                .setNegativeButton("Cancel", null).show()
        })
        addGroup("Speed")
        switchRow("Fast reading (recommended)", "fast", true) { "Quicker YouTube client; turn off if a video fails to load" }
        switchRow("Turbo downloads (aria2c)", "turbo", true) { "Up to 16 connections per file — much faster; falls back by itself" }
        choiceRow("Simultaneous downloads", "parallel", listOf("1", "2", "3"), 1)
        choiceRow("Connections per download", "threads", listOf("1", "4 (faster)", "8 (fastest)"), 2)
        choiceRow("Speed limit", "speed", listOf("Unlimited", "1 MB/s", "2 MB/s", "5 MB/s"), 0)
        addGroup("Behaviour")
        switchRow("Ask before downloading", "ask", true) { "Off = one tap starts the download with your default quality" }
        switchRow("Wi‑Fi only", "wifi", false) { "Wait for Wi‑Fi instead of using mobile data" }
        switchRow("Auto-retry", "retry", true) { "Tries again twice when the connection drops" }
        switchRow("Precise trimming by default", "precise", false) { "Slower, but cuts exactly at your times" }
        addGroup("Account & engine")
        switchRow("Use my Google account", "use_account", true) {
            when {
                DL.imported() -> "Using the imported cookies file"
                DL.signedIn() -> "Signed in through the Browse tab"
                else -> "Not linked — tap the account icon in Browse"
            }
        }
        addRow("Download engine (yt-dlp)", { "Version ${DL.version.ifEmpty { "…" }}  •  tap to update now" }, {
            say("Updating the engine…", false)
            lifecycleScope.launch {
                val v = withContext(Dispatchers.IO) { runCatching { DL.updateEngine() }.getOrDefault("") }
                say(if (v.isEmpty()) "Update failed — check the connection." else "Engine updated: $v")
                refreshSettings()
            }
        })
        group = null
    }

    /** iOS-style inset group: a small header and a rounded card that holds the rows. */
    private fun addGroup(title: String) {
        ui.settingsBox.addView(TextView(this).apply {
            text = title.uppercase(); textSize = 12f; alpha = 0.6f; letterSpacing = 0.06f
            setPadding(dp(22), dp(20), dp(22), dp(6))
        })
        val inner = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val card = com.google.android.material.card.MaterialCardView(this, null, com.google.android.material.R.attr.materialCardViewFilledStyle)
        card.addView(inner, android.widget.FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, W))
        ui.settingsBox.addView(card, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, W).apply { setMargins(dp(12), 0, dp(12), 0) })
        group = inner
    }

    private fun refreshSettings() { refreshers.forEach { it() } }

    private fun addRow(title: String, sub: () -> String, tap: () -> Unit, sw: MaterialSwitch? = null) {
        val tv = TypedValue()
        theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
        val row = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            setBackgroundResource(tv.resourceId)
            setOnClickListener { tap() }
        }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val s = TextView(this).apply { text = sub(); textSize = 13f; alpha = 0.7f }
        col.addView(TextView(this).apply { text = title; textSize = 16f })
        col.addView(s)
        row.addView(col, LinearLayout.LayoutParams(0, W, 1f))
        sw?.let { row.addView(it) }
        val g = group
        if (g != null) {
            if (g.childCount > 0) g.addView(View(this).apply { setBackgroundColor(0x22808080) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1).apply { marginStart = dp(16) })
            g.addView(row)
        } else ui.settingsBox.addView(row)
        refreshers += { s.text = sub() }
    }

    private fun choiceRow(title: String, key: String, labels: List<String>, def: Int) {
        addRow(title, { labels[prefs.getInt(key, def).coerceIn(labels.indices)] }, {
            MaterialAlertDialogBuilder(this).setTitle(title)
                .setSingleChoiceItems(labels.toTypedArray(), prefs.getInt(key, def)) { d, i ->
                    prefs.edit().putInt(key, i).apply(); d.dismiss(); refreshSettings()
                }.show()
        })
    }

    private fun switchRow(title: String, key: String, def: Boolean, sub: () -> String) {
        val sw = MaterialSwitch(this).apply {
            isChecked = prefs.getBoolean(key, def)
            setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean(key, c).apply() }
        }
        addRow(title, sub, { sw.toggle() }, sw)
    }

    // =====================  live speed meter  =====================

    /** Once a second: total speed of all running downloads, shown with a small live graph. */
    private fun startSpeedMeter() {
        lifecycleScope.launch {
            while (true) {
                delay(1000)
                val running = tasks.count { it.st == DL.St.RUNNING }
                val total = DL.totalSpeed()
                ui.speedGraph.push(total)
                if (running > 0) { peakBps = maxOf(peakBps, total); sumBps += total; cntBps++ } else { peakBps = 0L; sumBps = 0L; cntBps = 0 }
                val show = showQueue && running > 0 && ui.downloadsPane.visibility == View.VISIBLE
                ui.speedCard.visibility = if (show) View.VISIBLE else View.GONE
                if (show) {
                    ui.speedValue.text = fmtSpeed(total)
                    ui.speedSub.text = "$running active  •  peak ${fmtSpeed(peakBps)}  •  avg ${fmtSpeed(if (cntBps > 0) sumBps / cntBps else 0L)}"
                }
            }
        }
    }

    // =====================  search suggestions, recent searches, rename, paste  =====================

    private fun recents(): List<String> = (prefs.getString("recents", "") ?: "").split("\n").filter { it.isNotBlank() }

    private fun addRecent(t: String) {
        val l = (listOf(t) + recents().filter { !it.equals(t, ignoreCase = true) }).take(8)
        prefs.edit().putString("recents", l.joinToString("\n")).apply()
    }

    private fun rowView(text: String, dim: Boolean = false, onTap: () -> Unit): TextView {
        val tv = TypedValue()
        theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
        return TextView(this).apply {
            this.text = text; textSize = 15f; alpha = if (dim) 0.55f else 0.95f; maxLines = 1
            setPadding(dp(18), dp(12), dp(18), dp(12)); setBackgroundResource(tv.resourceId)
            setOnClickListener { onTap() }
        }
    }

    private fun showRows(rows: List<String>, clearable: Boolean = false) {
        ui.suggestBox.removeAllViews()
        rows.forEach { item -> ui.suggestBox.addView(rowView(item) { ui.searchBox.setText(item); ui.searchBox.setSelection(item.length); submitSearch() }) }
        if (clearable && rows.isNotEmpty()) {
            ui.suggestBox.addView(rowView("Clear history", dim = true) { prefs.edit().remove("recents").apply(); showRows(emptyList()) })
        }
        ui.suggestBox.visibility = if (ui.suggestBox.childCount > 0) View.VISIBLE else View.GONE
    }

    /** Live suggestions from YouTube while typing; recent searches when the box is empty. */
    private fun fetchSuggestions(q: String) {
        if (!ui.searchBox.hasFocus() || ui.homePane.visibility != View.VISIBLE) { ui.suggestBox.visibility = View.GONE; return }
        if (q.startsWith("http")) { // a link is being pasted/typed: start reading it now so the sheet opens instantly
            val l = extractUrl(q)
            if (DL.ready && ytRe.containsMatchIn(l)) { DL.info(l); if (DL.fastMode()) DL.infoFull(l) }
            showRows(emptyList()); return
        }
        if (q.isEmpty()) { showRows(recents(), true); return }
        lifecycleScope.launch {
            val list = withContext(Dispatchers.IO) {
                runCatching {
                    val c = URL("https://suggestqueries.google.com/complete/search?client=firefox&ds=yt&q=" + Uri.encode(q)).openConnection() as HttpURLConnection
                    c.connectTimeout = 3000
                    c.readTimeout = 3000
                    val arr = JSONArray(c.inputStream.bufferedReader().readText()).getJSONArray(1)
                    (0 until minOf(arr.length(), 6)).map { arr.getString(it) }
                }.getOrDefault(emptyList())
            }
            if (ui.searchBox.text.toString().trim() == q && ui.searchBox.hasFocus()) showRows(list)
        }
    }

    private fun renameDialog(f: Item) {
        val base = f.name.substringBeforeLast('.')
        val ext = f.name.substringAfterLast('.', "")
        val et = EditText(this).apply { setText(base); setPadding(dp(24), dp(16), dp(24), dp(16)) }
        MaterialAlertDialogBuilder(this).setTitle("Rename").setView(et)
            .setPositiveButton("Save") { _, _ ->
                val nn = et.text.toString().trim().filter { c -> c.isLetterOrDigit() || c in " _-.()[]!&'" || c.code > 127 }
                if (nn.isNotEmpty()) {
                    val cv = ContentValues().apply { put(MediaStore.MediaColumns.DISPLAY_NAME, if (ext.isEmpty()) nn else "$nn.$ext") }
                    val ok = runCatching { contentResolver.update(f.uri, cv, null, null) }.getOrDefault(0) > 0
                    if (!ok) say("Couldn't rename this file.")
                    loadFiles()
                }
            }.setNegativeButton("Cancel", null).show()
    }

    /** From the "Paste & download" launcher shortcut. */
    private fun doPaste() {
        pasteRequest = false
        val u = extractUrl(clipText())
        if (u.isNotEmpty()) openSheet(u) else say("There is no link in the clipboard.")
    }

    // =====================  quick add, playlists, errors  =====================

    private fun askNotif() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    /** Adds links straight to the queue with the default quality (no sheet). */
    private fun quickAdd(urls: List<String>, titles: List<String> = emptyList()) {
        val q = prefChoice()
        urls.forEachIndexed { i, u ->
            val dir = File(getExternalFilesDir(null) ?: filesDir, "tasks/${UUID.randomUUID()}").apply { mkdirs() }
            val o = DL.Opts(q.audio, q.h, false, 0, 0, prefs.getBoolean("precise", false), null, false, true, false, false, q.afmt, q.abr)
            DL.add(DL.Task(DL.nextId++, u, titles.getOrNull(i) ?: u, null, o, null, null, dir))
        }
        askNotif()
        ui.root.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
        Snackbar.make(ui.root, if (urls.size == 1) "Added to downloads" else "Added ${urls.size} downloads", Snackbar.LENGTH_LONG)
            .setAction("View") { ui.nav.selectedItemId = R.id.nav_downloads }.show()
    }

    private fun batchDialog(urls: List<String>) {
        MaterialAlertDialogBuilder(this).setTitle("Download ${urls.size} links?")
            .setMessage("They will use your default quality from Settings.")
            .setPositiveButton("Download all") { _, _ -> quickAdd(urls) }
            .setNegativeButton("Cancel", null).show()
    }

    private fun openPlaylist(l: String) {
        if (!DL.ready) return say("The engine is still starting. Try again in a moment.")
        say("Reading the playlist…")
        lifecycleScope.launch {
            try {
                val (name, list) = withContext(Dispatchers.IO) { DL.playlist(l) }
                if (list.isEmpty()) { say("The playlist is empty."); return@launch }
                val checked = BooleanArray(list.size) { true }
                MaterialAlertDialogBuilder(this@MainActivity).setTitle("$name (${list.size})")
                    .setMultiChoiceItems(list.map { it.title }.toTypedArray(), checked) { _, i, c -> checked[i] = c }
                    .setPositiveButton("Download selected") { _, _ ->
                        val sel = list.filterIndexed { i, _ -> checked[i] }
                        if (sel.isNotEmpty()) quickAdd(sel.map { it.url }, sel.map { it.title })
                    }
                    .setNegativeButton("Cancel", null).show()
            } catch (e: Exception) {
                say("Couldn't read the playlist: ${msgOf(e)}")
            }
        }
    }

    private fun errorDialog(t: DL.Task) {
        val text = "${t.title}\n${t.link}\n\n${t.errFull.ifEmpty { t.err }}".take(4000)
        MaterialAlertDialogBuilder(this).setTitle("Download failed").setMessage(text)
            .setPositiveButton("Copy") { _, _ ->
                (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("YtClip error", text))
                say("Copied")
            }
            .setNeutralButton("Share") { _, _ -> shareText(text) }
            .setNegativeButton("Close", null).show()
    }

    private fun shareText(text: String) {
        runCatching {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text), null))
        }
    }

    /** If the app ever crashes, the next launch shows the error so it can be shared and fixed. */
    private fun installCrashHandler() {
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { th, e ->
            runCatching {
                File(filesDir, "crash.txt").writeText("${Build.MODEL} • Android ${Build.VERSION.RELEASE}\n" + e.stackTraceToString().take(6000))
            }
            prev?.uncaughtException(th, e)
        }
    }

    private fun showLastCrash() {
        val f = File(filesDir, "crash.txt")
        if (!f.exists()) return
        val text = runCatching { f.readText() }.getOrDefault("")
        f.delete()
        if (text.isEmpty()) return
        MaterialAlertDialogBuilder(this).setTitle("YtClip closed unexpectedly last time")
            .setMessage(text.take(2500))
            .setPositiveButton("Share report") { _, _ -> shareText(text) }
            .setNegativeButton("Dismiss", null).show()
    }

    // =====================  helpers  =====================

    private fun say(m: String, toast: Boolean = true) = runOnUiThread {
        ui.hintView.text = m
        if (toast) Toast.makeText(this, m, Toast.LENGTH_LONG).show()
    }

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
}
