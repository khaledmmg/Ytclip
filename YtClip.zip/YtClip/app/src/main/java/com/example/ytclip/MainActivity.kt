package com.example.ytclip

import android.Manifest
import android.app.NotificationManager
import android.content.ClipboardManager
import android.content.ContentUris
import android.content.pm.PackageManager
import android.os.Build
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.text.InputFilter
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.MimeTypeMap
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.button.MaterialButton
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.color.DynamicColors
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.progressindicator.LinearProgressIndicator
import com.google.android.material.slider.RangeSlider
import com.google.android.material.textfield.TextInputEditText
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : AppCompatActivity() {

    private val pid = "ytclip-download"
    private val infoPid = "ytclip-info"
    private val timeRe = Regex("""time=(\d+):(\d+):(\d+)""")
    private val W = ViewGroup.LayoutParams.WRAP_CONTENT
    private var ready = false
    private var cancelled = false
    private var link = ""
    private var gen = 0
    private var duration = 0
    private var selStart = 0
    private var selEnd = 0          // 0 = until the end of the video
    private var infoFile: File? = null
    private var infoJob: Deferred<File>? = null
    private var browseUrl = ""
    private var savedUri: Uri? = null
    private var savedMime = "video/mp4"
    private lateinit var typeFields: List<EditText>
    private var lastClip = ""
    private var lastNotif = 0L

    private class Item(val uri: Uri, val name: String, val size: Long, val mime: String, val added: Long)
    private var items = listOf<Item>()
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    private val qBase = mapOf(
        R.id.qBest to "Best", R.id.q2160 to "4K", R.id.q1440 to "2K", R.id.q1080 to "1080p",
        R.id.q720 to "720p", R.id.q480 to "480p", R.id.q360 to "360p", R.id.qAudio to "Audio only"
    )
    private val qHeight = mapOf(
        R.id.q2160 to 2160, R.id.q1440 to 1440, R.id.q1080 to 1080,
        R.id.q720 to 720, R.id.q480 to 480, R.id.q360 to 360
    )
    private val filesPane by lazy { v<View>(R.id.filesPane) }
    private val filesList by lazy { v<ListView>(R.id.filesList) }
    private val filesEmpty by lazy { v<TextView>(R.id.filesEmpty) }
    private val shareBtn by lazy { v<View>(R.id.shareBtn) }

    private fun <T : View> v(id: Int): T = findViewById(id)
    private val nav by lazy { v<BottomNavigationView>(R.id.nav) }
    private val scroll by lazy { v<ScrollView>(R.id.scroll) }
    private val browserPane by lazy { v<View>(R.id.browserPane) }
    private val web by lazy { v<WebView>(R.id.web) }
    private val addressBar by lazy { v<TextInputEditText>(R.id.addressBar) }
    private val sites by lazy { v<LinearLayout>(R.id.sites) }
    private val dlFab by lazy { v<View>(R.id.dlFab) }
    private val hintView by lazy { v<TextView>(R.id.hintView) }
    private val url by lazy { v<TextInputEditText>(R.id.url) }
    private val pasteBtn by lazy { v<View>(R.id.pasteBtn) }
    private val fetchBtn by lazy { v<android.widget.Button>(R.id.fetchBtn) }
    private val previewCard by lazy { v<View>(R.id.previewCard) }
    private val thumb by lazy { v<ImageView>(R.id.thumb) }
    private val titleView by lazy { v<TextView>(R.id.titleView) }
    private val metaView by lazy { v<TextView>(R.id.metaView) }
    private val optionsCard by lazy { v<View>(R.id.optionsCard) }
    private val qualityGroup by lazy { v<ChipGroup>(R.id.qualityGroup) }
    private val trimSwitch by lazy { v<MaterialSwitch>(R.id.trimSwitch) }
    private val trimBox by lazy { v<LinearLayout>(R.id.trimBox) }
    private val modeGroup by lazy { v<MaterialButtonToggleGroup>(R.id.modeGroup) }
    private val trimLabel by lazy { v<TextView>(R.id.trimLabel) }
    private val sliderBox by lazy { v<View>(R.id.sliderBox) }
    private val range by lazy { v<RangeSlider>(R.id.range) }
    private val nudgeBox by lazy { v<LinearLayout>(R.id.nudgeBox) }
    private val typeBox by lazy { v<LinearLayout>(R.id.typeBox) }
    private val precise by lazy { v<CheckBox>(R.id.precise) }
    private val downloadBtn by lazy { v<View>(R.id.downloadBtn) }
    private val progressCard by lazy { v<View>(R.id.progressCard) }
    private val status by lazy { v<TextView>(R.id.status) }
    private val bar by lazy { v<LinearProgressIndicator>(R.id.bar) }
    private val details by lazy { v<TextView>(R.id.details) }
    private val cancelBtn by lazy { v<View>(R.id.cancelBtn) }
    private val openBtn by lazy { v<View>(R.id.openBtn) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DynamicColors.applyToActivityIfAvailable(this)
        setContentView(R.layout.activity_main)

        if (intent.action == Intent.ACTION_SEND) {
            intent.getStringExtra(Intent.EXTRA_TEXT)?.let { url.setText(extractUrl(it)) }
        }

        // ---------- trim ----------
        range.values = listOf(0f, 100f)
        range.isEnabled = false
        range.setLabelFormatter { fmt(it.toInt()) }
        range.addOnChangeListener { s, _, _ ->
            selStart = s.values[0].toInt()
            selEnd = s.values[1].toInt()
            refreshTrimUi()
        }
        buildTrimTools()
        trimSwitch.setOnCheckedChangeListener { _, on ->
            trimBox.visibility = if (on) View.VISIBLE else View.GONE
            refreshTrimUi()
        }
        modeGroup.addOnButtonCheckedListener { _, id, checked ->
            if (!checked) return@addOnButtonCheckedListener
            val typing = id == R.id.modeType
            if (typing) fillFields() else {
                readFields()
                if (duration > 1) applySel(selStart, if (selEnd > 0) selEnd else duration)
            }
            typeBox.visibility = if (typing) View.VISIBLE else View.GONE
            sliderBox.visibility = if (typing) View.GONE else View.VISIBLE
            refreshTrimUi()
        }

        // ---------- download tab ----------
        pasteBtn.setOnClickListener {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            val t = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)
                ?.coerceToText(this)?.toString().orEmpty()
            url.setText(extractUrl(t).ifEmpty { t })
            fetch()
        }
        fetchBtn.setOnClickListener { fetch() }
        downloadBtn.setOnClickListener {
            if (link.isEmpty()) return@setOnClickListener say("Fetch a link first.")
            val trim = trimSwitch.isChecked
            val (a, b) = trimRange()
            if (trim && b > 0 && b <= a) return@setOnClickListener say("The end time must be after the start time.")
            if (trim && duration > 0 && a >= duration) return@setOnClickListener say("The start time is after the end of the video.")
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
            startDownload(qualityGroup.checkedChipId, trim, a, b, precise.isChecked)
        }
        cancelBtn.setOnClickListener {
            cancelled = true
            infoJob?.cancel()
            YoutubeDL.getInstance().destroyProcessById(infoPid)
            YoutubeDL.getInstance().destroyProcessById(pid)
        }
        openBtn.setOnClickListener {
            val u = savedUri ?: return@setOnClickListener
            runCatching {
                startActivity(
                    Intent(Intent.ACTION_VIEW).setDataAndType(u, savedMime)
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                )
            }
        }

        shareBtn.setOnClickListener { savedUri?.let { shareUri(it, savedMime) } }
        filesList.setOnItemClickListener { _, _, i, _ -> openUri(items[i].uri, items[i].mime) }
        filesList.setOnItemLongClickListener { _, _, i, _ -> fileMenu(items[i]); true }
        KeepAliveService.onCancel = { runOnUiThread { cancelBtn.performClick() } }

        // ---------- browser tab ----------
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = object : WebViewClient() {
            override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
                onBrowse(url)
            }
        }
        listOf(
            "YouTube" to "https://m.youtube.com", "Facebook" to "https://m.facebook.com",
            "Instagram" to "https://www.instagram.com", "TikTok" to "https://www.tiktok.com",
            "X" to "https://x.com"
        ).forEach { (name, u) ->
            sites.addView(Chip(this).apply { text = name; setOnClickListener { web.loadUrl(u) } })
        }
        addressBar.setOnEditorActionListener { _, action, _ ->
            if (action == EditorInfo.IME_ACTION_GO) { go(); true } else false
        }
        dlFab.setOnClickListener {
            url.setText(browseUrl)
            nav.selectedItemId = R.id.nav_download
            fetch()
        }
        nav.setOnItemSelectedListener { item ->
            val b = item.itemId == R.id.nav_browser
            val f = item.itemId == R.id.nav_files
            browserPane.visibility = if (b) View.VISIBLE else View.GONE
            filesPane.visibility = if (f) View.VISIBLE else View.GONE
            scroll.visibility = if (b || f) View.GONE else View.VISIBLE
            if (b && web.url == null) web.loadUrl("https://m.youtube.com")
            if (f) loadFiles()
            true
        }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val tab = nav.selectedItemId
                when {
                    tab == R.id.nav_browser && web.canGoBack() -> web.goBack()
                    tab != R.id.nav_download -> nav.selectedItemId = R.id.nav_download
                    else -> finish()
                }
            }
        })

        // ---------- engine ----------
        lifecycleScope.launch {
            try {
                val prefs = getSharedPreferences("ytclip", MODE_PRIVATE)
                val due = System.currentTimeMillis() - prefs.getLong("upd", 0L) > 24 * 3600 * 1000L
                withContext(Dispatchers.IO) {
                    YoutubeDL.getInstance().init(application)
                    FFmpeg.getInstance().init(application)
                    if (due) { // update yt-dlp at most once a day, so startup stays fast
                        say("Updating engine…", false)
                        runCatching {
                            YoutubeDL.getInstance().updateYoutubeDL(application, YoutubeDL.UpdateChannel.STABLE)
                        }.onSuccess { prefs.edit().putLong("upd", System.currentTimeMillis()).apply() }
                    }
                }
                ready = true
                say("Ready. Paste a link or open the Browser tab.", false)
                if (url.text?.isNotBlank() == true) fetch()
            } catch (e: Exception) {
                say("Startup failed: ${msg(e)}")
            }
        }
    }

    // =====================  browser  =====================

    private fun go() {
        val t = addressBar.text.toString().trim()
        if (t.isEmpty()) return
        val u = when {
            t.startsWith("http") -> t
            t.contains(".") && !t.contains(" ") -> "https://$t"
            else -> "https://www.google.com/search?q=" + Uri.encode(t)
        }
        web.loadUrl(u)
        addressBar.clearFocus()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(addressBar.windowToken, 0)
    }

    private fun onBrowse(u: String?) {
        browseUrl = u.orEmpty()
        if (!addressBar.hasFocus()) addressBar.setText(browseUrl)
        val yt = Regex("""(youtube\.com/(watch|shorts)|youtu\.be/)""").containsMatchIn(browseUrl)
        val other = !browseUrl.contains("youtube.com") && !browseUrl.contains("google.") &&
            Regex("""https?://[^/]+/.+""").containsMatchIn(browseUrl)
        dlFab.visibility = if (yt || other) View.VISIBLE else View.GONE
    }

    // =====================  fetch (fast)  =====================

    /**
     * 1) Instant preview (title + thumbnail) from YouTube's oEmbed – under a second.
     * 2) yt-dlp reads the full details ONCE, in the background, and saves them to a file.
     * 3) The download re-uses that file (--load-info-json), so yt-dlp never extracts twice.
     */
    private fun fetch() {
        val l = extractUrl(url.text.toString())
        if (l.isEmpty()) return say("Paste a YouTube link first.")
        if (!ready) return say("The engine is still starting. Try again in a moment.")
        val g = ++gen
        link = l; duration = 0; infoFile = null
        infoJob?.cancel()
        YoutubeDL.getInstance().destroyProcessById(infoPid)

        titleView.text = "Loading…"
        metaView.text = "Reading video details…"
        thumb.setImageDrawable(null)
        previewCard.visibility = View.VISIBLE
        optionsCard.visibility = View.VISIBLE
        trimSwitch.isChecked = false
        selStart = 0; selEnd = 0
        range.isEnabled = false
        resetChips()
        fillFields()
        refreshTrimUi()
        say("Choose a quality — you can press Download right away.", false)

        lifecycleScope.launch {
            val quick = withContext(Dispatchers.IO) { quickPreview(l) }
            if (quick != null && g == gen && duration == 0) {
                titleView.text = quick.first
                quick.second?.let { thumb.setImageBitmap(it) }
            }
        }

        val job = lifecycleScope.async(Dispatchers.IO) { extractInfo(l) }
        infoJob = job
        lifecycleScope.launch {
            try {
                val f = job.await()
                if (g != gen) return@launch
                infoFile = f
                val j = withContext(Dispatchers.IO) { JSONObject(f.readText()) }
                duration = j.optInt("duration", 0)
                j.optString("title").takeIf { it.isNotEmpty() }?.let { titleView.text = it }
                metaView.text = if (duration > 0) "Length ${fmt(duration)}" else "Live or unknown length"
                if (duration > 1) onDurationKnown()
                updateChips(j)
                val tu = j.optString("thumbnail")
                if (thumb.drawable == null && tu.isNotEmpty()) {
                    withContext(Dispatchers.IO) { bitmap(tu) }?.let { thumb.setImageBitmap(it) }
                }
            } catch (e: Exception) {
                if (g == gen) metaView.text = "Couldn't read details: ${msg(e)}"
            }
        }
    }

    private fun extractInfo(l: String): File {
        val req = YoutubeDLRequest(l).apply {
            addOption("--dump-single-json")
            addOption("--no-playlist")
            addOption("--no-warnings")
        }
        val out = YoutubeDL.getInstance().execute(req, infoPid) { _, _, _ -> }.out
        val json = out.lines().lastOrNull { it.trimStart().startsWith("{") }
            ?: error("No video details were returned")
        return File(cacheDir, "info-${System.currentTimeMillis()}.json").apply { writeText(json) }
    }

    private fun quickPreview(l: String): Pair<String, Bitmap?>? = runCatching {
        val c = URL("https://www.youtube.com/oembed?format=json&url=" + Uri.encode(l))
            .openConnection() as HttpURLConnection
        c.connectTimeout = 4000
        c.readTimeout = 4000
        val j = JSONObject(c.inputStream.bufferedReader().readText())
        Pair(j.getString("title"), bitmap(j.optString("thumbnail_url")))
    }.getOrNull()

    private fun bitmap(u: String): Bitmap? =
        runCatching { URL(u).openStream().use { BitmapFactory.decodeStream(it) } }.getOrNull()

    // =====================  trim  =====================

    private fun onDurationKnown() {
        range.valueFrom = 0f
        range.valueTo = duration.toFloat()
        range.stepSize = 1f
        range.isEnabled = true
        selStart = selStart.coerceIn(0, duration - 1)
        if (selEnd <= selStart || selEnd > duration) selEnd = duration
        range.values = listOf(selStart.toFloat(), selEnd.toFloat())
        refreshTrimUi()
    }

    private fun applySel(a: Int, b: Int) {
        if (duration < 2) return
        selStart = a.coerceIn(0, duration - 1)
        selEnd = b.coerceIn(selStart + 1, duration)
        range.values = listOf(selStart.toFloat(), selEnd.toFloat())
        refreshTrimUi()
    }

    private fun refreshTrimUi() {
        trimLabel.text = when {
            modeGroup.checkedButtonId == R.id.modeType ->
                "Type start and end time (leave End empty to go to the end)"
            duration <= 1 -> "Loading video length…"
            else -> "${fmt(selStart)}  →  ${fmt(selEnd)}      (clip ${fmt(selEnd - selStart)})"
        }
    }

    /** Returns (startSeconds, endSeconds). End <= 0 means "until the end of the video". */
    private fun trimRange(): Pair<Int, Int> {
        if (modeGroup.checkedButtonId == R.id.modeType) readFields()
        return Pair(selStart, selEnd)
    }

    private fun buildTrimTools() {
        typeFields = timeRow("Start") + timeRow("End")
        for ((name, isStart) in listOf("Start" to true, "End" to false)) {
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            row.addView(TextView(this).apply { text = name }, LinearLayout.LayoutParams(dp(52), W))
            for (d in listOf(-10, -1, 1, 10)) {
                val label = if (d > 0) "+${d}s" else "−${-d}s"
                row.addView(smallBtn(label) {
                    if (isStart) applySel(selStart + d, selEnd) else applySel(selStart, selEnd + d)
                }, LinearLayout.LayoutParams(0, W, 1f).apply { marginStart = dp(4) })
            }
            nudgeBox.addView(row)
        }
        val presets = LinearLayout(this)
        listOf<Pair<String, () -> Unit>>(
            "Reset" to { applySel(0, duration) },
            "First 30s" to { applySel(0, 30) },
            "First 60s" to { applySel(0, 60) },
            "Last 30s" to { applySel(duration - 30, duration) }
        ).forEach { (t, action) ->
            presets.addView(smallBtn(t, action), LinearLayout.LayoutParams(0, W, 1f).apply { marginEnd = dp(4) })
        }
        nudgeBox.addView(presets)
    }

    private fun smallBtn(t: String, onClick: () -> Unit) =
        MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            text = t
            textSize = 12f
            minWidth = 0
            minimumWidth = 0
            insetTop = 0
            insetBottom = 0
            setPadding(0, 0, 0, 0)
            setOnClickListener { onClick() }
        }

    private fun timeRow(name: String): List<EditText> {
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        row.addView(TextView(this).apply { text = name }, LinearLayout.LayoutParams(dp(52), W))
        val fields = listOf("hh", "mm", "ss").mapIndexed { i, u ->
            if (i > 0) row.addView(TextView(this).apply { text = " : " })
            EditText(this).apply {
                hint = u
                inputType = InputType.TYPE_CLASS_NUMBER
                filters = arrayOf(InputFilter.LengthFilter(2))
                gravity = Gravity.CENTER
            }.also { row.addView(it, LinearLayout.LayoutParams(0, W, 1f)) }
        }
        typeBox.addView(row)
        return fields
    }

    private fun secs(i: Int): Int {
        val p = (0..2).map { typeFields[i + it].text.toString().toIntOrNull() ?: 0 }
        return p[0] * 3600 + p[1] * 60 + p[2]
    }

    private fun readFields() {
        selStart = secs(0)
        val e = secs(3)
        selEnd = if (e > 0) e else duration
    }

    private fun fillFields() {
        fun put(i: Int, t: Int) {
            val parts = if (t <= 0) listOf("", "", "") else listOf(t / 3600, t % 3600 / 60, t % 60).map { it.toString() }
            for (k in 0..2) typeFields[i + k].setText(parts[k])
        }
        put(0, selStart)
        put(3, selEnd)
    }

    // =====================  download  =====================

    private fun startDownload(chip: Int, trim: Boolean, a: Int, b: Int, accurate: Boolean) =
        lifecycleScope.launch {
            cancelled = false
            setBusy(true)
            ContextCompat.startForegroundService(
                this@MainActivity, Intent(this@MainActivity, KeepAliveService::class.java)
            )
            status.text = "Preparing…"
            details.text = ""
            setBar(null)
            val t0 = System.currentTimeMillis()
            val ticker = launch {
                while (true) {
                    delay(1000)
                    if (bar.isIndeterminate)
                        details.text = "Elapsed " + fmt(((System.currentTimeMillis() - t0) / 1000).toInt())
                }
            }
            try {
                if (infoFile == null) { // details still loading: wait for them (needed anyway)
                    status.text = "Reading video details…"
                    infoFile = runCatching { infoJob?.await() }.getOrNull()
                }
                if (cancelled) error("Cancelled")
                val r = withContext(Dispatchers.IO) { download(chip, trim, a, b, accurate) }
                savedUri = r.first
                savedMime = r.second
                setBar(100f)
                status.text = "Done ✓  Saved to ${r.third}"
                details.text = "You can find it in your gallery."
                openBtn.visibility = View.VISIBLE
                shareBtn.visibility = View.VISIBLE
                notifyDone("Saved ✓  ${r.third}")
            } catch (e: Exception) {
                status.text = if (cancelled) "Cancelled" else "Failed"
                details.text = if (cancelled) "" else msg(e)
            } finally {
                ticker.cancel()
                setBusy(false)
                stopService(Intent(this@MainActivity, KeepAliveService::class.java))
            }
        }

    private fun download(chip: Int, trim: Boolean, a: Int, b: Int, accurate: Boolean): Triple<Uri, String, String> {
        val dir = File(cacheDir, "dl/${System.currentTimeMillis()}").apply { mkdirs() }
        try {
            val audio = chip == R.id.qAudio
            val h = when (chip) {
                R.id.q2160 -> 2160; R.id.q1440 -> 1440; R.id.q1080 -> 1080
                R.id.q720 -> 720; R.id.q480 -> 480; R.id.q360 -> 360; else -> 2160
            }
            // up to 1080p: H.264 (plays everywhere). 2K/4K only exist as VP9/AV1, so prefer VP9.
            val codec = if (h <= 1080) "h264" else "vp9"

            fun build(useInfo: Boolean): YoutubeDLRequest {
                val f = infoFile?.takeIf { useInfo && it.exists() }
                return (if (f != null) YoutubeDLRequest(emptyList<String>()) else YoutubeDLRequest(link)).apply {
                    if (f != null) addOption("--load-info-json", f.absolutePath)
                    addOption("--no-playlist")
                    addOption("-N", "4")
                    addOption("-o", "${dir.absolutePath}/%(title).80s.%(ext)s")
                    if (audio) {
                        addOption("-f", "ba[ext=m4a]/ba/b")
                        addOption("-x")
                        addOption("--audio-format", "m4a")
                    } else {
                        addOption("-f", "bv*+ba[ext=m4a]/bv*+ba/b")
                        addOption("-S", "res:$h,vcodec:$codec,acodec:aac") // res = smallest side (portrait-safe)
                        addOption("--merge-output-format", "mp4")
                    }
                    if (trim) {
                        addOption("--download-sections", "*$a-${if (b > 0) b.toString() else "inf"}")
                        if (accurate) addOption("--force-keyframes-at-cuts")
                    }
                }
            }

            var stage = 0
            val clipLen = if (!trim) 0 else (if (b > 0) b else duration) - a
            val onLine: (Float, Long, String) -> Unit = { pct, eta, line ->
                if (line.contains("Destination:")) stage++
                val tm = timeRe.find(line)
                val frac: Float? = when {
                    trim && tm != null && clipLen > 0 -> {
                        val (hh, mm, ss) = tm.destructured
                        (hh.toInt() * 3600 + mm.toInt() * 60 + ss.toInt()) * 100f / clipLen
                    }
                    trim -> null
                    pct >= 0f -> pct
                    else -> null
                }
                val label = when {
                    audio -> "Downloading audio"
                    trim -> "Downloading your clip"
                    stage >= 2 -> "Downloading audio"
                    else -> "Downloading video"
                }
                runOnUiThread {
                    status.text = if (frac != null && frac >= 100f && (audio || trim || stage >= 2)) "Processing…" else label
                    setBar(frac)
                    notifyProgress(label, frac)
                    if (frac != null) {
                        details.text = "${frac.toInt().coerceAtMost(100)}%" +
                            if (!trim && eta >= 0) "   •   ${fmt(eta.toInt())} left" else ""
                    }
                }
            }

            try {
                YoutubeDL.getInstance().execute(build(true), pid, onLine)
            } catch (e: Exception) {
                if (cancelled || infoFile == null) throw e
                runOnUiThread { status.text = "Retrying…" }  // saved details may have expired
                stage = 0
                YoutubeDL.getInstance().execute(build(false), pid, onLine)
            }

            val file = dir.listFiles()
                ?.filter { !it.name.endsWith(".part") && !it.name.endsWith(".ytdl") }
                ?.maxByOrNull { it.length() } ?: error("No output file was produced")

            val mime = if (audio) "audio/mp4"
            else MimeTypeMap.getSingleton().getMimeTypeFromExtension(file.extension) ?: "video/mp4"
            val folder = if (audio) Environment.DIRECTORY_MUSIC else Environment.DIRECTORY_MOVIES
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, file.name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, "$folder/YtClip")
            }
            val coll = if (audio) MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            val uri = contentResolver.insert(coll, values) ?: error("Could not create the file")
            contentResolver.openOutputStream(uri)!!.use { out -> file.inputStream().use { it.copyTo(out) } }
            return Triple(uri, mime, "$folder/YtClip")
        } finally {
            dir.deleteRecursively()
        }
    }

    // =====================  quality chips (4K / 2K, sizes)  =====================

    private fun resetChips() {
        for ((id, base) in qBase) v<Chip>(id).apply { text = base; visibility = View.VISIBLE }
    }

    /** Hides resolutions the video doesn't have and shows an estimated size on each quality chip. */
    private fun updateChips(j: JSONObject) {
        val fs = j.optJSONArray("formats") ?: return
        class F(val r: Int, val size: Long, val audio: Boolean, val m4a: Boolean)
        val vids = ArrayList<F>()
        val auds = ArrayList<F>()
        for (i in 0 until fs.length()) {
            val o = fs.optJSONObject(i) ?: continue
            val vc = o.optString("vcodec", "none")
            val ac = o.optString("acodec", "none")
            val hasV = vc != "none" && vc != "null" && vc.isNotEmpty()
            val hasA = ac != "none" && ac != "null" && ac.isNotEmpty()
            var size = o.optLong("filesize", 0L)
            if (size <= 0) size = o.optLong("filesize_approx", 0L)
            if (size <= 0) size = (o.optDouble("tbr", 0.0) * 125.0 * duration).toLong()
            val w = o.optInt("width", 0)
            val hh = o.optInt("height", 0)
            val res = if (w > 0 && hh > 0) minOf(w, hh) else hh // portrait videos: smallest side
            val f = F(res, size, hasA, o.optString("ext") == "m4a")
            if (hasV && res > 0) vids += f else if (hasA && !hasV) auds += f
        }
        val audioSize = (auds.filter { it.m4a }.ifEmpty { auds }).maxOfOrNull { it.size } ?: 0L
        val maxR = vids.maxOfOrNull { it.r } ?: 0
        fun est(limit: Int): Long {
            val cand = vids.filter { it.r <= limit }
            val top = cand.maxOfOrNull { it.r } ?: return 0L
            val best = cand.filter { it.r == top }.maxByOrNull { it.size } ?: return 0L
            return best.size + if (best.audio) 0L else audioSize
        }
        for ((id, h) in qHeight) {
            val chip = v<Chip>(id)
            if (maxR in 1 until h) { chip.visibility = View.GONE; continue }
            val e = est(h)
            chip.text = if (e > 0) "${qBase[id]} · ${fmtSize(e)}" else qBase[id]
        }
        est(2160).takeIf { it > 0 }?.let { v<Chip>(R.id.qBest).text = "Best · ${fmtSize(it)}" }
        if (audioSize > 0) v<Chip>(R.id.qAudio).text = "Audio only · ${fmtSize(audioSize)}"
        val checked = qualityGroup.checkedChipId
        if (checked == View.NO_ID || v<Chip>(checked).visibility != View.VISIBLE) qualityGroup.check(R.id.qBest)
    }

    private fun fmtSize(b: Long): String =
        if (b >= (1L shl 30)) "%.1f GB".format(b / 1073741824.0) else "%d MB".format(maxOf(1L, b / 1048576))

    // =====================  files tab  =====================

    private fun loadFiles() = lifecycleScope.launch {
        items = withContext(Dispatchers.IO) { queryFiles() }
        filesEmpty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
        filesList.adapter = ArrayAdapter(
            this@MainActivity, android.R.layout.simple_list_item_1,
            items.map { "${it.name}\n${fmtSize(it.size)}" }
        )
    }

    private fun queryFiles(): List<Item> {
        val out = mutableListOf<Item>()
        val cols = arrayOf(
            MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.MIME_TYPE, MediaStore.MediaColumns.DATE_ADDED
        )
        for (coll in listOf(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, MediaStore.Audio.Media.EXTERNAL_CONTENT_URI)) {
            contentResolver.query(
                coll, cols, "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?", arrayOf("%YtClip/"), null
            )?.use { c ->
                while (c.moveToNext()) {
                    out += Item(
                        ContentUris.withAppendedId(coll, c.getLong(0)), c.getString(1) ?: "file",
                        c.getLong(2), c.getString(3) ?: "video/mp4", c.getLong(4)
                    )
                }
            }
        }
        return out.sortedByDescending { it.added }
    }

    private fun fileMenu(f: Item) {
        MaterialAlertDialogBuilder(this).setTitle(f.name)
            .setItems(arrayOf("Open", "Share", "Delete")) { _, which ->
                when (which) {
                    0 -> openUri(f.uri, f.mime)
                    1 -> shareUri(f.uri, f.mime)
                    else -> {
                        val ok = runCatching { contentResolver.delete(f.uri, null, null) }.getOrDefault(0) > 0
                        if (!ok) say("Couldn't delete this file.")
                        loadFiles()
                    }
                }
            }.show()
    }

    private fun openUri(u: Uri, mime: String) {
        runCatching {
            startActivity(
                Intent(Intent.ACTION_VIEW).setDataAndType(u, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        }
    }

    private fun shareUri(u: Uri, mime: String) {
        runCatching {
            startActivity(
                Intent.createChooser(
                    Intent(Intent.ACTION_SEND).setType(mime).putExtra(Intent.EXTRA_STREAM, u)
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), null
                )
            )
        }
    }

    // =====================  notifications / clipboard  =====================

    private fun notifyProgress(text: String, pct: Float?) {
        val now = System.currentTimeMillis()
        if (now - lastNotif < 1000) return
        lastNotif = now
        runCatching {
            getSystemService(NotificationManager::class.java).notify(
                KeepAliveService.ID, KeepAliveService.build(this, text, pct?.toInt()?.coerceIn(0, 100))
            )
        }
    }

    private fun notifyDone(text: String) {
        runCatching {
            getSystemService(NotificationManager::class.java)
                .notify(2, KeepAliveService.build(this, text, null, true))
        }
    }

    /** Offer to fetch a link the user just copied (SnapTube-style). */
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (!hasFocus || !ready || nav.selectedItemId != R.id.nav_download) return
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        val t = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString().orEmpty()
        val u = extractUrl(t)
        if (u.isNotEmpty() && u != lastClip && u != link &&
            Regex("""youtu|facebook|fb\.watch|instagram|tiktok|twitter|x\.com""").containsMatchIn(u)
        ) {
            lastClip = u
            Snackbar.make(findViewById(android.R.id.content), "Link copied — fetch it?", Snackbar.LENGTH_LONG)
                .setAction("Fetch") { url.setText(u); fetch() }.show()
        }
    }

    override fun onDestroy() {
        KeepAliveService.onCancel = null
        super.onDestroy()
    }

    // =====================  helpers  =====================

    private fun setBar(frac: Float?) {
        if (frac == null) {
            if (!bar.isIndeterminate) bar.isIndeterminate = true
        } else {
            if (bar.isIndeterminate) bar.isIndeterminate = false
            bar.setProgressCompat(frac.coerceIn(0f, 100f).toInt(), true)
        }
    }

    private fun setBusy(busy: Boolean) {
        progressCard.visibility = View.VISIBLE
        downloadBtn.isEnabled = !busy
        fetchBtn.isEnabled = !busy
        pasteBtn.isEnabled = !busy
        cancelBtn.visibility = if (busy) View.VISIBLE else View.GONE
        if (busy) {
            openBtn.visibility = View.GONE
            shareBtn.visibility = View.GONE
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    private fun say(m: String, toast: Boolean = true) = runOnUiThread {
        hintView.text = m
        if (toast) Toast.makeText(this, m, Toast.LENGTH_LONG).show()
    }

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun extractUrl(t: String) = Regex("""https?://\S+""").find(t)?.value ?: ""

    private fun fmt(s: Int): String {
        val h = s / 3600
        val m = s % 3600 / 60
        val sec = s % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
    }

    private fun msg(e: Exception): String {
        val ls = e.message?.lines().orEmpty().filter { it.isNotBlank() }
        return (ls.lastOrNull { "ERROR" in it } ?: ls.firstOrNull() ?: "Unknown error").take(180)
    }
}
