package com.example.ytclip

import android.Manifest
import android.app.NotificationManager
import android.content.ClipboardManager
import android.content.ContentUris
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.text.InputFilter
import android.text.InputType
import android.util.LruCache
import android.util.Size
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.MimeTypeMap
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.example.ytclip.databinding.ActivityMainBinding
import com.example.ytclip.databinding.ItemFileBinding
import com.example.ytclip.databinding.ItemTaskBinding
import com.google.android.material.button.MaterialButton
import com.google.android.material.chip.Chip
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.tabs.TabLayout
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : AppCompatActivity() {

    enum class St { QUEUED, RUNNING, PAUSED, FAILED }

    class Opts(val audio: Boolean, val h: Int, val trim: Boolean, val a: Int, val bEnd: Int, val accurate: Boolean)

    class Task(
        val id: Int, val link: String, var title: String, var thumb: Bitmap?, val o: Opts,
        val job: Deferred<File>?, var info: File?, val dir: File
    ) {
        @Volatile var st = St.QUEUED
        @Volatile var busy = false
        @Volatile var gone = false
        @Volatile var pct = -1f
        @Volatile var speed = ""
        @Volatile var eta = -1L
        @Volatile var stage = 0
        @Volatile var err = ""
        @Volatile var duration = 0
        val pid get() = "ytclip-task-$id"
    }

    class Item(val uri: Uri, val name: String, val size: Long, val mime: String, val added: Long, val ms: Long)

    private lateinit var ui: ActivityMainBinding
    private val infoPid = "ytclip-info"
    private val timeRe = Regex("""time=(\d+):(\d+):(\d+)""")
    private val speedRe = Regex("""at\s+([\d.]+\s?\w+/s)""")
    private val W = ViewGroup.LayoutParams.WRAP_CONTENT

    private val tasks = mutableListOf<Task>()
    private var items = listOf<Item>()
    private var nextId = 1
    private var ready = false
    private var showQueue = true

    // download-sheet state
    private var link = ""
    private var gen = 0
    private var duration = 0
    private var selStart = 0
    private var selEnd = 0 // 0 = until the end of the video
    private var infoFile: File? = null
    private var infoJob: Deferred<File>? = null
    private lateinit var typeFields: List<EditText>

    private var browseUrl = ""
    private var pendingUrl: String? = null
    private var sharedLink = ""
    private var lastClip = ""
    private var lastNotif = 0L
    private var lastUi = 0L
    private val refreshers = mutableListOf<() -> Unit>()
    private val thumbCache = LruCache<Uri, Bitmap>(60)
    private lateinit var taskAdapter: TaskAdapter
    private lateinit var fileAdapter: FileAdapter

    private val prefs by lazy { getSharedPreferences("ytclip", MODE_PRIVATE) }
    private val cookieFile by lazy { File(filesDir, "cookies.txt") }
    private val sites = listOf(
        "YouTube" to "https://m.youtube.com", "Facebook" to "https://m.facebook.com",
        "Instagram" to "https://www.instagram.com", "TikTok" to "https://www.tiktok.com", "X" to "https://x.com"
    )
    private val qBase = mapOf(
        R.id.qBest to "Best", R.id.q2160 to "4K", R.id.q1440 to "2K", R.id.q1080 to "1080p",
        R.id.q720 to "720p", R.id.q480 to "480p", R.id.q360 to "360p", R.id.qAudio to "Audio only"
    )
    private val qHeight = mapOf(
        R.id.q2160 to 2160, R.id.q1440 to 1440, R.id.q1080 to 1080,
        R.id.q720 to 720, R.id.q480 to 480, R.id.q360 to 360
    )
    private val qIds = listOf(
        R.id.qBest, R.id.q2160, R.id.q1440, R.id.q1080, R.id.q720, R.id.q480, R.id.q360, R.id.qAudio
    )
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    private val pickCookies = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importCookies(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ui = ActivityMainBinding.inflate(layoutInflater)
        setContentView(ui.root)
        File(getExternalFilesDir(null) ?: filesDir, "tasks").deleteRecursively() // leftovers of a previous run

        if (intent.action == Intent.ACTION_SEND) {
            sharedLink = extractUrl(intent.getStringExtra(Intent.EXTRA_TEXT).orEmpty())
        }
        setupBrowse()
        setupSheet()
        buildTrimTools()
        setupDownloads()
        setupSettings()
        ui.nav.setOnItemSelectedListener { item ->
            val id = item.itemId
            ui.browsePane.visibility = if (id == R.id.nav_browse) View.VISIBLE else View.GONE
            ui.downloadsPane.visibility = if (id == R.id.nav_downloads) View.VISIBLE else View.GONE
            ui.settingsPane.visibility = if (id == R.id.nav_settings) View.VISIBLE else View.GONE
            if (id == R.id.nav_downloads) { refreshTasks(); loadFiles() }
            if (id == R.id.nav_settings) refreshSettings()
            true
        }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    ui.sheet.visibility == View.VISIBLE -> hideSheet()
                    ui.nav.selectedItemId != R.id.nav_browse -> ui.nav.selectedItemId = R.id.nav_browse
                    ui.web.visibility == View.VISIBLE && ui.web.canGoBack() -> ui.web.goBack()
                    ui.web.visibility == View.VISIBLE -> ui.tabs.getTabAt(0)?.select()
                    else -> finish()
                }
            }
        })
        KeepAliveService.onCancel = { runOnUiThread { tasks.toList().forEach { cancel(it) } } }
        startEngine()
    }

    private fun startEngine() {
        lifecycleScope.launch {
            try {
                val due = System.currentTimeMillis() - prefs.getLong("upd", 0L) > 24 * 3600 * 1000L
                withContext(Dispatchers.IO) {
                    YoutubeDL.getInstance().init(application)
                    FFmpeg.getInstance().init(application)
                    if (due) { // update yt-dlp at most once a day
                        say("Updating engine…", false)
                        runCatching {
                            YoutubeDL.getInstance().updateYoutubeDL(application, YoutubeDL.UpdateChannel.STABLE)
                        }.onSuccess { prefs.edit().putLong("upd", System.currentTimeMillis()).apply() }
                    }
                }
                ready = true
                say("Ready. Paste a link, or browse a site and tap Download.", false)
                if (sharedLink.isNotEmpty()) openSheet(sharedLink)
            } catch (e: Exception) {
                say("Startup failed: ${msg(e)}")
            }
        }
    }

    // =====================  BROWSE  =====================

    private fun setupBrowse() {
        ui.tabs.addTab(ui.tabs.newTab().setText("Home"))
        sites.forEach { ui.tabs.addTab(ui.tabs.newTab().setText(it.first)) }
        ui.tabs.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) { showSite(tab?.position ?: 0) }
            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) { if ((tab?.position ?: 0) > 0) showSite(tab!!.position) }
        })
        sites.forEachIndexed { i, s ->
            ui.siteChips.addView(Chip(this).apply { text = s.first; setOnClickListener { goWeb(i + 1, null) } })
        }
        ui.searchGo.setOnClickListener { submitSearch() }
        ui.searchBox.setOnEditorActionListener { _, action, _ ->
            if (action == EditorInfo.IME_ACTION_SEARCH) { submitSearch(); true } else false
        }
        ui.pasteBtn.setOnClickListener {
            val t = clipText()
            if (t.isNotEmpty()) { ui.searchBox.setText(extractUrl(t).ifEmpty { t }); submitSearch() }
        }
        ui.dlFab.setOnClickListener { openSheet(browseUrl) }
        ui.accountBtn.setOnClickListener { accountDialog() }

        val ua = WebSettings.getDefaultUserAgent(this).replace("; wv", "").replace(Regex("""Version/\d+\.\d+\s"""), "")
        ui.web.settings.apply { javaScriptEnabled = true; domStorageEnabled = true; userAgentString = ua }
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(ui.web, true)
        ui.web.webViewClient = object : WebViewClient() {
            override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) { onBrowse(url) }
            override fun onPageFinished(view: WebView?, url: String?) {
                CookieManager.getInstance().flush()
                updateAccountIcon()
            }
        }
        updateAccountIcon()
    }

    private fun showSite(pos: Int) {
        val home = pos == 0
        ui.homePane.visibility = if (home) View.VISIBLE else View.GONE
        ui.web.visibility = if (home) View.GONE else View.VISIBLE
        if (home) ui.dlFab.visibility = View.GONE
        else { ui.web.loadUrl(pendingUrl ?: sites[pos - 1].second); pendingUrl = null }
    }

    private fun goWeb(tab: Int, url: String?) {
        pendingUrl = url
        ui.nav.selectedItemId = R.id.nav_browse
        if (ui.tabs.selectedTabPosition == tab) showSite(tab) else ui.tabs.getTabAt(tab)?.select()
    }

    private fun submitSearch() {
        val t = ui.searchBox.text.toString().trim()
        if (t.isEmpty()) return
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(ui.searchBox.windowToken, 0)
        val u = extractUrl(t)
        if (u.isNotEmpty()) openSheet(u)
        else goWeb(1, "https://m.youtube.com/results?search_query=" + Uri.encode(t))
    }

    private fun onBrowse(u: String?) {
        browseUrl = u.orEmpty()
        val yt = Regex("""(youtube\.com/(watch|shorts)|youtu\.be/)""").containsMatchIn(browseUrl)
        val other = !browseUrl.contains("youtube.com") && !browseUrl.contains("google.") &&
            Regex("""https?://[^/]+/.+""").containsMatchIn(browseUrl)
        ui.dlFab.visibility = if (ui.web.visibility == View.VISIBLE && (yt || other)) View.VISIBLE else View.GONE
    }

    private fun clipText(): String {
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        return cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString().orEmpty()
    }

    /** Offer to fetch a link the user just copied. */
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (!hasFocus || !ready || ui.nav.selectedItemId != R.id.nav_browse || ui.sheet.visibility == View.VISIBLE) return
        val u = extractUrl(clipText())
        if (u.isNotEmpty() && u != lastClip && u != link &&
            Regex("""youtu|facebook|fb\.watch|instagram|tiktok|twitter|x\.com""").containsMatchIn(u)
        ) {
            lastClip = u
            Snackbar.make(ui.root, "Link copied — download it?", Snackbar.LENGTH_LONG)
                .setAction("Open") { openSheet(u) }.show()
        }
    }

    // =====================  GOOGLE ACCOUNT  =====================

    private fun signedIn() = CookieManager.getInstance().getCookie("https://www.youtube.com")
        ?.let { "SAPISID" in it || "__Secure-3PSID" in it } == true

    private fun linked() = signedIn() || prefs.getBoolean("cookies_imported", false)

    private fun updateAccountIcon() {
        ui.accountBtn.imageTintList = if (linked()) ColorStateList.valueOf(0xFFFFC107.toInt()) else null
    }

    private fun accountDialog() {
        if (linked()) {
            MaterialAlertDialogBuilder(this).setTitle("Google account linked ✓")
                .setMessage("Downloads can use your account (age-restricted videos and “confirm you’re not a bot” errors).")
                .setPositiveButton("Close", null)
                .setNegativeButton("Sign out") { _, _ -> signOut() }.show()
        } else {
            MaterialAlertDialogBuilder(this).setTitle("Link your Google account")
                .setMessage("Sign in to YouTube so downloads can use your account. If Google refuses the sign-in inside the app, import a cookies.txt file instead.")
                .setPositiveButton("Sign in") { _, _ ->
                    goWeb(1, "https://accounts.google.com/ServiceLogin?service=youtube&hl=en&continue=" +
                        Uri.encode("https://m.youtube.com/"))
                }
                .setNeutralButton("Import cookies.txt") { _, _ -> pickCookies.launch(arrayOf("*/*")) }
                .setNegativeButton("Cancel", null).show()
        }
    }

    private fun signOut() {
        CookieManager.getInstance().removeAllCookies(null)
        CookieManager.getInstance().flush()
        WebStorage.getInstance().deleteAllData()
        cookieFile.delete()
        prefs.edit().putBoolean("cookies_imported", false).apply()
        updateAccountIcon(); refreshSettings(); say("Signed out.")
    }

    private fun importCookies(uri: Uri) {
        runCatching {
            contentResolver.openInputStream(uri)?.use { cookieFile.writeBytes(it.readBytes()) }
            prefs.edit().putBoolean("cookies_imported", true).apply()
        }.onSuccess { updateAccountIcon(); refreshSettings(); say("Cookies imported ✓") }
            .onFailure { say("Couldn't import the file: ${it.message}") }
    }

    /** Path of a cookies file for yt-dlp, or null when no account should be used. */
    private fun cookiesArg(): String? {
        if (!prefs.getBoolean("use_account", true)) return null
        if (prefs.getBoolean("cookies_imported", false) && cookieFile.exists()) return cookieFile.absolutePath
        if (!signedIn()) return null
        return runCatching {
            val sb = StringBuilder("# Netscape HTTP Cookie File\n")
            val cm = CookieManager.getInstance()
            for ((u, dom) in listOf(
                "https://www.youtube.com" to ".youtube.com", "https://accounts.google.com" to ".google.com",
                "https://www.google.com" to ".google.com"
            )) {
                cm.getCookie(u)?.split(";")?.forEach { c ->
                    val i = c.indexOf('=')
                    if (i > 0) sb.append("$dom\tTRUE\t/\tTRUE\t2147483647\t${c.substring(0, i).trim()}\t${c.substring(i + 1).trim()}\n")
                }
            }
            cookieFile.writeText(sb.toString())
            cookieFile.absolutePath
        }.getOrNull()
    }

    // =====================  DOWNLOAD SHEET  =====================

    private fun setupSheet() {
        ui.scrim.setOnClickListener { hideSheet() }
        ui.sheetClose.setOnClickListener { hideSheet() }
        ui.downloadBtn.setOnClickListener { enqueueFromSheet() }
        ui.range.values = listOf(0f, 100f)
        ui.range.isEnabled = false
        ui.range.setLabelFormatter { fmt(it.toInt()) }
        ui.range.addOnChangeListener { s, _, _ ->
            selStart = s.values[0].toInt()
            selEnd = s.values[1].toInt()
            refreshTrimUi()
        }
        ui.trimSwitch.setOnCheckedChangeListener { _, on ->
            ui.trimBox.visibility = if (on) View.VISIBLE else View.GONE
            refreshTrimUi()
        }
        ui.modeGroup.addOnButtonCheckedListener { _, id, checked ->
            if (!checked) return@addOnButtonCheckedListener
            val typing = id == R.id.modeType
            if (typing) fillFields() else {
                readFields()
                if (duration > 1) applySel(selStart, if (selEnd > 0) selEnd else duration)
            }
            ui.typeBox.visibility = if (typing) View.VISIBLE else View.GONE
            ui.sliderBox.visibility = if (typing) View.GONE else View.VISIBLE
            refreshTrimUi()
        }
    }

    private fun showSheet() { ui.scrim.visibility = View.VISIBLE; ui.sheet.visibility = View.VISIBLE }
    private fun hideSheet() { ui.scrim.visibility = View.GONE; ui.sheet.visibility = View.GONE }

    /**
     * 1) Instant preview (title + thumbnail) from oEmbed.
     * 2) yt-dlp reads the full details ONCE in the background and saves them to a file.
     * 3) The download re-uses that file (--load-info-json), so yt-dlp never extracts twice.
     */
    private fun openSheet(l: String) {
        if (l.isEmpty()) return
        if (!ready) return say("The engine is still starting. Try again in a moment.")
        val g = ++gen
        link = l; duration = 0; infoFile = null
        infoJob?.cancel()
        YoutubeDL.getInstance().destroyProcessById(infoPid)

        ui.titleView.text = "Loading…"
        ui.metaView.text = "Reading video details…"
        ui.thumb.setImageDrawable(null)
        ui.trimSwitch.isChecked = false
        selStart = 0; selEnd = 0
        ui.range.isEnabled = false
        resetChips()
        ui.qualityGroup.check(qIds[prefs.getInt("quality", 0).coerceIn(qIds.indices)])
        ui.precise.isChecked = prefs.getBoolean("precise", false)
        fillFields(); refreshTrimUi(); showSheet()

        lifecycleScope.launch {
            val quick = withContext(Dispatchers.IO) { quickPreview(l) }
            if (quick != null && g == gen && duration == 0) {
                ui.titleView.text = quick.first
                quick.second?.let { ui.thumb.setImageBitmap(it) }
            }
        }
        val job = lifecycleScope.async(Dispatchers.IO) { extractInfo(l) }
        infoJob = job
        lifecycleScope.launch {
            try {
                val f = job.await()
                if (g != gen) return@launch
                infoFile = f
                val j = withContext(Dispatchers.IO) { JSONObject(f.readText()) }
                duration = j.optInt("duration", 0)
                j.optString("title").takeIf { it.isNotEmpty() }?.let { ui.titleView.text = it }
                ui.metaView.text = if (duration > 0) "Length ${fmt(duration)}" else "Live or unknown length"
                if (duration > 1) onDurationKnown()
                updateChips(j)
                val tu = j.optString("thumbnail")
                if (ui.thumb.drawable == null && tu.isNotEmpty()) {
                    withContext(Dispatchers.IO) { bitmap(tu) }?.let { ui.thumb.setImageBitmap(it) }
                }
            } catch (e: Exception) {
                if (g == gen) ui.metaView.text = "Couldn't read details: ${msg(e)}"
            }
        }
    }

    private fun extractInfo(l: String): File {
        val req = YoutubeDLRequest(l).apply {
            addOption("--dump-single-json")
            addOption("--no-playlist")
            addOption("--no-warnings")
            cookiesArg()?.let { addOption("--cookies", it) }
        }
        val out = YoutubeDL.getInstance().execute(req, infoPid) { _, _, _ -> }.out
        val json = out.lines().lastOrNull { it.trimStart().startsWith("{") }
            ?: error("No video details were returned")
        return File(cacheDir, "info-${System.currentTimeMillis()}.json").apply { writeText(json) }
    }

    private fun quickPreview(l: String): Pair<String, Bitmap?>? = runCatching {
        val c = URL("https://www.youtube.com/oembed?format=json&url=" + Uri.encode(l)).openConnection() as HttpURLConnection
        c.connectTimeout = 4000
        c.readTimeout = 4000
        val j = JSONObject(c.inputStream.bufferedReader().readText())
        Pair(j.getString("title"), bitmap(j.optString("thumbnail_url")))
    }.getOrNull()

    private fun bitmap(u: String): Bitmap? =
        runCatching { URL(u).openStream().use { BitmapFactory.decodeStream(it) } }.getOrNull()

    private fun enqueueFromSheet() {
        if (link.isEmpty()) return
        val trim = ui.trimSwitch.isChecked
        val (a, e) = trimRange()
        if (trim && e > 0 && e <= a) return say("The end time must be after the start time.")
        if (trim && duration > 0 && a >= duration) return say("The start time is after the end of the video.")
        val chip = ui.qualityGroup.checkedChipId
        val o = Opts(chip == R.id.qAudio, qHeight[chip] ?: 2160, trim, a, e, ui.precise.isChecked)
        val dir = File(getExternalFilesDir(null) ?: filesDir, "tasks/$nextId").apply { mkdirs() }
        val bmp = (ui.thumb.drawable as? BitmapDrawable)?.bitmap
        val t = Task(nextId++, link, ui.titleView.text.toString(), bmp, o, infoJob, infoFile, dir)
        t.duration = duration
        tasks.add(0, t)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        hideSheet()
        refreshTasks(); pump()
        Snackbar.make(ui.root, "Added to downloads", Snackbar.LENGTH_LONG)
            .setAction("View") { ui.nav.selectedItemId = R.id.nav_downloads }.show()
    }

    // ---- quality chips (hide missing resolutions, show estimated sizes) ----

    private fun resetChips() {
        for ((id, base) in qBase) findViewById<Chip>(id).apply { text = base; visibility = View.VISIBLE }
    }

    private fun updateChips(j: JSONObject) {
        val fs = j.optJSONArray("formats") ?: return
        class F(val r: Int, val size: Long, val audio: Boolean, val m4a: Boolean)
        val vids = ArrayList<F>()
        val auds = ArrayList<F>()
        for (i in 0 until fs.length()) {
            val o = fs.optJSONObject(i) ?: continue
            val vc = o.optString("vcodec", "none")
            val ac = o.optString("acodec", "none")
            val hasV = vc != "none" && vc != "null" && vc.isNotEmpty()
            val hasA = ac != "none" && ac != "null" && ac.isNotEmpty()
            var size = o.optLong("filesize", 0L)
            if (size <= 0) size = o.optLong("filesize_approx", 0L)
            if (size <= 0) size = (o.optDouble("tbr", 0.0) * 125.0 * duration).toLong()
            val w = o.optInt("width", 0)
            val hh = o.optInt("height", 0)
            val res = if (w > 0 && hh > 0) minOf(w, hh) else hh // portrait videos: smallest side
            val f = F(res, size, hasA, o.optString("ext") == "m4a")
            if (hasV && res > 0) vids += f else if (hasA && !hasV) auds += f
        }
        val audioSize = (auds.filter { it.m4a }.ifEmpty { auds }).maxOfOrNull { it.size } ?: 0L
        val maxR = vids.maxOfOrNull { it.r } ?: 0
        fun est(limit: Int): Long {
            val cand = vids.filter { it.r <= limit }
            val top = cand.maxOfOrNull { it.r } ?: return 0L
            val best = cand.filter { it.r == top }.maxByOrNull { it.size } ?: return 0L
            return best.size + if (best.audio) 0L else audioSize
        }
        for ((id, h) in qHeight) {
            val chip = findViewById<Chip>(id)
            if (maxR in 1 until h) { chip.visibility = View.GONE; continue }
            val e = est(h)
            chip.text = if (e > 0) "${qBase[id]} · ${fmtSize(e)}" else qBase[id]
        }
        est(2160).takeIf { it > 0 }?.let { ui.qBest.text = "Best · ${fmtSize(it)}" }
        if (audioSize > 0) ui.qAudio.text = "Audio only · ${fmtSize(audioSize)}"
        val checked = ui.qualityGroup.checkedChipId
        if (checked == View.NO_ID || findViewById<Chip>(checked).visibility != View.VISIBLE) ui.qualityGroup.check(R.id.qBest)
    }

    // ---- trim ----

    private fun onDurationKnown() {
        ui.range.valueFrom = 0f
        ui.range.valueTo = duration.toFloat()
        ui.range.stepSize = 1f
        ui.range.isEnabled = true
        selStart = selStart.coerceIn(0, duration - 1)
        if (selEnd <= selStart || selEnd > duration) selEnd = duration
        ui.range.values = listOf(selStart.toFloat(), selEnd.toFloat())
        refreshTrimUi()
    }

    private fun applySel(a: Int, e: Int) {
        if (duration < 2) return
        selStart = a.coerceIn(0, duration - 1)
        selEnd = e.coerceIn(selStart + 1, duration)
        ui.range.values = listOf(selStart.toFloat(), selEnd.toFloat())
        refreshTrimUi()
    }

    private fun refreshTrimUi() {
        ui.trimLabel.text = when {
            ui.modeGroup.checkedButtonId == R.id.modeType -> "Type start and end time (leave End empty to go to the end)"
            duration <= 1 -> "Loading video length…"
            else -> "${fmt(selStart)}  →  ${fmt(selEnd)}      (clip ${fmt(selEnd - selStart)})"
        }
    }

    /** (startSeconds, endSeconds); end <= 0 means "until the end of the video". */
    private fun trimRange(): Pair<Int, Int> {
        if (ui.modeGroup.checkedButtonId == R.id.modeType) readFields()
        return Pair(selStart, selEnd)
    }

    private fun buildTrimTools() {
        typeFields = timeRow("Start") + timeRow("End")
        for ((name, isStart) in listOf("Start" to true, "End" to false)) {
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            row.addView(TextView(this).apply { text = name }, LinearLayout.LayoutParams(dp(52), W))
            for (d in listOf(-10, -1, 1, 10)) {
                val label = if (d > 0) "+${d}s" else "−${-d}s"
                row.addView(smallBtn(label) {
                    if (isStart) applySel(selStart + d, selEnd) else applySel(selStart, selEnd + d)
                }, LinearLayout.LayoutParams(0, W, 1f).apply { marginStart = dp(4) })
            }
            ui.nudgeBox.addView(row)
        }
        val presets = LinearLayout(this)
        listOf<Pair<String, () -> Unit>>(
            "Reset" to { applySel(0, duration) }, "First 30s" to { applySel(0, 30) },
            "First 60s" to { applySel(0, 60) }, "Last 30s" to { applySel(duration - 30, duration) }
        ).forEach { (t, action) ->
            presets.addView(smallBtn(t, action), LinearLayout.LayoutParams(0, W, 1f).apply { marginEnd = dp(4) })
        }
        ui.nudgeBox.addView(presets)
    }

    private fun smallBtn(t: String, onClick: () -> Unit) =
        MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            text = t; textSize = 12f; minWidth = 0; minimumWidth = 0; insetTop = 0; insetBottom = 0
            setPadding(0, 0, 0, 0)
            setOnClickListener { onClick() }
        }

    private fun timeRow(name: String): List<EditText> {
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        row.addView(TextView(this).apply { text = name }, LinearLayout.LayoutParams(dp(52), W))
        val fields = listOf("hh", "mm", "ss").mapIndexed { i, u ->
            if (i > 0) row.addView(TextView(this).apply { text = " : " })
            EditText(this).apply {
                hint = u
                inputType = InputType.TYPE_CLASS_NUMBER
                filters = arrayOf(InputFilter.LengthFilter(2))
                gravity = Gravity.CENTER
            }.also { row.addView(it, LinearLayout.LayoutParams(0, W, 1f)) }
        }
        ui.typeBox.addView(row)
        return fields
    }

    private fun secs(i: Int): Int {
        val p = (0..2).map { typeFields[i + it].text.toString().toIntOrNull() ?: 0 }
        return p[0] * 3600 + p[1] * 60 + p[2]
    }

    private fun readFields() {
        selStart = secs(0)
        val e = secs(3)
        selEnd = if (e > 0) e else duration
    }

    private fun fillFields() {
        fun put(i: Int, t: Int) {
            val parts = if (t <= 0) listOf("", "", "") else listOf(t / 3600, t % 3600 / 60, t % 60).map { it.toString() }
            for (k in 0..2) typeFields[i + k].setText(parts[k])
        }
        put(0, selStart)
        put(3, selEnd)
    }

    // =====================  DOWNLOAD QUEUE  =====================

    private fun setupDownloads() {
        taskAdapter = TaskAdapter(); fileAdapter = FileAdapter()
        ui.taskList.adapter = taskAdapter
        ui.fileList.adapter = fileAdapter
        ui.fileList.setOnItemClickListener { _, _, i, _ -> openUri(items[i].uri, items[i].mime) }
        ui.fileList.setOnItemLongClickListener { _, _, i, _ -> fileMenu(items[i]); true }
        ui.dlTabs.addOnButtonCheckedListener { _, id, checked ->
            if (checked) { showQueue = id == R.id.tabQueue; refreshTasks() }
        }
        ui.pauseAllBtn.setOnClickListener {
            if (tasks.any { it.st == St.RUNNING || it.st == St.QUEUED }) tasks.toList().forEach { pause(it) }
            else tasks.toList().forEach { if (it.st == St.PAUSED || it.st == St.FAILED) resume(it) }
        }
        ui.cancelAllBtn.setOnClickListener {
            MaterialAlertDialogBuilder(this).setTitle("Cancel all downloads?")
                .setPositiveButton("Yes, cancel all") { _, _ -> tasks.toList().forEach { cancel(it) } }
                .setNegativeButton("No", null).show()
        }
    }

    private fun pump() {
        val max = prefs.getInt("parallel", 0) + 1
        var running = tasks.count { it.st == St.RUNNING }
        for (t in tasks.reversed()) { // oldest first
            if (running >= max) break
            if (t.st == St.QUEUED && !t.busy) { running++; start(t) }
        }
        val svc = Intent(this, KeepAliveService::class.java)
        if (tasks.any { it.st == St.RUNNING || it.st == St.QUEUED }) ContextCompat.startForegroundService(this, svc)
        else stopService(svc)
    }

    private fun start(t: Task) {
        t.st = St.RUNNING; t.busy = true; t.err = ""
        lifecycleScope.launch {
            try {
                if (prefs.getBoolean("wifi", false) && !onWifi()) {
                    t.st = St.PAUSED; t.err = "Waiting for Wi‑Fi — tap ▶ to continue"
                    return@launch
                }
                if (t.info == null) t.info = runCatching { t.job?.await() }.getOrNull()
                val r = withContext(Dispatchers.IO) { runTask(t) }
                tasks.remove(t)
                t.dir.deleteRecursively()
                notifyDone("Saved ✓  ${r.third}")
                loadFiles()
            } catch (e: Exception) {
                when {
                    t.gone -> tasks.remove(t)
                    t.st != St.RUNNING -> {} // paused by the user
                    else -> { t.st = St.FAILED; t.err = msg(e) }
                }
            } finally {
                t.busy = false
                if (t.gone) t.dir.deleteRecursively()
                refreshTasks(); pump()
            }
        }
    }

    private fun pause(t: Task) {
        if (t.st != St.RUNNING && t.st != St.QUEUED) return
        t.st = St.PAUSED; t.err = ""
        YoutubeDL.getInstance().destroyProcessById(t.pid)
        refreshTasks(); pump()
    }

    private fun resume(t: Task) { t.st = St.QUEUED; t.err = ""; refreshTasks(); pump() }

    private fun cancel(t: Task) {
        t.gone = true
        YoutubeDL.getInstance().destroyProcessById(t.pid)
        if (!t.busy) { tasks.remove(t); t.dir.deleteRecursively() }
        refreshTasks(); pump()
    }

    private fun onWifi(): Boolean {
        val cm = getSystemService(ConnectivityManager::class.java)
        val c = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) || c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
    }

    /** Runs one download (blocking, on an IO thread) and copies the result into Movies/<folder> or Music/<folder>. */
    private fun runTask(t: Task): Triple<Uri, String, String> {
        val o = t.o
        t.info?.let { f ->
            runCatching {
                val j = JSONObject(f.readText())
                j.optString("title").takeIf { it.isNotEmpty() }?.let { t.title = it }
                if (t.duration == 0) t.duration = j.optInt("duration", 0)
            }
        }
        val cookies = cookiesArg()
        val conn = listOf(1, 4, 8)[prefs.getInt("threads", 1).coerceIn(0, 2)]
        val rate = listOf("", "1M", "2M", "5M")[prefs.getInt("speed", 0).coerceIn(0, 3)]
        // up to 1080p: H.264 (plays everywhere). 2K/4K only exist as VP9/AV1, so prefer VP9.
        val codec = if (o.h <= 1080) "h264" else "vp9"

        fun build(useInfo: Boolean): YoutubeDLRequest {
            val f = t.info?.takeIf { useInfo && it.exists() }
            return (if (f != null) YoutubeDLRequest(emptyList<String>()) else YoutubeDLRequest(t.link)).apply {
                if (f != null) addOption("--load-info-json", f.absolutePath)
                addOption("--no-playlist")
                addOption("-N", conn.toString())
                if (rate.isNotEmpty()) addOption("--limit-rate", rate)
                cookies?.let { addOption("--cookies", it) }
                addOption("-o", "${t.dir.absolutePath}/%(title).80s.%(ext)s")
                if (o.audio) {
                    addOption("-f", "ba[ext=m4a]/ba/b")
                    addOption("-x")
                    addOption("--audio-format", "m4a")
                } else {
                    addOption("-f", "bv*+ba[ext=m4a]/bv*+ba/b")
                    addOption("-S", "res:${o.h},vcodec:$codec,acodec:aac") // res = smallest side (portrait-safe)
                    addOption("--merge-output-format", "mp4")
                }
                if (o.trim) {
                    addOption("--download-sections", "*${o.a}-${if (o.bEnd > 0) o.bEnd.toString() else "inf"}")
                    if (o.accurate) addOption("--force-keyframes-at-cuts")
                }
            }
        }

        val clipLen = if (!o.trim) 0 else (if (o.bEnd > 0) o.bEnd else t.duration) - o.a
        val onLine: (Float, Long, String) -> Unit = { pct, eta, line ->
            if (line.contains("Destination:")) t.stage++
            val tm = timeRe.find(line)
            val frac: Float? = when {
                o.trim && tm != null && clipLen > 0 -> {
                    val (hh, mm, ss) = tm.destructured
                    (hh.toInt() * 3600 + mm.toInt() * 60 + ss.toInt()) * 100f / clipLen
                }
                o.trim -> null
                pct >= 0f -> pct
                else -> null
            }
            t.pct = frac ?: -1f
            t.eta = if (o.trim) -1L else eta
            if (!o.trim) speedRe.find(line)?.let { t.speed = it.groupValues[1] }
            postRefresh()
            notifyProgress(t)
        }

        try {
            YoutubeDL.getInstance().execute(build(true), t.pid, onLine)
        } catch (e: Exception) {
            if (t.gone || t.st != St.RUNNING || t.info == null) throw e
            t.stage = 0 // saved details may have expired: retry with the plain link
            YoutubeDL.getInstance().execute(build(false), t.pid, onLine)
        }

        val file = t.dir.listFiles()
            ?.filter { !it.name.endsWith(".part") && !it.name.endsWith(".ytdl") }
            ?.maxByOrNull { it.length() } ?: error("No output file was produced")
        val mime = if (o.audio) "audio/mp4"
        else MimeTypeMap.getSingleton().getMimeTypeFromExtension(file.extension) ?: "video/mp4"
        val folder = if (o.audio) Environment.DIRECTORY_MUSIC else Environment.DIRECTORY_MOVIES
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, file.name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, "$folder/${folderName()}")
        }
        val coll = if (o.audio) MediaStore.Audio.Media.EXTERNAL_CONTENT_URI else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val uri = contentResolver.insert(coll, values) ?: error("Could not create the file")
        contentResolver.openOutputStream(uri)!!.use { out -> file.inputStream().use { it.copyTo(out) } }
        return Triple(uri, mime, file.name)
    }

    private fun statusText(t: Task): String = when (t.st) {
        St.QUEUED -> "Waiting…"
        St.PAUSED -> if (t.err.isNotEmpty()) t.err else "Paused" + if (t.pct >= 0) " • ${t.pct.toInt()}%" else ""
        St.FAILED -> "Failed: ${t.err}  (tap ▶ to retry)"
        St.RUNNING -> {
            val part = when { t.o.audio -> "Audio"; t.o.trim -> "Clip"; t.stage >= 2 -> "Audio"; else -> "Video" }
            if (t.pct < 0) "Preparing…"
            else if (t.pct >= 100f && (t.o.audio || t.o.trim || t.stage >= 2)) "Processing…"
            else "$part ${t.pct.toInt().coerceAtMost(100)}%" +
                (if (t.speed.isNotEmpty()) "  •  ${t.speed}" else "") +
                (if (t.eta >= 0) "  •  ${fmt(t.eta.toInt())} left" else "")
        }
    }

    private fun postRefresh() {
        val now = System.currentTimeMillis()
        if (now - lastUi < 250) return
        lastUi = now
        runOnUiThread { refreshTasks() }
    }

    private fun refreshTasks() {
        taskAdapter.notifyDataSetChanged()
        val n = tasks.size
        ui.tabQueue.text = "Downloading ($n)"
        ui.taskList.visibility = if (showQueue) View.VISIBLE else View.GONE
        ui.fileList.visibility = if (showQueue) View.GONE else View.VISIBLE
        ui.queueBar.visibility = if (showQueue && n > 0) View.VISIBLE else View.GONE
        ui.pauseAllBtn.text = if (tasks.any { it.st == St.RUNNING || it.st == St.QUEUED }) "Pause all" else "Resume all"
        val empty = if (showQueue) n == 0 else items.isEmpty()
        ui.emptyView.visibility = if (empty) View.VISIBLE else View.GONE
        ui.emptyView.text = if (showQueue) "No active downloads.\nBrowse a site or paste a link to start." else "No downloaded files yet."
        if (n > 0) ui.nav.getOrCreateBadge(R.id.nav_downloads).number = n else ui.nav.removeBadge(R.id.nav_downloads)
    }

    private inner class TaskAdapter : BaseAdapter() {
        override fun getCount() = tasks.size
        override fun getItem(position: Int): Any = tasks[position]
        override fun getItemId(position: Int) = tasks[position].id.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val r = if (convertView != null) ItemTaskBinding.bind(convertView)
            else ItemTaskBinding.inflate(layoutInflater, parent, false)
            val t = tasks[position]
            r.title.text = t.title
            r.thumb.setImageBitmap(t.thumb)
            r.status.text = statusText(t)
            if (t.st == St.RUNNING && t.pct < 0) {
                if (!r.bar.isIndeterminate) r.bar.isIndeterminate = true
            } else {
                if (r.bar.isIndeterminate) r.bar.isIndeterminate = false
                r.bar.setProgressCompat(t.pct.coerceIn(0f, 100f).toInt(), false)
            }
            val active = t.st == St.RUNNING || t.st == St.QUEUED
            r.pauseBtn.setImageResource(if (active) R.drawable.ic_pause else R.drawable.ic_play)
            r.pauseBtn.setOnClickListener { if (active) pause(t) else resume(t) }
            r.cancelBtn.setOnClickListener { cancel(t) }
            return r.root
        }
    }

    // =====================  DOWNLOADED FILES  =====================

    private fun folderName() = (prefs.getString("folder", "YtClip") ?: "YtClip")
        .replace(Regex("[^A-Za-z0-9 _-]"), "").trim().ifEmpty { "YtClip" }

    private fun loadFiles() {
        lifecycleScope.launch {
            items = withContext(Dispatchers.IO) { queryFiles() }
            fileAdapter.notifyDataSetChanged()
            refreshTasks()
        }
    }

    private fun queryFiles(): List<Item> {
        val out = mutableListOf<Item>()
        val cols = arrayOf(
            MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.MIME_TYPE, MediaStore.MediaColumns.DATE_ADDED, MediaStore.MediaColumns.DURATION
        )
        for (coll in listOf(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, MediaStore.Audio.Media.EXTERNAL_CONTENT_URI)) {
            contentResolver.query(
                coll, cols, "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?", arrayOf("%${folderName()}/"), null
            )?.use { c ->
                while (c.moveToNext()) {
                    out += Item(
                        ContentUris.withAppendedId(coll, c.getLong(0)), c.getString(1) ?: "file", c.getLong(2),
                        c.getString(3) ?: "video/mp4", c.getLong(4), c.getLong(5)
                    )
                }
            }
        }
        return out.sortedByDescending { it.added }
    }

    private inner class FileAdapter : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(position: Int): Any = items[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val r = if (convertView != null) ItemFileBinding.bind(convertView)
            else ItemFileBinding.inflate(layoutInflater, parent, false)
            val f = items[position]
            r.title.text = f.name
            r.meta.text = fmtSize(f.size) + if (f.ms > 0) "  •  ${fmt((f.ms / 1000).toInt())}" else ""
            r.root.tag = f.uri
            val cached = thumbCache.get(f.uri)
            if (cached != null) r.thumb.setImageBitmap(cached) else {
                r.thumb.setImageDrawable(null)
                lifecycleScope.launch {
                    val bmp = withContext(Dispatchers.IO) {
                        runCatching { contentResolver.loadThumbnail(f.uri, Size(192, 108), null) }.getOrNull()
                    }
                    if (bmp != null) { thumbCache.put(f.uri, bmp); if (r.root.tag == f.uri) r.thumb.setImageBitmap(bmp) }
                }
            }
            r.moreBtn.setOnClickListener { fileMenu(f) }
            return r.root
        }
    }

    private fun fileMenu(f: Item) {
        MaterialAlertDialogBuilder(this).setTitle(f.name)
            .setItems(arrayOf("Open", "Share", "Delete")) { _, which ->
                when (which) {
                    0 -> openUri(f.uri, f.mime)
                    1 -> shareUri(f.uri, f.mime)
                    else -> {
                        val ok = runCatching { contentResolver.delete(f.uri, null, null) }.getOrDefault(0) > 0
                        if (!ok) say("Couldn't delete this file.")
                        loadFiles()
                    }
                }
            }.show()
    }

    private fun openUri(u: Uri, mime: String) {
        runCatching {
            startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(u, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        }
    }

    private fun shareUri(u: Uri, mime: String) {
        runCatching {
            startActivity(
                Intent.createChooser(
                    Intent(Intent.ACTION_SEND).setType(mime).putExtra(Intent.EXTRA_STREAM, u)
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), null
                )
            )
        }
    }

    // =====================  SETTINGS (download settings only)  =====================

    private fun setupSettings() {
        val box = ui.settingsBox
        box.addView(TextView(this).apply {
            text = "Download settings"; textSize = 22f; setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(16), dp(20), dp(16), dp(8))
        })
        choiceRow("Default quality", "quality", listOf("Best (up to 4K)", "4K", "2K", "1080p", "720p", "480p", "360p", "Audio only"), 0)
        addRow("Download folder", { "Movies/${folderName()}  •  Music/${folderName()}" }, {
            val et = EditText(this).apply { setText(folderName()); setPadding(dp(24), dp(16), dp(24), dp(16)) }
            MaterialAlertDialogBuilder(this).setTitle("Folder name").setView(et)
                .setPositiveButton("Save") { _, _ ->
                    prefs.edit().putString("folder", et.text.toString()).apply(); refreshSettings()
                }.setNegativeButton("Cancel", null).show()
        })
        choiceRow("Simultaneous downloads", "parallel", listOf("1", "2", "3"), 0)
        choiceRow("Connections per download", "threads", listOf("1", "4 (faster)", "8 (fastest)"), 1)
        choiceRow("Speed limit", "speed", listOf("Unlimited", "1 MB/s", "2 MB/s", "5 MB/s"), 0)
        switchRow("Wi‑Fi only", "wifi", false) { "Wait for Wi‑Fi instead of using mobile data" }
        switchRow("Precise trimming by default", "precise", false) { "Slower, but cuts exactly at your times" }
        switchRow("Use my Google account", "use_account", true) {
            when {
                prefs.getBoolean("cookies_imported", false) -> "Using the imported cookies file"
                signedIn() -> "Signed in through the Browse tab"
                else -> "Not linked — tap the account icon in Browse"
            }
        }
    }

    private fun refreshSettings() { refreshers.forEach { it() } }

    private fun addRow(title: String, sub: () -> String, tap: () -> Unit, sw: MaterialSwitch? = null) {
        val tv = TypedValue()
        theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
        val row = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            setBackgroundResource(tv.resourceId)
            setOnClickListener { tap() }
        }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val s = TextView(this).apply { text = sub(); textSize = 13f; alpha = 0.7f }
        col.addView(TextView(this).apply { text = title; textSize = 16f })
        col.addView(s)
        row.addView(col, LinearLayout.LayoutParams(0, W, 1f))
        sw?.let { row.addView(it) }
        ui.settingsBox.addView(row)
        refreshers += { s.text = sub() }
    }

    private fun choiceRow(title: String, key: String, labels: List<String>, def: Int) {
        addRow(title, { labels[prefs.getInt(key, def).coerceIn(labels.indices)] }, {
            MaterialAlertDialogBuilder(this).setTitle(title)
                .setSingleChoiceItems(labels.toTypedArray(), prefs.getInt(key, def)) { d, i ->
                    prefs.edit().putInt(key, i).apply(); d.dismiss(); refreshSettings()
                }.show()
        })
    }

    private fun switchRow(title: String, key: String, def: Boolean, sub: () -> String) {
        val sw = MaterialSwitch(this).apply {
            isChecked = prefs.getBoolean(key, def)
            setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean(key, c).apply() }
        }
        addRow(title, sub, { sw.toggle() }, sw)
    }

    // =====================  NOTIFICATIONS & HELPERS  =====================

    private fun notifyProgress(t: Task) {
        val now = System.currentTimeMillis()
        if (now - lastNotif < 1000) return
        lastNotif = now
        val n = tasks.count { it.st == St.RUNNING }
        val text = if (n > 1) "Downloading $n files" else t.title
        runCatching {
            getSystemService(NotificationManager::class.java).notify(
                KeepAliveService.ID, KeepAliveService.build(this, text, if (t.pct >= 0) t.pct.toInt().coerceAtMost(100) else null)
            )
        }
    }

    private fun notifyDone(text: String) {
        runCatching {
            getSystemService(NotificationManager::class.java).notify(2, KeepAliveService.build(this, text, null, true))
        }
    }

    override fun onDestroy() {
        KeepAliveService.onCancel = null
        super.onDestroy()
    }

    private fun say(m: String, toast: Boolean = true) = runOnUiThread {
        ui.hintView.text = m
        if (toast) Toast.makeText(this, m, Toast.LENGTH_LONG).show()
    }

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun extractUrl(t: String) = Regex("""https?://\S+""").find(t)?.value ?: ""

    private fun fmt(s: Int): String {
        val h = s / 3600
        val m = s % 3600 / 60
        val sec = s % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
    }

    private fun fmtSize(b: Long): String =
        if (b >= (1L shl 30)) "%.1f GB".format(b / 1073741824.0) else "%d MB".format(maxOf(1L, b / 1048576))

    private fun msg(e: Exception): String {
        val ls = e.message?.lines().orEmpty().filter { it.isNotBlank() }
        return (ls.lastOrNull { "ERROR" in it } ?: ls.firstOrNull() ?: "Unknown error").take(180)
    }
}
